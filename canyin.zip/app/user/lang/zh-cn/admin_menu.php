<?php
// +----------------------------------------------------------------------
// | ThinkCMF [ WE CAN DO IT MORE SIMPLE ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2017 http://www.thinkcmf.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 老猫 <thinkcmf@126.com>
// +----------------------------------------------------------------------
return [
    'USER_INDEXADMIN_BAN'       => '拉黑会员',
    'USER_INDEXADMIN_CANCELBAN' => '启用会员',
    'USER_INDEXADMIN_DEFAULT1'  => '用户组',
    'USER_INDEXADMIN_DEFAULT3'  => '管理组',
    'USER_INDEXADMIN_INDEX'     => '本站用户',
    'USER_OAUTHADMIN_DELETE'    => '第三方用户解绑',
    'USER_OAUTHADMIN_INDEX'     => '第三方用户',
    'USER_INDEXADMIN_DEFAULT'   => '用户管理'
];
