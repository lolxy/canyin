<?php

return [
    // 应用调试模式
    'app_debug' => true,
    // 应用Trace
    'app_trace' => true,

];