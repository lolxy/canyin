<?php

return [
    // 应用调试模式
    'app_debug' => false,
    // 应用Trace
    'app_trace' => false,

];