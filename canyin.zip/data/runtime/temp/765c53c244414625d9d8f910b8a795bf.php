<?php if (!defined('THINK_PATH')) exit(); /*a:6:{s:31:"themes/canyin/portal\about.html";i:1509248748;s:30:"themes/canyin/public\head.html";i:1508853696;s:34:"themes/canyin/public\function.html";i:1509278413;s:29:"themes/canyin/public\nav.html";i:1509112433;s:32:"themes/canyin/public\footer.html";i:1508854962;s:33:"themes/canyin/public\scripts.html";i:1509285519;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo $page['post_title']; ?>-<?php echo (isset($site_info['site_name']) && ($site_info['site_name'] !== '')?$site_info['site_name']:''); ?></title>
    <meta name="keywords" content="<?php echo $page['post_keywords']; ?>"/>
    <meta name="description" content="<?php echo $page['post_excerpt']; ?>">
    
<?php 
/*可以加多个方法哟！*/
function _sp_helloworld(){
	echo "hello 这里有餐饮!";
}

function _sp_helloworld2(){
	echo "hello 这里有餐饮2!";
}


function _sp_helloworld3(){
	echo "hello 这里有餐饮3!";
}

 ?>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="author" content="hujianying">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta content="yes" name="apple-mobile-web-app-capable" />
<meta content="black" name="apple-mobile-web-app-status-bar-style" />
<meta content="telephone=no" name="format-detection" />
<meta name="renderer" content="webkit">
<!-- No Baidu Siteapp-->
<meta http-equiv="Cache-Control" content="no-siteapp"/>
<link rel="icon" href="__TMPL__/public/assets/images/favicon.ico" type="image/png"/>
<link rel="shortcut icon" href="__TMPL__/public/assets/images/favicon.png" type="image/png">
<title></title>
<!-- Bootstrap -->
<link href="__TMPL__/public/assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="__TMPL__/public/assets/css/swiper.min.css">
<link rel="stylesheet" href="__TMPL__/public/assets/css/style.css">
<!--[if lt IE 9]>
<script src="__TMPL__/public/assets/js/html5shiv.min.js"></script>
<script src="__TMPL__/public/assets/js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">
    //全局变量
    var GV = {
        ROOT: "__ROOT__/",
        WEB_ROOT: "__WEB_ROOT__/",
        JS_ROOT: "static/js/"
    };
</script>
<script src="__STATIC__/js/wind.js"></script>

    <?php 
    \think\Hook::listen('before_head_end',$temp59f5e44203cf1,null,false);
 ?>
	<style>
    html,body{background-color: #fff;color:#434343;}
    </style>
</head>
<body>
<header>
	<nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">
          	<img src="<?php echo cmf_get_image_url($site_info['site_logo']); ?>" alt="" class="img-responsive"/>
          </a>
        </div>

        <div class="collapse navbar-collapse" id="navbar-collapse">
          <ul id="main-menu" class="nav navbar-nav navbar-right">
              <?php

function __parse_navigation4a3b7c19939c43a550cb98499d0248ff($menus,$level=1){
$_parse_navigation_func_name = '__parse_navigation4a3b7c19939c43a550cb98499d0248ff';
if(is_array($menus) || $menus instanceof \think\Collection || $menus instanceof \think\Paginator): if( count($menus)==0 ) : echo "" ;else: foreach($menus as $key=>$menu): if(empty($menu['children'])): ?>
    <li class="menu-item menu-item-level-<?php echo $level; ?>">
    
                      <a href="<?php echo (isset($menu['href']) && ($menu['href'] !== '')?$menu['href']:''); ?>" target="<?php echo (isset($menu['target']) && ($menu['target'] !== '')?$menu['target']:''); ?>">
                          <?php echo (isset($menu['name']) && ($menu['name'] !== '')?$menu['name']:''); ?>
                      </a>
                  
    </li>
<?php endif; if(!empty($menu['children'])): ?>
    <li class="dropdown dropdown-custom dropdown-custom-level-<?php echo $level; ?>">
        
                      <a href="#" class="dropdown-toggle dropdown-toggle-<?php echo $level; ?>" data-toggle="dropdown">
                          <?php echo (isset($menu['name']) && ($menu['name'] !== '')?$menu['name']:''); ?><span class="caret"></span>
                      </a>
                  
        <ul class="dropdown-menu dropdown-menu-level-<?php echo $level; ?>">
            <?php 
            $mLevel=$level+1;
             ?>
            <?php echo $_parse_navigation_func_name($menu['children'],$mLevel); ?>
        </ul>
    </li>
<?php endif; endforeach; endif; else: echo "" ;endif; 
}

    $navMenuModel = new \app\admin\model\NavMenuModel();
    $menus = $navMenuModel->navMenusTreeArray('',0);
if(''==''): ?>
    <?php echo __parse_navigation4a3b7c19939c43a550cb98499d0248ff($menus); else: ?>
    < id="main-navigation" class="nav navbar-nav navbar-nav-custom">
        <?php echo __parse_navigation4a3b7c19939c43a550cb98499d0248ff($menus); ?>
    </>
<?php endif; ?>

          </ul>
        </div>
      </div>
    </nav>
</header>


<div class="wrapper">
	<?php
     if(isset($theme_widgets['zheliyou']) && $theme_widgets['zheliyou']['display']){
        $widget=$theme_widgets['zheliyou'];
     
 ?>

	<div class="container aboutboxone">
    	<div class="row">
        	<div class="col-xs-12 col-md-6">
            	<div class="tit">
                <img src="__TMPL__/public/assets/images/about_tit1.png" alt="" class="img-responsive"/>
                </div>
                <div class="content">
                	<?php echo htmlspecialchars_decode($widget['vars']['description']); ?>
                </div>
            </div>

            <div class="col-xs-12 col-md-6 text-center">
            	<img src="<?php echo cmf_get_image_url($widget['vars']['main_thumb']); ?>" alt="" class="img-responsive"/>
            </div>
        </div>
    </div>
    
<?php
    }
 
     if(isset($theme_widgets['terms']) && $theme_widgets['terms']['display']){
        $widget=$theme_widgets['terms'];
     
 ?>

    <div class="container-fluid aboutboxtwo">
    	<div class="container">
           	<div class="row">
                <h2 class="htit abouthtit2">
                    <span class="sr-only">团队</span>
                </h2>
            </div>

            <div class="row teamlist">
                <ul class="list-unstyled">
                
                <?php 
                $term_count = count($widget['vars']['itemarray']);
                $rows = ceil($term_count/3);
                 $__FOR_START_13969__=1;$__FOR_END_13969__=$rows;for($row=$__FOR_START_13969__;$row <= $__FOR_END_13969__;$row+=1){ 
                        $first_row = ($row-1)*3;
                        $terms = array_slice($widget['vars']['itemarray'],$first_row,3);
                     if(is_array($terms) || $terms instanceof \think\Collection || $terms instanceof \think\Paginator): if( count($terms)==0 ) : echo "" ;else: foreach($terms as $key=>$vo): ?>
                        <li class="col-sm-4 col-xs-12">
                            <div class="box">
                                <div class="imgbox">
                                    <img src="<?php echo cmf_get_image_url($vo['thumb']); ?>" alt="">
                                </div>
                                <div class="txtbox">
                                    <h3><?php echo $vo['title']; ?></h3>
                                    <p><?php echo htmlspecialchars_decode($vo['description']); ?></p>
                                </div>
                            </div>
                    	</li>
                    <?php endforeach; endif; else: echo "" ;endif; } ?>
                </ul>
            </div>
        </div>
    </div>
    
<?php
    }
 
     if(isset($theme_widgets['licheng']) && $theme_widgets['licheng']['display']){
        $widget=$theme_widgets['licheng'];
     
 ?>

    <div class="container lichengbox">
    	<div class="row">
            <h2 class="htit abouthtit3">
                <span class="sr-only">历程</span>
            </h2>
        </div>

    	<div class="row">
        	<img src="<?php echo cmf_get_image_url($widget['vars']['lichengimg']); ?>" alt="" class="img-responsive"/>
        </div>
    </div>
    
<?php
    }
 ?>



    <!--企业理念-->
    <?php
     if(isset($theme_widgets['linian']) && $theme_widgets['linian']['display']){
        $widget=$theme_widgets['linian'];
     
 ?>

    <div class="container-fulid qiyelinianbox">
        <div class="container">
            <div class="row">
                <h2 class="htit abouthtit4">
                    <span class="sr-only">企业理念</span>
                </h2>
            </div>
            <div class="row">
                <?php 
                $linian_count = count($widget['vars']['linianarray']);
                $rows = ceil($linian_count/3);
                 $__FOR_START_18616__=1;$__FOR_END_18616__=$rows;for($row=$__FOR_START_18616__;$row <= $__FOR_END_18616__;$row+=1){ 
                        $first_row = ($row-1)*3;
                        $linians = array_slice($widget['vars']['linianarray'],$first_row,3);
                     if(is_array($linians) || $linians instanceof \think\Collection || $linians instanceof \think\Paginator): if( count($linians)==0 ) : echo "" ;else: foreach($linians as $key=>$vo): ?>
                        <div class="col-xs-12 col-sm-4">
                            <div class="recombox">
                              <div class="text-center">
                              <img src="<?php echo cmf_get_image_url($vo['thumb']); ?>" alt="..." class="img-responsive"/>
                              </div>
                              <div class="caption">
                                <h3><?php echo $vo['title']; ?></h3>
                                <p><?php echo htmlspecialchars_decode($vo['description']); ?></p>
                              </div>
                            </div>
                        </div>
                    <?php endforeach; endif; else: echo "" ;endif; } ?>
            </div>
        </div>
        </div>
        
<?php
    }
 ?>



        <!--联系我们-->
   <?php
     if(isset($theme_widgets['contact']) && $theme_widgets['contact']['display']){
        $widget=$theme_widgets['contact'];
     
 
$location=explode(',',$widget["vars"]["company_location"]);
$location_str = '"'.$location[0].'", "'.$location[1].'"';
 ?>
<div class="container-fulid about_contactus">
    <div class="container">
        <div class="row">
            <h2 class="htit abouthtit5">
                <span class="sr-only">联系我们</span>
            </h2>
        </div>

        <div class="row">
        	<div class="col-xs-12 col-sm-6">
            	<div id="mapCanvas" class="about-map-canvas"></div>
            </div>
            <div class="col-xs-12 col-sm-6">
            	<div class="myinfo">
                    <dl class="dl-horizontal">
                        <dt>地址：</dt>
                        <dd><?php echo $widget['vars']['address']; ?></dd>
                        <dt>QQ：</dt>
                        <dd><?php echo $widget['vars']['qq']; ?></dd>
                        <dt>微信：</dt>
                        <dd><?php echo $widget['vars']['weixin']; ?></dd>
                        <dt>邮箱：</dt>
                        <dd><?php echo $widget['vars']['email']; ?></dd>
                        <dt>电话：</dt>
                        <dd><?php echo $widget['vars']['phone']; ?></dd>
                    </dl>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="http://api.map.baidu.com/api?v=1.3"></script>
<script>
	var map   = new BMap.Map("mapCanvas"); // 创建Map实例
	var point = new BMap.Point(<?php echo $location_str; ?>); // 创建点坐标
	map.centerAndZoom(point, 15); // 初始化地图,设置中心点坐标和地图级别。
	var marker = new BMap.Marker(point); // 创建标注
	map.addOverlay(marker); // 将标注添加到地图中
</script>

<?php
    }
 ?>


</div>

<footer class="footer">
  <?php 
    \think\Hook::listen('footer_start',$temp59f5e44203d16,null,false);
 ?>
	<p>备案号:
  <?php if(!(empty($site_info['site_icp']) || (($site_info['site_icp'] instanceof \think\Collection || $site_info['site_icp'] instanceof \think\Paginator ) && $site_info['site_icp']->isEmpty()))): ?>
      <a href="http://www.miitbeian.gov.cn/" target="_blank"><?php echo $site_info['site_icp']; ?></a>
      <?php else: ?>
      请在后台设置"网站信息"设置"备案信息"
  <?php endif; ?></p>
</footer>

<!-- /container -->
<script src="__TMPL__/public/assets/js/jquery.min.js"></script>
<script src="__TMPL__/public/assets/js/swiper.jquery.min.js"></script>
<script src="__TMPL__/public/assets/js/bootstrap.min.js"></script>
<script>
$("#main-menu a,#news-nav a").each(function(){
    if ($(this)[0].href == String(window.location) && $(this).attr('href')!="") {
    	$(this).parents("li").addClass("active");
	}
    });
</script>

<?php 
    \think\Hook::listen('before_body_end',$temp59f5e44203d25,null,false);
 ?>
</body>
</html>
