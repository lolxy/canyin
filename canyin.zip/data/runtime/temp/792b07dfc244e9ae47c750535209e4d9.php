<?php if (!defined('THINK_PATH')) exit(); /*a:7:{s:33:"themes/canyin/portal\article.html";i:1509292360;s:30:"themes/canyin/public\head.html";i:1508853696;s:34:"themes/canyin/public\function.html";i:1509278413;s:29:"themes/canyin/public\nav.html";i:1509112433;s:37:"themes/canyin/public\categorynav.html";i:1509285941;s:32:"themes/canyin/public\footer.html";i:1508854962;s:33:"themes/canyin/public\scripts.html";i:1509285519;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo $article['post_title']; ?>-<?php echo (isset($site_info['site_name']) && ($site_info['site_name'] !== '')?$site_info['site_name']:''); ?></title>
    <meta name="keywords" content="<?php echo (isset($site_info['site_seo_keywords']) && ($site_info['site_seo_keywords'] !== '')?$site_info['site_seo_keywords']:''); ?>"/>
    <meta name="description" content="<?php echo (isset($site_info['site_seo_description']) && ($site_info['site_seo_description'] !== '')?$site_info['site_seo_description']:''); ?>">
    
<?php 
/*可以加多个方法哟！*/
function _sp_helloworld(){
	echo "hello 这里有餐饮!";
}

function _sp_helloworld2(){
	echo "hello 这里有餐饮2!";
}


function _sp_helloworld3(){
	echo "hello 这里有餐饮3!";
}

 ?>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="author" content="hujianying">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta content="yes" name="apple-mobile-web-app-capable" />
<meta content="black" name="apple-mobile-web-app-status-bar-style" />
<meta content="telephone=no" name="format-detection" />
<meta name="renderer" content="webkit">
<!-- No Baidu Siteapp-->
<meta http-equiv="Cache-Control" content="no-siteapp"/>
<link rel="icon" href="__TMPL__/public/assets/images/favicon.ico" type="image/png"/>
<link rel="shortcut icon" href="__TMPL__/public/assets/images/favicon.png" type="image/png">
<title></title>
<!-- Bootstrap -->
<link href="__TMPL__/public/assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="__TMPL__/public/assets/css/swiper.min.css">
<link rel="stylesheet" href="__TMPL__/public/assets/css/style.css">
<!--[if lt IE 9]>
<script src="__TMPL__/public/assets/js/html5shiv.min.js"></script>
<script src="__TMPL__/public/assets/js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">
    //全局变量
    var GV = {
        ROOT: "__ROOT__/",
        WEB_ROOT: "__WEB_ROOT__/",
        JS_ROOT: "static/js/"
    };
</script>
<script src="__STATIC__/js/wind.js"></script>

    <?php 
    \think\Hook::listen('before_head_end',$temp59f5fd363eca7,null,false);
 ?>
<style>
html,body{background-color: #fff;color:#434343;}
</style>
</head>
<body>
<header>
	<nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">
          	<img src="<?php echo cmf_get_image_url($site_info['site_logo']); ?>" alt="" class="img-responsive"/>
          </a>
        </div>

        <div class="collapse navbar-collapse" id="navbar-collapse">
          <ul id="main-menu" class="nav navbar-nav navbar-right">
              <?php

function __parse_navigation7c409c8c0fd07850216104a1d8119fd5($menus,$level=1){
$_parse_navigation_func_name = '__parse_navigation7c409c8c0fd07850216104a1d8119fd5';
if(is_array($menus) || $menus instanceof \think\Collection || $menus instanceof \think\Paginator): if( count($menus)==0 ) : echo "" ;else: foreach($menus as $key=>$menu): if(empty($menu['children'])): ?>
    <li class="menu-item menu-item-level-<?php echo $level; ?>">
    
                      <a href="<?php echo (isset($menu['href']) && ($menu['href'] !== '')?$menu['href']:''); ?>" target="<?php echo (isset($menu['target']) && ($menu['target'] !== '')?$menu['target']:''); ?>">
                          <?php echo (isset($menu['name']) && ($menu['name'] !== '')?$menu['name']:''); ?>
                      </a>
                  
    </li>
<?php endif; if(!empty($menu['children'])): ?>
    <li class="dropdown dropdown-custom dropdown-custom-level-<?php echo $level; ?>">
        
                      <a href="#" class="dropdown-toggle dropdown-toggle-<?php echo $level; ?>" data-toggle="dropdown">
                          <?php echo (isset($menu['name']) && ($menu['name'] !== '')?$menu['name']:''); ?><span class="caret"></span>
                      </a>
                  
        <ul class="dropdown-menu dropdown-menu-level-<?php echo $level; ?>">
            <?php 
            $mLevel=$level+1;
             ?>
            <?php echo $_parse_navigation_func_name($menu['children'],$mLevel); ?>
        </ul>
    </li>
<?php endif; endforeach; endif; else: echo "" ;endif; 
}

    $navMenuModel = new \app\admin\model\NavMenuModel();
    $menus = $navMenuModel->navMenusTreeArray('',0);
if(''==''): ?>
    <?php echo __parse_navigation7c409c8c0fd07850216104a1d8119fd5($menus); else: ?>
    < id="main-navigation" class="nav navbar-nav navbar-nav-custom">
        <?php echo __parse_navigation7c409c8c0fd07850216104a1d8119fd5($menus); ?>
    </>
<?php endif; ?>

          </ul>
        </div>
      </div>
    </nav>
</header>


<div class="wrapper newswrapperbox">
	<?php $categoryId=2; ?>
<div class="container-fulid categorybox">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-8 none-padding">
                <ul class="nav nav-pills" id="news-nav">
                  <li><a href="<?php echo cmf_url('portal/List/index',array('id'=>$categoryId)); ?>">全部新闻</a></li>
                  <?php
$portal_sub_categories_data = \app\portal\service\ApiService::subCategories($categoryId);
 
 if(is_array($portal_sub_categories_data) || $portal_sub_categories_data instanceof \think\Collection || $portal_sub_categories_data instanceof \think\Paginator): $i = 0; $__LIST__ = $portal_sub_categories_data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

                  <li><a href="<?php echo cmf_url('portal/List/index',array('id'=>$vo['id'])); ?>"><?php echo $vo['name']; ?></a></li>
                  
<?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
            <div class="col-sm-4 hidden-xs text-right none-padding tells">
                咨询热线：<?php echo $theme_vars['contact']; ?>
            </div>
        </div>
    </div>
</div>

    <div class="container">
    	<div class="row">
        	<div class="col-xs-12 none-padding">
            	<?php 
                $currentCid=$category['id'];
                $currentCategory=[]
                 ?>
                <ol class="breadcrumb">
                  <li><a href="__ROOT__/">首页</a></li>
                  <?php
if(!empty($currentCid)){
    $__BREADCRUMB_ITEMS__ = \app\portal\service\ApiService::breadcrumb($currentCid,true);
if(is_array($__BREADCRUMB_ITEMS__) || $__BREADCRUMB_ITEMS__ instanceof \think\Collection || $__BREADCRUMB_ITEMS__ instanceof \think\Paginator): $i = 0; $__LIST__ = $__BREADCRUMB_ITEMS__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
    
                    <li><a href="<?php echo url('portal/List/index',['id'=>$vo['id']]); ?>"><?php echo $vo['name']; ?></a></li>
                  
<?php endforeach; endif; else: echo "" ;endif; 
}
?>
                  <li class="active"><?php echo $article['post_title']; ?></li>
                </ol>
            </div>
        </div>
        
        <div class="contentbox">
            <div class="row">
                <div class="col-xs-12">
                    <h2 class="text-overflow"><?php echo $article['post_title']; ?></h2>
                    <span class="fbtime"><?php echo date('Y年m月d日',$article['update_time']); ?></span>
                </div>
            </div>
            
            <div class="row">
            	<div class="col-xs-12 col-sm-7">
                	<div class="htmlbox">
                    	<?php echo htmlspecialchars_decode($article['post_content']); ?>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-5 none-padding">
                	<div class="recomlist">
                    	<ul class="list-unstyled">
                        <?php
$portal_all_sub_categories_data = \app\portal\service\ApiService::allSubCategories($currentCid);
 if(is_array($portal_all_sub_categories_data) || $portal_all_sub_categories_data instanceof \think\Collection || $portal_all_sub_categories_data instanceof \think\Paginator): $i = 0; $__LIST__ = $portal_all_sub_categories_data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;
                                $currentCategory[] = $vo['id'];
                             endforeach; endif; else: echo "" ;endif; 
                            if(!empty($currentCategory)){
                                $currentCategoryList=join($currentCategory,',');
                                $currentCategoryList = $currentCid.','.$currentCategoryList;
                            }else{
                                $currentCategoryList = $currentCid;
                            }
                         
$articles_data = \app\portal\service\ApiService::articles([
    'field'   => '',
    'where'   => "",
    'limit'   => '5',
    'order'   => 'post.post_hits DESC,post.published_time DESC',
    'page'    => '',
    'relation'=> '',
    'category_ids'=>$currentCategoryList
]);

$__PAGE_VAR_NAME__ = isset($articles_data['page'])?$articles_data['page']:'';

 if(is_array($articles_data['articles']) || $articles_data['articles'] instanceof \think\Collection || $articles_data['articles'] instanceof \think\Paginator): $i = 0; $__LIST__ = $articles_data['articles'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

                            <li>
                            	<div class="picbox">
                                	<a href="<?php echo cmf_url('portal/Article/index',array('id'=>$vo['id'],'cid'=>$vo['category_id'])); ?>" target="_blank" title="<?php echo $vo['post_title']; ?>">
                                    	<?php if(isset($vo['more']['thumbnail'])): if(empty($vo['more']['thumbnail']) || (($vo['more']['thumbnail'] instanceof \think\Collection || $vo['more']['thumbnail'] instanceof \think\Paginator ) && $vo['more']['thumbnail']->isEmpty())): ?>
                                                <img src="__TMPL__/public/assets/images/default-thumbnail.png"
                                                     class="img-responsive"
                                                     alt="<?php echo $vo['post_title']; ?>">
                                                <?php else: ?>
                                                <img src="<?php echo cmf_get_image_url($vo['more']['thumbnail']); ?>"
                                                     class="img-responsive"
                                                     alt="<?php echo $vo['post_title']; ?>">
                                            <?php endif; else: ?>
                                            <img src="__TMPL__/public/assets/images/default-thumbnail.png"
                                                 class="img-responsive"
                                                 alt="<?php echo $vo['post_title']; ?>">
                                        <?php endif; ?>
                                    </a>
                                </div>
                                <div class="tbox">
                                	<div class="theader">
                                    	<span class="category pill-left"><?php echo cmf_get_current_category($vo['category_id']); ?></span>
                                        <span class="time pull-right"><span class="time" title="<?php echo date('Y-m-d H:i:s',$vo['published_time']); ?>"></span></span>
                                    </div>
                                    <div class="tbody">
                                    	<a href="<?php echo cmf_url('portal/Article/index',array('id'=>$vo['id'],'cid'=>$vo['category_id'])); ?>" target="_blank" class="text-overflow-3"><?php echo $vo['post_excerpt']; ?></a>
                                    </div>
                                </div>
                            </li>
                            
<?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<footer class="footer">
  <?php 
    \think\Hook::listen('footer_start',$temp59f5fd363ecc9,null,false);
 ?>
	<p>备案号:
  <?php if(!(empty($site_info['site_icp']) || (($site_info['site_icp'] instanceof \think\Collection || $site_info['site_icp'] instanceof \think\Paginator ) && $site_info['site_icp']->isEmpty()))): ?>
      <a href="http://www.miitbeian.gov.cn/" target="_blank"><?php echo $site_info['site_icp']; ?></a>
      <?php else: ?>
      请在后台设置"网站信息"设置"备案信息"
  <?php endif; ?></p>
</footer>

<script src="__TMPL__/public/assets/js/jquery.min.js"></script>
<script src="__TMPL__/public/assets/js/swiper.jquery.min.js"></script>
<script src="__TMPL__/public/assets/js/bootstrap.min.js"></script>
<script>
$("#main-menu a,#news-nav a").each(function(){
    if ($(this)[0].href == String(window.location) && $(this).attr('href')!="") {
    	$(this).parents("li").addClass("active");
	}
    });
</script>

<script src="__TMPL__/public/assets/js/timeago.jquery.js"></script>
<script>
 $(".time").timeago();
</script>
<?php 
    \think\Hook::listen('before_body_end',$temp59f5fd363ece8,null,false);
 ?>
</body>
</html>
