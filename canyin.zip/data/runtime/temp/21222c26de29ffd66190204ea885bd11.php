<?php if (!defined('THINK_PATH')) exit(); /*a:6:{s:32:"themes/canyin/portal\\index.html";i:1509244686;s:30:"themes/canyin/public\head.html";i:1508853696;s:34:"themes/canyin/public\function.html";i:1509278413;s:29:"themes/canyin/public\nav.html";i:1509112433;s:32:"themes/canyin/public\footer.html";i:1508854962;s:33:"themes/canyin/public\scripts.html";i:1509285519;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>首页 <?php echo (isset($site_info['site_name']) && ($site_info['site_name'] !== '')?$site_info['site_name']:''); ?></title>
    <meta name="keywords" content="<?php echo (isset($site_info['site_seo_keywords']) && ($site_info['site_seo_keywords'] !== '')?$site_info['site_seo_keywords']:''); ?>"/>
    <meta name="description" content="<?php echo (isset($site_info['site_seo_description']) && ($site_info['site_seo_description'] !== '')?$site_info['site_seo_description']:''); ?>">
    
<?php 
/*可以加多个方法哟！*/
function _sp_helloworld(){
	echo "hello 这里有餐饮!";
}

function _sp_helloworld2(){
	echo "hello 这里有餐饮2!";
}


function _sp_helloworld3(){
	echo "hello 这里有餐饮3!";
}

 ?>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="author" content="hujianying">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta content="yes" name="apple-mobile-web-app-capable" />
<meta content="black" name="apple-mobile-web-app-status-bar-style" />
<meta content="telephone=no" name="format-detection" />
<meta name="renderer" content="webkit">
<!-- No Baidu Siteapp-->
<meta http-equiv="Cache-Control" content="no-siteapp"/>
<link rel="icon" href="__TMPL__/public/assets/images/favicon.ico" type="image/png"/>
<link rel="shortcut icon" href="__TMPL__/public/assets/images/favicon.png" type="image/png">
<title></title>
<!-- Bootstrap -->
<link href="__TMPL__/public/assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="__TMPL__/public/assets/css/swiper.min.css">
<link rel="stylesheet" href="__TMPL__/public/assets/css/style.css">
<!--[if lt IE 9]>
<script src="__TMPL__/public/assets/js/html5shiv.min.js"></script>
<script src="__TMPL__/public/assets/js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">
    //全局变量
    var GV = {
        ROOT: "__ROOT__/",
        WEB_ROOT: "__WEB_ROOT__/",
        JS_ROOT: "static/js/"
    };
</script>
<script src="__STATIC__/js/wind.js"></script>

    <?php 
    \think\Hook::listen('before_head_end',$temp59f5fd1ca1fb5,null,false);
 ?>
</head>
<body>
<header>
	<nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">
          	<img src="<?php echo cmf_get_image_url($site_info['site_logo']); ?>" alt="" class="img-responsive"/>
          </a>
        </div>

        <div class="collapse navbar-collapse" id="navbar-collapse">
          <ul id="main-menu" class="nav navbar-nav navbar-right">
              <?php

function __parse_navigationc129d423cbedca86df978e4179b68332($menus,$level=1){
$_parse_navigation_func_name = '__parse_navigationc129d423cbedca86df978e4179b68332';
if(is_array($menus) || $menus instanceof \think\Collection || $menus instanceof \think\Paginator): if( count($menus)==0 ) : echo "" ;else: foreach($menus as $key=>$menu): if(empty($menu['children'])): ?>
    <li class="menu-item menu-item-level-<?php echo $level; ?>">
    
                      <a href="<?php echo (isset($menu['href']) && ($menu['href'] !== '')?$menu['href']:''); ?>" target="<?php echo (isset($menu['target']) && ($menu['target'] !== '')?$menu['target']:''); ?>">
                          <?php echo (isset($menu['name']) && ($menu['name'] !== '')?$menu['name']:''); ?>
                      </a>
                  
    </li>
<?php endif; if(!empty($menu['children'])): ?>
    <li class="dropdown dropdown-custom dropdown-custom-level-<?php echo $level; ?>">
        
                      <a href="#" class="dropdown-toggle dropdown-toggle-<?php echo $level; ?>" data-toggle="dropdown">
                          <?php echo (isset($menu['name']) && ($menu['name'] !== '')?$menu['name']:''); ?><span class="caret"></span>
                      </a>
                  
        <ul class="dropdown-menu dropdown-menu-level-<?php echo $level; ?>">
            <?php 
            $mLevel=$level+1;
             ?>
            <?php echo $_parse_navigation_func_name($menu['children'],$mLevel); ?>
        </ul>
    </li>
<?php endif; endforeach; endif; else: echo "" ;endif; 
}

    $navMenuModel = new \app\admin\model\NavMenuModel();
    $menus = $navMenuModel->navMenusTreeArray('',0);
if(''==''): ?>
    <?php echo __parse_navigationc129d423cbedca86df978e4179b68332($menus); else: ?>
    < id="main-navigation" class="nav navbar-nav navbar-nav-custom">
        <?php echo __parse_navigationc129d423cbedca86df978e4179b68332($menus); ?>
    </>
<?php endif; ?>

          </ul>
        </div>
      </div>
    </nav>
</header>


<div class="wrapper">
<div class="banner">
	<div class="swiper-container">
        <div class="swiper-wrapper">
            <?php 
                $top_slide_id=empty($theme_vars['top_slide'])?1:$theme_vars['top_slide'];
             
     $__SLIDE_ITEMS__ = \app\admin\service\ApiService::slides($top_slide_id);
if(is_array($__SLIDE_ITEMS__) || $__SLIDE_ITEMS__ instanceof \think\Collection || $__SLIDE_ITEMS__ instanceof \think\Paginator): $i = 0; $__LIST__ = $__SLIDE_ITEMS__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

                <div class="swiper-slide">
                    <a href="<?php echo (isset($vo['url']) && ($vo['url'] !== '')?$vo['url']:''); ?>"><img src="<?php echo cmf_get_image_url($vo['image']); ?>" alt="" class="img-responsive"/></a>
                </div>
            
<?php endforeach; endif; else: echo "" ;endif; 
    if(!isset($__SLIDE_ITEMS__)){
        $__SLIDE_ITEMS__ = \app\admin\service\ApiService::slides($top_slide_id);
    }
if(count($__SLIDE_ITEMS__) == 0): ?>

              <div class="swiper-slide">
                <img src="__TMPL__/public/assets/images/banner.png" alt="" class="img-responsive"/>
              </div>
              <div class="swiper-slide">
              	<img src="__TMPL__/public/assets/images/banner.png" alt="" class="img-responsive"/>
              </div>
              <div class="swiper-slide">
              	<img src="__TMPL__/public/assets/images/banner.png" alt="" class="img-responsive"/>
              </div>
            
<?php endif; ?>
        </div>
        <!-- 如果需要分页器 -->
        <div class="swiper-pagination"></div>
    </div>
</div>

<!--三大品牌-->
<?php
     if(isset($theme_widgets['brand']) && $theme_widgets['brand']['display']){
        $widget=$theme_widgets['brand'];
     
 ?>

<div class="container">
	<div class="row">
    	<h2 class="htit htit1">
        	<span class="sr-only">三大品牌</span>
        </h2>
    </div>
    
    <div class="row">
    <?php 
        $brand_count = count($widget['vars']['brands']);
        $rows = ceil($brand_count/3);
     $__FOR_START_10957__=1;$__FOR_END_10957__=$rows;for($row=$__FOR_START_10957__;$row <= $__FOR_END_10957__;$row+=1){ 
            $first_row = ($row-1)*3;
            $brand = array_slice($widget['vars']['brands'],$first_row,3);
         if(is_array($brand) || $brand instanceof \think\Collection || $brand instanceof \think\Paginator): if( count($brand)==0 ) : echo "" ;else: foreach($brand as $key=>$vo): ?>
          <div class="col-xs-12 col-sm-4">
            <a href="<?php echo $vo['url']; ?>" title="<?php echo $vo['title']; ?>">
            <div class="recombox">
              <div class="text-center pos-r">
              <img src="<?php echo cmf_get_image_url($vo['thumb']); ?>" alt="..." class="img-responsive"/>
              <div class="img-hover hidden-xs">
                <img src="__TMPL__/public/assets/images/recommend_hover.png" alt="..." class="img-responsive"/>
              </div>
              </div>
              <div class="caption">
                <h3><?php echo $vo['title']; ?></h3>
              </div>
            </div>
            </a>
          </div>
        <?php endforeach; endif; else: echo "" ;endif; } ?>
    </div>
</div>

<?php
    }
 ?>



<!--公司简介-->
<?php
     if(isset($theme_widgets['companyinfo']) && $theme_widgets['companyinfo']['display']){
        $widget=$theme_widgets['companyinfo'];
     
 ?>

<div class="container-fulid aboutus">
    <div class="container">
        <div class="row">
            <h2 class="htit htit2">
                <span class="sr-only">公司简介</span>
            </h2>
        </div>
        <div class="row">
          <div class="col-xs-10 col-xs-offset-1 description">
            <p><?php echo $widget['vars']['top_content']; ?></p>
        	<p>目前公司旗下已有3个品牌：</p>
          </div>
        </div>

        <div class="row mt-20 mb-20">
        	<div class="col-xs-8 col-xs-offset-2 brandbox">
            <?php 
                $brand_count = count($widget['vars']['brand']);
                $rows = ceil($brand_count/3);
             $__FOR_START_14436__=1;$__FOR_END_14436__=$rows;for($row=$__FOR_START_14436__;$row <= $__FOR_END_14436__;$row+=1){ 
                    $first_row = ($row-1)*3;
                    $brand = array_slice($widget['vars']['brand'],$first_row,3);
                 if(is_array($brand) || $brand instanceof \think\Collection || $brand instanceof \think\Paginator): if( count($brand)==0 ) : echo "" ;else: foreach($brand as $key=>$vo): ?>
                    <div class="col-xs-12">
                    <a href="<?php echo $vo['url']; ?>" title="<?php echo $vo['title']; ?>">
                        <div class="col-xs-12 col-sm-6 <?php if($key%2): ?>col-sm-push-6<?php endif; ?>">
                            <img src="<?php echo cmf_get_image_url($vo['thumb']); ?>" alt="" class="img-responsive"/>
                        </div>
                        <div class="col-xs-12 col-sm-6 text-center <?php if($key%2): ?>col-sm-pull-6<?php endif; ?>">
                            <div class="brandtit"><img src="<?php echo cmf_get_image_url($vo['logo']); ?>" alt="" class="img-responsive"/></div>
                            <p><?php echo $vo['content']; ?></p>
                        </div>
                     </a>
                    </div>
                <?php endforeach; endif; else: echo "" ;endif; } ?>
            </div>
        </div>

        <div class="row mb-20">
          <div class="col-xs-10 col-xs-offset-1 description">
          <p><?php echo $widget['vars']['bottom_content']; ?></p>
          </div>
        </div>

        <div class="row">
        	<a href="<?php echo cmf_url('portal/Page/index',['id'=>2]); ?>" class="jmbtns">加盟详情</a>
        </div>
    </div>
</div>

<?php
    }
 ?>



<!--新闻资讯-->
<?php
     if(isset($theme_widgets['last_news']) && $theme_widgets['last_news']['display']){
        $widget=$theme_widgets['last_news'];
     
 
    $widget["vars"]["last_news_category_id"] = empty($widget["vars"]["last_news_category_id"])?1:$widget["vars"]["last_news_category_id"];
    $last_news_limit=5;
    $recomlist = 1;
 ?>
<div class="container newsbox">
	<div class="row">
    	<h2 class="htit htit3">
        	<span class="sr-only">新闻资讯</span>
        </h2>
    </div>
    <div class="row bgfff">
      <div class="col-xs-12 col-sm-6 none-padding text-center">
        <?php
$articles_data = \app\portal\service\ApiService::articles([
    'field'   => '',
    'where'   => "",
    'limit'   => $recomlist,
    'order'   => 'post.is_top DESC,post.recommended DESC,post.update_time DESC,post.published_time DESC',
    'page'    => '',
    'relation'=> '',
    'category_ids'=>$widget['vars']['last_news_category_id']
]);

$__PAGE_VAR_NAME__ = isset($articles_data['page'])?$articles_data['page']:'';

 if(is_array($articles_data['articles']) || $articles_data['articles'] instanceof \think\Collection || $articles_data['articles'] instanceof \think\Paginator): $i = 0; $__LIST__ = $articles_data['articles'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

        <a href="<?php echo cmf_url('portal/Article/index',array('id'=>$vo['id'],'cid'=>$vo['category_id'])); ?>" title="<?php echo $vo['post_title']; ?>">
            <?php if(isset($vo['more']['thumbnail'])): if(empty($vo['more']['thumbnail']) || (($vo['more']['thumbnail'] instanceof \think\Collection || $vo['more']['thumbnail'] instanceof \think\Paginator ) && $vo['more']['thumbnail']->isEmpty())): ?>
                    <img src="__TMPL__/public/assets/images/default-thumbnail.png"
                         class="img-responsive"
                         alt="">
                    <?php else: ?>
                    <img src="<?php echo cmf_get_image_url($vo['more']['thumbnail']); ?>"
                         class="img-responsive"
                         alt="">
                <?php endif; else: ?>
                <img src="__TMPL__/public/assets/images/default-thumbnail.png"
                     class="img-responsive"
                     alt="">
            <?php endif; ?>
        </a>
        
<?php endforeach; endif; else: echo "" ;endif; ?>
      </div>
      <div class="col-xs-12 col-sm-6 newlistbox">
      	<div class="newlist">
        	<div class="new-heading">
            	<h2><?php echo $widget['title']; ?></h2>
                <a href="<?php echo cmf_url('portal/List/index',['id'=>2]); ?>" target="_blank" class="more"></a>
            </div>
            <div class="new-list">
            	<ul class="list-unstyled">
                <?php
$articles_data = \app\portal\service\ApiService::articles([
    'field'   => '',
    'where'   => "",
    'limit'   => $last_news_limit,
    'order'   => 'post.published_time DESC',
    'page'    => '',
    'relation'=> '',
    'category_ids'=>$widget['vars']['last_news_category_id']
]);

$__PAGE_VAR_NAME__ = isset($articles_data['page'])?$articles_data['page']:'';

 if(is_array($articles_data['articles']) || $articles_data['articles'] instanceof \think\Collection || $articles_data['articles'] instanceof \think\Paginator): $i = 0; $__LIST__ = $articles_data['articles'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

                    <li>
                       <a href="<?php echo cmf_url('portal/Article/index',array('id'=>$vo['id'],'cid'=>$vo['category_id'])); ?>" class="text-overflow" title="<?php echo $vo['post_title']; ?>"><?php echo $vo['post_title']; ?></a>
                       <span><?php echo date('Y-m-d',$vo['published_time']); ?></span>
                    </li>
                    
<?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
        </div>
      </div>
    </div>
</div>

<?php
    }
 ?>



<!--联系我们-->
<?php
     if(isset($theme_widgets['contact']) && $theme_widgets['contact']['display']){
        $widget=$theme_widgets['contact'];
     
 
$location=explode(',',$widget["vars"]["company_location"]);
$location_str = '"'.$location[0].'", "'.$location[1].'"';
 ?>
<div class="container-fulid contactus">
    <div class="container">
        <div class="row">
            <h2 class="htit htit4">
                <span class="sr-only">联系我们</span>
            </h2>
        </div>

        <div class="row mapbox">
        	<div class="col-xs-12 col-sm-8 col-sm-offset-2">
            	<div id="mapCanvas" class="map-canvas no-margin"></div>
            </div>
        </div>

        <div class="row telbox">
        	<div class="col-xs-12 col-sm-8 col-sm-offset-2">
                <div class="col-xs-12 col-sm-6 none-padding">
                    <i class="telicon"></i>
                    <span><?php echo $widget["vars"]["phone"]; ?></span>
                </div>
                <div class="col-xs-12 col-sm-6 none-padding">
                    <i class="dwicon"></i>
                    <span><?php echo $widget["vars"]["address"]; ?></span>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script src="http://api.map.baidu.com/api?v=1.3"></script>
<script>
	var map   = new BMap.Map("mapCanvas"); // 创建Map实例
	var point = new BMap.Point(<?php echo $location_str; ?>); // 创建点坐标
	map.centerAndZoom(point, 15); // 初始化地图,设置中心点坐标和地图级别。
	var marker = new BMap.Marker(point); // 创建标注
	map.addOverlay(marker); // 将标注添加到地图中
</script>

<?php
    }
 ?>



<footer class="footer">
  <?php 
    \think\Hook::listen('footer_start',$temp59f5fd1ca1fde,null,false);
 ?>
	<p>备案号:
  <?php if(!(empty($site_info['site_icp']) || (($site_info['site_icp'] instanceof \think\Collection || $site_info['site_icp'] instanceof \think\Paginator ) && $site_info['site_icp']->isEmpty()))): ?>
      <a href="http://www.miitbeian.gov.cn/" target="_blank"><?php echo $site_info['site_icp']; ?></a>
      <?php else: ?>
      请在后台设置"网站信息"设置"备案信息"
  <?php endif; ?></p>
</footer>

<!-- /container -->
<script src="__TMPL__/public/assets/js/jquery.min.js"></script>
<script src="__TMPL__/public/assets/js/swiper.jquery.min.js"></script>
<script src="__TMPL__/public/assets/js/bootstrap.min.js"></script>
<script>
$("#main-menu a,#news-nav a").each(function(){
    if ($(this)[0].href == String(window.location) && $(this).attr('href')!="") {
    	$(this).parents("li").addClass("active");
	}
    });
</script>

<script>
  var mySwiper = new Swiper ('.swiper-container', {
    loop: true,
	autoHeight:true,
    // 如果需要分页器
    pagination: '.swiper-pagination',
    // 如果需要前进后退按钮
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
	paginationClickable:true
  })
</script>
<?php 
    \think\Hook::listen('before_body_end',$temp59f5fd1ca1fed,null,false);
 ?>
</body>
</html>
