<?php
//000000000000
 exit();?>
a:12:{s:9:"site_name";s:15:"这里有餐饮";s:14:"site_seo_title";s:15:"这里有餐饮";s:17:"site_seo_keywords";s:15:"这里有餐饮";s:20:"site_seo_description";s:15:"这里有餐饮";s:9:"site_host";s:0:"";s:9:"site_logo";s:51:"admin/20171027/447ba5083ba16171baf0ecc9c990529d.png";s:12:"site_erweima";s:51:"admin/20171027/abd96d82f9473df35fbb8f31a1b3187d.png";s:8:"site_icp";s:0:"";s:16:"site_admin_email";s:0:"";s:14:"site_analytics";s:0:"";s:7:"urlmode";s:1:"1";s:11:"html_suffix";s:0:"";}