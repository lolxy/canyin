<?php
//000000000000
 exit();?>
a:1:{s:14:"admin_password";s:0:"";}