<?php
//000000000000
 exit();?>
a:1:{s:4:"type";s:5:"Local";}