<?php	return array (
  'brand/:id' => 
  array (
    0 => 'portal/Article/index?cid=1',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'news/:id' => 
  array (
    0 => 'portal/Article/index?cid=2',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'xpss/:id' => 
  array (
    0 => 'portal/Article/index?cid=3',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'qydt/:id' => 
  array (
    0 => 'portal/Article/index?cid=4',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'lmrshg/:id' => 
  array (
    0 => 'portal/Article/index?cid=5',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'zlyysct/:id' => 
  array (
    0 => 'portal/Article/index?cid=6',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'holyfan/:id' => 
  array (
    0 => 'portal/Article/index?cid=7',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'about' => 
  array (
    0 => 'portal/Page/index?id=1',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'join' => 
  array (
    0 => 'portal/Page/index?id=2',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'brand' => 
  array (
    0 => 'portal/List/index?id=1',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'news' => 
  array (
    0 => 'portal/List/index?id=2',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'xpss' => 
  array (
    0 => 'portal/List/index?id=3',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'qydt' => 
  array (
    0 => 'portal/List/index?id=4',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'lmrshg' => 
  array (
    0 => 'portal/List/index?id=5',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'zlyysct' => 
  array (
    0 => 'portal/List/index?id=6',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'holyfan' => 
  array (
    0 => 'portal/List/index?id=7',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'detail/:id' => 
  array (
    0 => 'portal/Article/index',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
);