-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2017 年 10 月 29 日 16:17
-- 服务器版本: 5.5.53
-- PHP 版本: 5.4.45

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `hdm302080459_db`
--

-- --------------------------------------------------------

--
-- 表的结构 `cy_admin_menu`
--

CREATE TABLE IF NOT EXISTS `cy_admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父菜单id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '菜单类型;1:有界面可访问菜单,2:无界面可访问菜单,0:只作为菜单',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态;1:显示,0:不显示',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `app` varchar(15) NOT NULL DEFAULT '' COMMENT '应用名',
  `controller` varchar(30) NOT NULL DEFAULT '' COMMENT '控制器名',
  `action` varchar(30) NOT NULL DEFAULT '' COMMENT '操作名称',
  `param` varchar(50) NOT NULL DEFAULT '' COMMENT '额外参数',
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '菜单名称',
  `icon` varchar(20) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `parentid` (`parent_id`),
  KEY `model` (`controller`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='后台菜单表' AUTO_INCREMENT=162 ;

--
-- 转存表中的数据 `cy_admin_menu`
--

INSERT INTO `cy_admin_menu` (`id`, `parent_id`, `type`, `status`, `list_order`, `app`, `controller`, `action`, `param`, `name`, `icon`, `remark`) VALUES
(1, 0, 0, 0, 20, 'admin', 'Plugin', 'default', '', '插件管理', 'cloud', '插件管理'),
(2, 1, 1, 1, 10000, 'admin', 'Hook', 'index', '', '钩子管理', '', '钩子管理'),
(3, 2, 1, 0, 10000, 'admin', 'Hook', 'plugins', '', '钩子插件管理', '', '钩子插件管理'),
(4, 2, 2, 0, 10000, 'admin', 'Hook', 'pluginListOrder', '', '钩子插件排序', '', '钩子插件排序'),
(5, 2, 1, 0, 10000, 'admin', 'Hook', 'sync', '', '同步钩子', '', '同步钩子'),
(6, 0, 0, 1, 0, 'admin', 'Setting', 'default', '', '设置', 'cogs', '系统设置入口'),
(7, 6, 1, 1, 50, 'admin', 'Link', 'index', '', '友情链接', '', '友情链接管理'),
(8, 7, 1, 0, 10000, 'admin', 'Link', 'add', '', '添加友情链接', '', '添加友情链接'),
(9, 7, 2, 0, 10000, 'admin', 'Link', 'addPost', '', '添加友情链接提交保存', '', '添加友情链接提交保存'),
(10, 7, 1, 0, 10000, 'admin', 'Link', 'edit', '', '编辑友情链接', '', '编辑友情链接'),
(11, 7, 2, 0, 10000, 'admin', 'Link', 'editPost', '', '编辑友情链接提交保存', '', '编辑友情链接提交保存'),
(12, 7, 2, 0, 10000, 'admin', 'Link', 'delete', '', '删除友情链接', '', '删除友情链接'),
(13, 7, 2, 0, 10000, 'admin', 'Link', 'listOrder', '', '友情链接排序', '', '友情链接排序'),
(14, 7, 2, 0, 10000, 'admin', 'Link', 'toggle', '', '友情链接显示隐藏', '', '友情链接显示隐藏'),
(15, 6, 1, 0, 10, 'admin', 'Mailer', 'index', '', '邮箱配置', '', '邮箱配置'),
(16, 15, 2, 0, 10000, 'admin', 'Mailer', 'indexPost', '', '邮箱配置提交保存', '', '邮箱配置提交保存'),
(17, 15, 1, 0, 10000, 'admin', 'Mailer', 'template', '', '邮件模板', '', '邮件模板'),
(18, 15, 2, 0, 10000, 'admin', 'Mailer', 'templatePost', '', '邮件模板提交', '', '邮件模板提交'),
(19, 15, 1, 0, 10000, 'admin', 'Mailer', 'test', '', '邮件发送测试', '', '邮件发送测试'),
(20, 6, 1, 0, 10000, 'admin', 'Menu', 'index', '', '后台菜单', '', '后台菜单管理'),
(21, 20, 1, 0, 10000, 'admin', 'Menu', 'lists', '', '所有菜单', '', '后台所有菜单列表'),
(22, 20, 1, 0, 10000, 'admin', 'Menu', 'add', '', '后台菜单添加', '', '后台菜单添加'),
(23, 20, 2, 0, 10000, 'admin', 'Menu', 'addPost', '', '后台菜单添加提交保存', '', '后台菜单添加提交保存'),
(24, 20, 1, 0, 10000, 'admin', 'Menu', 'edit', '', '后台菜单编辑', '', '后台菜单编辑'),
(25, 20, 2, 0, 10000, 'admin', 'Menu', 'editPost', '', '后台菜单编辑提交保存', '', '后台菜单编辑提交保存'),
(26, 20, 2, 0, 10000, 'admin', 'Menu', 'delete', '', '后台菜单删除', '', '后台菜单删除'),
(27, 20, 2, 0, 10000, 'admin', 'Menu', 'listOrder', '', '后台菜单排序', '', '后台菜单排序'),
(28, 20, 1, 0, 10000, 'admin', 'Menu', 'getActions', '', '导入新后台菜单', '', '导入新后台菜单'),
(29, 6, 1, 1, 30, 'admin', 'Nav', 'index', '', '导航管理', '', '导航管理'),
(30, 29, 1, 0, 10000, 'admin', 'Nav', 'add', '', '添加导航', '', '添加导航'),
(31, 29, 2, 0, 10000, 'admin', 'Nav', 'addPost', '', '添加导航提交保存', '', '添加导航提交保存'),
(32, 29, 1, 0, 10000, 'admin', 'Nav', 'edit', '', '编辑导航', '', '编辑导航'),
(33, 29, 2, 0, 10000, 'admin', 'Nav', 'editPost', '', '编辑导航提交保存', '', '编辑导航提交保存'),
(34, 29, 2, 0, 10000, 'admin', 'Nav', 'delete', '', '删除导航', '', '删除导航'),
(35, 29, 1, 0, 10000, 'admin', 'NavMenu', 'index', '', '导航菜单', '', '导航菜单'),
(36, 35, 1, 0, 10000, 'admin', 'NavMenu', 'add', '', '添加导航菜单', '', '添加导航菜单'),
(37, 35, 2, 0, 10000, 'admin', 'NavMenu', 'addPost', '', '添加导航菜单提交保存', '', '添加导航菜单提交保存'),
(38, 35, 1, 0, 10000, 'admin', 'NavMenu', 'edit', '', '编辑导航菜单', '', '编辑导航菜单'),
(39, 35, 2, 0, 10000, 'admin', 'NavMenu', 'editPost', '', '编辑导航菜单提交保存', '', '编辑导航菜单提交保存'),
(40, 35, 2, 0, 10000, 'admin', 'NavMenu', 'delete', '', '删除导航菜单', '', '删除导航菜单'),
(41, 35, 2, 0, 10000, 'admin', 'NavMenu', 'listOrder', '', '导航菜单排序', '', '导航菜单排序'),
(42, 1, 1, 1, 10000, 'admin', 'Plugin', 'index', '', '插件列表', '', '插件列表'),
(43, 42, 2, 0, 10000, 'admin', 'Plugin', 'toggle', '', '插件启用禁用', '', '插件启用禁用'),
(44, 42, 1, 0, 10000, 'admin', 'Plugin', 'setting', '', '插件设置', '', '插件设置'),
(45, 42, 2, 0, 10000, 'admin', 'Plugin', 'settingPost', '', '插件设置提交', '', '插件设置提交'),
(46, 42, 2, 0, 10000, 'admin', 'Plugin', 'install', '', '插件安装', '', '插件安装'),
(47, 42, 2, 0, 10000, 'admin', 'Plugin', 'update', '', '插件更新', '', '插件更新'),
(48, 42, 2, 0, 10000, 'admin', 'Plugin', 'uninstall', '', '卸载插件', '', '卸载插件'),
(49, 109, 0, 1, 10000, 'admin', 'User', 'default', '', '管理组', '', '管理组'),
(50, 49, 1, 1, 10000, 'admin', 'Rbac', 'index', '', '角色管理', '', '角色管理'),
(51, 50, 1, 0, 10000, 'admin', 'Rbac', 'roleAdd', '', '添加角色', '', '添加角色'),
(52, 50, 2, 0, 10000, 'admin', 'Rbac', 'roleAddPost', '', '添加角色提交', '', '添加角色提交'),
(53, 50, 1, 0, 10000, 'admin', 'Rbac', 'roleEdit', '', '编辑角色', '', '编辑角色'),
(54, 50, 2, 0, 10000, 'admin', 'Rbac', 'roleEditPost', '', '编辑角色提交', '', '编辑角色提交'),
(55, 50, 2, 0, 10000, 'admin', 'Rbac', 'roleDelete', '', '删除角色', '', '删除角色'),
(56, 50, 1, 0, 10000, 'admin', 'Rbac', 'authorize', '', '设置角色权限', '', '设置角色权限'),
(57, 50, 2, 0, 10000, 'admin', 'Rbac', 'authorizePost', '', '角色授权提交', '', '角色授权提交'),
(58, 0, 1, 0, 10000, 'admin', 'RecycleBin', 'index', '', '回收站', '', '回收站'),
(59, 58, 2, 0, 10000, 'admin', 'RecycleBin', 'restore', '', '回收站还原', '', '回收站还原'),
(60, 58, 2, 0, 10000, 'admin', 'RecycleBin', 'delete', '', '回收站彻底删除', '', '回收站彻底删除'),
(61, 6, 1, 1, 10000, 'admin', 'Route', 'index', '', 'URL美化', '', 'URL规则管理'),
(62, 61, 1, 0, 10000, 'admin', 'Route', 'add', '', '添加路由规则', '', '添加路由规则'),
(63, 61, 2, 0, 10000, 'admin', 'Route', 'addPost', '', '添加路由规则提交', '', '添加路由规则提交'),
(64, 61, 1, 0, 10000, 'admin', 'Route', 'edit', '', '路由规则编辑', '', '路由规则编辑'),
(65, 61, 2, 0, 10000, 'admin', 'Route', 'editPost', '', '路由规则编辑提交', '', '路由规则编辑提交'),
(66, 61, 2, 0, 10000, 'admin', 'Route', 'delete', '', '路由规则删除', '', '路由规则删除'),
(67, 61, 2, 0, 10000, 'admin', 'Route', 'ban', '', '路由规则禁用', '', '路由规则禁用'),
(68, 61, 2, 0, 10000, 'admin', 'Route', 'open', '', '路由规则启用', '', '路由规则启用'),
(69, 61, 2, 0, 10000, 'admin', 'Route', 'listOrder', '', '路由规则排序', '', '路由规则排序'),
(70, 61, 1, 0, 10000, 'admin', 'Route', 'select', '', '选择URL', '', '选择URL'),
(71, 6, 1, 1, 0, 'admin', 'Setting', 'site', '', '网站信息', '', '网站信息'),
(72, 71, 2, 0, 10000, 'admin', 'Setting', 'sitePost', '', '网站信息设置提交', '', '网站信息设置提交'),
(73, 6, 1, 0, 10000, 'admin', 'Setting', 'password', '', '密码修改', '', '密码修改'),
(74, 73, 2, 0, 10000, 'admin', 'Setting', 'passwordPost', '', '密码修改提交', '', '密码修改提交'),
(75, 6, 1, 1, 10000, 'admin', 'Setting', 'upload', '', '上传设置', '', '上传设置'),
(76, 75, 2, 0, 10000, 'admin', 'Setting', 'uploadPost', '', '上传设置提交', '', '上传设置提交'),
(77, 6, 1, 0, 10000, 'admin', 'Setting', 'clearCache', '', '清除缓存', '', '清除缓存'),
(78, 6, 1, 1, 40, 'admin', 'Slide', 'index', '', '幻灯片管理', '', '幻灯片管理'),
(79, 78, 1, 0, 10000, 'admin', 'Slide', 'add', '', '添加幻灯片', '', '添加幻灯片'),
(80, 78, 2, 0, 10000, 'admin', 'Slide', 'addPost', '', '添加幻灯片提交', '', '添加幻灯片提交'),
(81, 78, 1, 0, 10000, 'admin', 'Slide', 'edit', '', '编辑幻灯片', '', '编辑幻灯片'),
(82, 78, 2, 0, 10000, 'admin', 'Slide', 'editPost', '', '编辑幻灯片提交', '', '编辑幻灯片提交'),
(83, 78, 2, 0, 10000, 'admin', 'Slide', 'delete', '', '删除幻灯片', '', '删除幻灯片'),
(84, 78, 1, 0, 10000, 'admin', 'SlideItem', 'index', '', '幻灯片页面列表', '', '幻灯片页面列表'),
(85, 84, 1, 0, 10000, 'admin', 'SlideItem', 'add', '', '幻灯片页面添加', '', '幻灯片页面添加'),
(86, 84, 2, 0, 10000, 'admin', 'SlideItem', 'addPost', '', '幻灯片页面添加提交', '', '幻灯片页面添加提交'),
(87, 84, 1, 0, 10000, 'admin', 'SlideItem', 'edit', '', '幻灯片页面编辑', '', '幻灯片页面编辑'),
(88, 84, 2, 0, 10000, 'admin', 'SlideItem', 'editPost', '', '幻灯片页面编辑提交', '', '幻灯片页面编辑提交'),
(89, 84, 2, 0, 10000, 'admin', 'SlideItem', 'delete', '', '幻灯片页面删除', '', '幻灯片页面删除'),
(90, 84, 2, 0, 10000, 'admin', 'SlideItem', 'ban', '', '幻灯片页面隐藏', '', '幻灯片页面隐藏'),
(91, 84, 2, 0, 10000, 'admin', 'SlideItem', 'cancelBan', '', '幻灯片页面显示', '', '幻灯片页面显示'),
(92, 84, 2, 0, 10000, 'admin', 'SlideItem', 'listOrder', '', '幻灯片页面排序', '', '幻灯片页面排序'),
(93, 6, 1, 0, 10000, 'admin', 'Storage', 'index', '', '文件存储', '', '文件存储'),
(94, 93, 2, 0, 10000, 'admin', 'Storage', 'settingPost', '', '文件存储设置提交', '', '文件存储设置提交'),
(95, 6, 1, 1, 20, 'admin', 'Theme', 'index', '', '模板管理', '', '模板管理'),
(96, 95, 1, 0, 10000, 'admin', 'Theme', 'install', '', '安装模板', '', '安装模板'),
(97, 95, 2, 0, 10000, 'admin', 'Theme', 'uninstall', '', '卸载模板', '', '卸载模板'),
(98, 95, 2, 0, 10000, 'admin', 'Theme', 'installTheme', '', '模板安装', '', '模板安装'),
(99, 95, 2, 0, 10000, 'admin', 'Theme', 'update', '', '模板更新', '', '模板更新'),
(100, 95, 2, 0, 10000, 'admin', 'Theme', 'active', '', '启用模板', '', '启用模板'),
(101, 95, 1, 0, 10000, 'admin', 'Theme', 'files', '', '模板文件列表', '', '启用模板'),
(102, 95, 1, 0, 10000, 'admin', 'Theme', 'fileSetting', '', '模板文件设置', '', '模板文件设置'),
(103, 95, 1, 0, 10000, 'admin', 'Theme', 'fileArrayData', '', '模板文件数组数据列表', '', '模板文件数组数据列表'),
(104, 95, 2, 0, 10000, 'admin', 'Theme', 'fileArrayDataEdit', '', '模板文件数组数据添加编辑', '', '模板文件数组数据添加编辑'),
(105, 95, 2, 0, 10000, 'admin', 'Theme', 'fileArrayDataEditPost', '', '模板文件数组数据添加编辑提交保存', '', '模板文件数组数据添加编辑提交保存'),
(106, 95, 2, 0, 10000, 'admin', 'Theme', 'fileArrayDataDelete', '', '模板文件数组数据删除', '', '模板文件数组数据删除'),
(107, 95, 2, 0, 10000, 'admin', 'Theme', 'settingPost', '', '模板文件编辑提交保存', '', '模板文件编辑提交保存'),
(108, 95, 1, 0, 10000, 'admin', 'Theme', 'dataSource', '', '模板文件设置数据源', '', '模板文件设置数据源'),
(109, 0, 0, 1, 10, 'user', 'AdminIndex', 'default', '', '用户管理', 'group', '用户管理'),
(110, 49, 1, 1, 10000, 'admin', 'User', 'index', '', '管理员', '', '管理员管理'),
(111, 110, 1, 0, 10000, 'admin', 'User', 'add', '', '管理员添加', '', '管理员添加'),
(112, 110, 2, 0, 10000, 'admin', 'User', 'addPost', '', '管理员添加提交', '', '管理员添加提交'),
(113, 110, 1, 0, 10000, 'admin', 'User', 'edit', '', '管理员编辑', '', '管理员编辑'),
(114, 110, 2, 0, 10000, 'admin', 'User', 'editPost', '', '管理员编辑提交', '', '管理员编辑提交'),
(115, 110, 1, 0, 10000, 'admin', 'User', 'userInfo', '', '个人信息', '', '管理员个人信息修改'),
(116, 110, 2, 0, 10000, 'admin', 'User', 'userInfoPost', '', '管理员个人信息修改提交', '', '管理员个人信息修改提交'),
(117, 110, 2, 0, 10000, 'admin', 'User', 'delete', '', '管理员删除', '', '管理员删除'),
(118, 110, 2, 0, 10000, 'admin', 'User', 'ban', '', '停用管理员', '', '停用管理员'),
(119, 110, 2, 0, 10000, 'admin', 'User', 'cancelBan', '', '启用管理员', '', '启用管理员'),
(120, 0, 0, 1, 30, 'portal', 'AdminIndex', 'default', '', '门户管理', 'th', '门户管理'),
(121, 120, 1, 1, 10000, 'portal', 'AdminArticle', 'index', '', '文章管理', '', '文章列表'),
(122, 121, 1, 0, 10000, 'portal', 'AdminArticle', 'add', '', '添加文章', '', '添加文章'),
(123, 121, 2, 0, 10000, 'portal', 'AdminArticle', 'addPost', '', '添加文章提交', '', '添加文章提交'),
(124, 121, 1, 0, 10000, 'portal', 'AdminArticle', 'edit', '', '编辑文章', '', '编辑文章'),
(125, 121, 2, 0, 10000, 'portal', 'AdminArticle', 'editPost', '', '编辑文章提交', '', '编辑文章提交'),
(126, 121, 2, 0, 10000, 'portal', 'AdminArticle', 'delete', '', '文章删除', '', '文章删除'),
(127, 121, 2, 0, 10000, 'portal', 'AdminArticle', 'publish', '', '文章发布', '', '文章发布'),
(128, 121, 2, 0, 10000, 'portal', 'AdminArticle', 'top', '', '文章置顶', '', '文章置顶'),
(129, 121, 2, 0, 10000, 'portal', 'AdminArticle', 'recommend', '', '文章推荐', '', '文章推荐'),
(130, 121, 2, 0, 10000, 'portal', 'AdminArticle', 'listOrder', '', '文章排序', '', '文章排序'),
(131, 120, 1, 1, 10000, 'portal', 'AdminCategory', 'index', '', '分类管理', '', '文章分类列表'),
(132, 131, 1, 0, 10000, 'portal', 'AdminCategory', 'add', '', '添加文章分类', '', '添加文章分类'),
(133, 131, 2, 0, 10000, 'portal', 'AdminCategory', 'addPost', '', '添加文章分类提交', '', '添加文章分类提交'),
(134, 131, 1, 0, 10000, 'portal', 'AdminCategory', 'edit', '', '编辑文章分类', '', '编辑文章分类'),
(135, 131, 2, 0, 10000, 'portal', 'AdminCategory', 'editPost', '', '编辑文章分类提交', '', '编辑文章分类提交'),
(136, 131, 1, 0, 10000, 'portal', 'AdminCategory', 'select', '', '文章分类选择对话框', '', '文章分类选择对话框'),
(137, 131, 2, 0, 10000, 'portal', 'AdminCategory', 'listOrder', '', '文章分类排序', '', '文章分类排序'),
(138, 131, 2, 0, 10000, 'portal', 'AdminCategory', 'delete', '', '删除文章分类', '', '删除文章分类'),
(139, 120, 1, 1, 10000, 'portal', 'AdminPage', 'index', '', '页面管理', '', '页面管理'),
(140, 139, 1, 0, 10000, 'portal', 'AdminPage', 'add', '', '添加页面', '', '添加页面'),
(141, 139, 2, 0, 10000, 'portal', 'AdminPage', 'addPost', '', '添加页面提交', '', '添加页面提交'),
(142, 139, 1, 0, 10000, 'portal', 'AdminPage', 'edit', '', '编辑页面', '', '编辑页面'),
(143, 139, 2, 0, 10000, 'portal', 'AdminPage', 'editPost', '', '编辑页面提交', '', '编辑页面提交'),
(144, 139, 2, 0, 10000, 'portal', 'AdminPage', 'delete', '', '删除页面', '', '删除页面'),
(145, 120, 1, 1, 10000, 'portal', 'AdminTag', 'index', '', '文章标签', '', '文章标签'),
(146, 145, 1, 0, 10000, 'portal', 'AdminTag', 'add', '', '添加文章标签', '', '添加文章标签'),
(147, 145, 2, 0, 10000, 'portal', 'AdminTag', 'addPost', '', '添加文章标签提交', '', '添加文章标签提交'),
(148, 145, 2, 0, 10000, 'portal', 'AdminTag', 'upStatus', '', '更新标签状态', '', '更新标签状态'),
(149, 145, 2, 0, 10000, 'portal', 'AdminTag', 'delete', '', '删除文章标签', '', '删除文章标签'),
(150, 0, 1, 0, 10000, 'user', 'AdminAsset', 'index', '', '资源管理', 'file', '资源管理列表'),
(151, 150, 2, 0, 10000, 'user', 'AdminAsset', 'delete', '', '删除文件', '', '删除文件'),
(152, 109, 0, 0, 10000, 'user', 'AdminIndex', 'default1', '', '用户组', '', '用户组'),
(153, 152, 1, 1, 10000, 'user', 'AdminIndex', 'index', '', '本站用户', '', '本站用户'),
(154, 153, 2, 0, 10000, 'user', 'AdminIndex', 'ban', '', '本站用户拉黑', '', '本站用户拉黑'),
(155, 153, 2, 0, 10000, 'user', 'AdminIndex', 'cancelBan', '', '本站用户启用', '', '本站用户启用'),
(156, 152, 1, 1, 10000, 'user', 'AdminOauth', 'index', '', '第三方用户', '', '第三方用户'),
(157, 156, 2, 0, 10000, 'user', 'AdminOauth', 'delete', '', '删除第三方用户绑定', '', '删除第三方用户绑定'),
(158, 6, 1, 0, 10000, 'user', 'AdminUserAction', 'index', '', '用户操作管理', '', '用户操作管理'),
(159, 158, 1, 0, 10000, 'user', 'AdminUserAction', 'edit', '', '编辑用户操作', '', '编辑用户操作'),
(160, 158, 2, 0, 10000, 'user', 'AdminUserAction', 'editPost', '', '编辑用户操作提交', '', '编辑用户操作提交'),
(161, 158, 1, 0, 10000, 'user', 'AdminUserAction', 'sync', '', '同步用户操作', '', '同步用户操作');

-- --------------------------------------------------------

--
-- 表的结构 `cy_asset`
--

CREATE TABLE IF NOT EXISTS `cy_asset` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `file_size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小,单位B',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:可用,0:不可用',
  `download_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `file_key` varchar(64) NOT NULL DEFAULT '' COMMENT '文件惟一码',
  `filename` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '文件名',
  `file_path` varchar(100) NOT NULL DEFAULT '' COMMENT '文件路径,相对于upload目录,可以为url',
  `file_md5` varchar(32) NOT NULL DEFAULT '' COMMENT '文件md5值',
  `file_sha1` varchar(40) NOT NULL DEFAULT '',
  `suffix` varchar(10) NOT NULL DEFAULT '' COMMENT '文件后缀名,不包括点',
  `more` text COMMENT '其它详细信息,JSON格式',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='资源表' AUTO_INCREMENT=53 ;

--
-- 转存表中的数据 `cy_asset`
--

INSERT INTO `cy_asset` (`id`, `user_id`, `file_size`, `create_time`, `status`, `download_times`, `file_key`, `filename`, `file_path`, `file_md5`, `file_sha1`, `suffix`, `more`) VALUES
(1, 1, 591945, 1508861203, 1, 0, '66c449b772a6306a09861793ed24fb791fde8d9a9e3d0414f6da8e5410628c3d', 'banner.png', 'admin/20171025/d91699ad82e9cbee3bd173438a61113d.png', '66c449b772a6306a09861793ed24fb79', '42eefdd38671ea636ef5f5d7cd83f52710c72696', 'png', NULL),
(2, 1, 3077, 1509110919, 1, 0, '0607fdab36ee08f7697b66b4f8878eceb504f1deac84dd7f6c96b764860df7fe', 'logo.png', 'admin/20171027/447ba5083ba16171baf0ecc9c990529d.png', '0607fdab36ee08f7697b66b4f8878ece', '7527b3489992d3b21473cf85a090f73970c82f34', 'png', NULL),
(3, 1, 16742, 1509111207, 1, 0, '54ec14fc832fe3b3f9f3b1c0dc8fd392b618469e577890d169d481e51c74c1cb', 'recommend_hover.png', 'admin/20171027/abd96d82f9473df35fbb8f31a1b3187d.png', '54ec14fc832fe3b3f9f3b1c0dc8fd392', 'ccf1c58a0ddcd83b6ad224d70fece5fde5370209', 'png', NULL),
(4, 1, 31737, 1509111985, 1, 0, 'ffa7adb3ffcbcf2814aa2f30a8cfbe661be49f366e725bff98619e1cade8db7d', 'about_minmap.png', 'admin/20171027/d556ee025a86c1089f48a7cf39c8ea6a.png', 'ffa7adb3ffcbcf2814aa2f30a8cfbe66', '3809a34c81557d9f7423655e008090b388c9d42b', 'png', NULL),
(5, 1, 61128, 1509114927, 1, 0, '293b83b6b8868e0ed6402cedb7c25ac67f638f05199ad6f154a33ec059137417', 'recommend_1.png', 'admin/20171027/cb1276fabfe49d3cf4bc173e3e58670f.png', '293b83b6b8868e0ed6402cedb7c25ac6', '203826b331c13bceede369439837bfef5aa60800', 'png', NULL),
(6, 1, 70265, 1509114955, 1, 0, '3ca505cc63dfbe8316f38209d6627dba53d01ea6888f3a94cd28733f5a390462', 'recommend_2.png', 'admin/20171027/92a88d68b7d912c014c060b69e1fea02.png', '3ca505cc63dfbe8316f38209d6627dba', '9aef0f0b38e186eda6b08f004a46416cd25c67f0', 'png', NULL),
(7, 1, 56009, 1509114979, 1, 0, '6fd96a7fa12dd905cde920da6d0dad3bda081b2420f795fd7f4bfbf25233629f', 'recommend_3.png', 'admin/20171027/e987b1049d914dbe6557673b63d2e014.png', '6fd96a7fa12dd905cde920da6d0dad3b', 'bf76b569ecad1fbb98218bdd9fc4a45e00711088', 'png', NULL),
(8, 1, 34921, 1509187819, 1, 0, 'c890a99d68226590a9aef0616522b668afb54ab7acebde05bf0515bde575a0a2', 'brand1.png', 'admin/20171028/b7bc341f4cc542522118abde7da83a0f.png', 'c890a99d68226590a9aef0616522b668', '5dd9b3bdecbd77168172011776c304e04ecd51df', 'png', NULL),
(9, 1, 42479, 1509187829, 1, 0, '2714eda9369c3ef40fc8afe5523fd4e188bd42d76b7817b1208c4b40dbe93756', 'brand2.png', 'admin/20171028/ad38a610db48a0b191e5cea341cd06fa.png', '2714eda9369c3ef40fc8afe5523fd4e1', 'efbe007e9fb020720c64197737e80f696f1d287e', 'png', NULL),
(10, 1, 1350, 1509187860, 1, 0, 'a6cffa53c3e1e524b603bd3337688226ed21878b6dca0ad8c32d6628a3da3b02', 'brandt1.png', 'admin/20171028/2045d89c7b21a2be93f0bf069e1538b1.png', 'a6cffa53c3e1e524b603bd3337688226', '08ce6cc7d11d3bb2e0772d2322760ad9d5ffb15b', 'png', NULL),
(11, 1, 1413, 1509187934, 1, 0, '030a3690f5b27b6a438d1089dc443f0a54ba0b448882ecb16a64875311549cc4', 'brandt2.png', 'admin/20171028/179212cdbbdabbf98562285f4da060d6.png', '030a3690f5b27b6a438d1089dc443f0a', 'a2c271975d2e481e0459c41d4c5ff8c189530d49', 'png', NULL),
(12, 1, 1732, 1509188002, 1, 0, 'ce31d4ec8fc246d30a2279e143fc621756f36871f39d4ddc522c8b0eff054dab', 'brandt3.png', 'admin/20171028/40ea013875f97b1a7688bfea3af91d70.png', 'ce31d4ec8fc246d30a2279e143fc6217', '97ac18873c9af36a9487d6d883e913cbb38f287d', 'png', NULL),
(13, 1, 39742, 1509188011, 1, 0, '7bc62a3fe57e3bbba9f4a118c11885607d40c338055be2cabbd0fe74ed1dd97d', 'brand3.png', 'admin/20171028/750ef4388ccf76682156daa8130096c0.png', '7bc62a3fe57e3bbba9f4a118c1188560', '69ae9726354293435d1e0ab56b645832ca8457ff', 'png', NULL),
(14, 1, 99870, 1509238181, 1, 0, '585aa073cc36dbbc603241f01b24e522480d9c44a875f2c769909bc37ef7c3bb', 'newsthumb.png', 'portal/20171029/dc44367760930ea5766b65178b46489b.png', '585aa073cc36dbbc603241f01b24e522', '1f8ba3cd47b89ea9835fa9242b77419267ab5f5c', 'png', NULL),
(15, 1, 118472, 1509246488, 1, 0, '55044939242b580f9056eaa7341e6c3f1f84e117077b45308b4e425d1182b653', 'about_recommond.png', 'admin/20171029/63c7e3f8a8bf58a0545232e1e7dee2e6.png', '55044939242b580f9056eaa7341e6c3f', '71cfb2143ea7bc08ce0c9266f799f838c2919f01', 'png', NULL),
(16, 1, 386138, 1509246605, 1, 0, '0e00ce34529d88fdace22a75cb0ab769694d1d321453bd852f028ac86bdc015e', 'about_licheng.png', 'admin/20171029/2e5788bac72b2ce6239ce1849099d85c.png', '0e00ce34529d88fdace22a75cb0ab769', '99fb7cd43e78e1b8860d3f107d9a36c6d1984d65', 'png', NULL),
(17, 1, 140846, 1509246896, 1, 0, 'b1f11a8e7e6a72796aa40d71ff728cab31f1a5e2bdb999e39220897bbefd215c', 'about_td1.jpg', 'admin/20171029/8b5486fb0caf56aeae1fe41ab33f58c2.jpg', 'b1f11a8e7e6a72796aa40d71ff728cab', '18f056728b31dcf661bdb52b981db2987e75cddd', 'jpg', NULL),
(18, 1, 96708, 1509246932, 1, 0, '9b2a44e1d79c87623571f86b8c2f93cfb6886f6546aadba04d879440ff479551', 'about_td2.jpg', 'admin/20171029/79305a3918c7f6a2044f58576eca9d89.jpg', '9b2a44e1d79c87623571f86b8c2f93cf', 'c7ab549757306785dbcf1a250e6b1e5ad9e79f26', 'jpg', NULL),
(19, 1, 89158, 1509246987, 1, 0, '554db4b040402b331250814ff398030f528f16cd6dbaad085b138e4269b0feac', 'about_td3.jpg', 'admin/20171029/c206f8501714d7c3cdbe565838a973eb.jpg', '554db4b040402b331250814ff398030f', 'bac6a0037ed69cb0227d823a78d64b1b022966d5', 'jpg', NULL),
(20, 1, 34875, 1509247148, 1, 0, 'dbd7ebaa6a823def4de12df9fa4b1a0e3101467c5be7285589ab81e442555e91', 'about_img1.png', 'admin/20171029/cf94769b6bc381fa8d8add144d853575.png', 'dbd7ebaa6a823def4de12df9fa4b1a0e', '87392ad735f67035e2f27d4fa6bf52a925d74ad4', 'png', NULL),
(21, 1, 51137, 1509247177, 1, 0, '5641a55837c4200d4212f10a8f406c39f32058aaf40d50c4a45e17cdf2750560', 'about_img2.png', 'admin/20171029/c6e6341e5a3cbffb7938fbd01f2d8fdc.png', '5641a55837c4200d4212f10a8f406c39', '8bba051fdc69f08d85169c7d7b18fe86b9ef5801', 'png', NULL),
(22, 1, 41757, 1509247205, 1, 0, 'dd96d161b28675abb6f88df712f1584e3062abe190b4eb211304dce73ec5982e', 'about_img3.png', 'admin/20171029/8277e9bd353205cb24ef1393b90c51b0.png', 'dd96d161b28675abb6f88df712f1584e', '9d914a4f66c75ca873d358ad2838daabf9e80d2e', 'png', NULL),
(23, 1, 409177, 1509270320, 1, 0, '05287843d8a5159dc1f357c07970b013f377fe733186d35b6c34b95a279c4f77', 'brand_banner.png', 'admin/20171029/ffbcbabaa7280cda69534bfac0327661.png', '05287843d8a5159dc1f357c07970b013', 'b7630dfcb8d76f64f6378ed6599a85f27f54d28d', 'png', NULL),
(24, 1, 69048, 1509271961, 1, 0, '19500e3fe8dcb6239eae8c4b50b03568283d8aedcdeb774b231b253a7edcec03', 'brand_main_img.png', 'admin/20171029/92e4b0f9ade6266b3c13a31b59e3efb6.png', '19500e3fe8dcb6239eae8c4b50b03568', 'aae336263c1b48a46845acbbc69e85069568df96', 'png', NULL),
(25, 1, 3083, 1509271973, 1, 0, '58a776e737f187b6df88d3497b43491e11a12fd327130b8b9d940094a4006b6d', 'brand_main_logo.png', 'admin/20171029/dfabae926653d7d5fae98b1e5b2bb8ac.png', '58a776e737f187b6df88d3497b43491e', '9ad6bc15585adda011fcc4a3387ae156441bd2a4', 'png', NULL),
(26, 1, 158712, 1509272003, 1, 0, '8c64f717a17b78c2bd451a44c5fc8f0b3dadb8c0a096d937648d5ac6a7c047e0', 'brand_thumb1.png', 'admin/20171029/1fb88dc4b8efb2cc0c47016c56de7822.png', '8c64f717a17b78c2bd451a44c5fc8f0b', '61343134fd3f0f956611fe69feab2d2f3f3120fa', 'png', NULL),
(27, 1, 162626, 1509272027, 1, 0, '4c5b9912254fb075f679ce9bd819d1c7d49fc7267c15cfcd14f524988bcedeeb', 'brand_thumb2.png', 'admin/20171029/45c6ca4a5a2998ab20a4a5382fc1cafa.png', '4c5b9912254fb075f679ce9bd819d1c7', '7ae2d3358265b1c2d54ddd969001295c346a831d', 'png', NULL),
(28, 1, 167770, 1509272062, 1, 0, '42e95683d52d89b28672df8a694fb5985631c82ccb9976cea6c98225e3531602', 'brand_thumb3.png', 'admin/20171029/b6bb274a401fac6a711d57774359394f.png', '42e95683d52d89b28672df8a694fb598', '5eeeb60ff3cd84c6a8d8ec9ff25c571bf55dbabf', 'png', NULL),
(29, 1, 83550, 1509272089, 1, 0, '3da23189e8893a59438e29a059b67b601a38dadb2aec3a931b5051d271f95d32', 'brand_xx1.png', 'admin/20171029/abd2b61f44cae79827f08c360a253bfe.png', '3da23189e8893a59438e29a059b67b60', 'a6fb2445b2b22879600d35d6bda219cb9d961105', 'png', NULL),
(30, 1, 98130, 1509272105, 1, 0, 'b6b553d4e81b13523ea7b53f38989ddb31f3831104546f851189363d9743b0d2', 'brand_xx2.png', 'admin/20171029/3e5719548e9ef906494e8f89c63e98ae.png', 'b6b553d4e81b13523ea7b53f38989ddb', '8e81abc00d9a34488470462ee9d1436decb57e67', 'png', NULL),
(31, 1, 337397, 1509280373, 1, 0, '7770f547a00659b9736bc2ace24cfe06ea5d0937430c076fa0116ee2369aafb0', 'zs_banner.png', 'admin/20171029/7660d9004f2443d89450cac324760ffc.png', '7770f547a00659b9736bc2ace24cfe06', 'f716bafb489498afcbcc685dbec7ce78cb0808b9', 'png', NULL),
(32, 1, 89489, 1509280390, 1, 0, '2bdec040127a8444e75bc5f5b29f83983456e5af966a6f2b3680a7967d1e9b92', 'zs_img01.jpg', 'admin/20171029/98d1eeb44d817aed57eb32dc56bb69d1.jpg', '2bdec040127a8444e75bc5f5b29f8398', '2a6cff0b1a2601c96b559dda2f1cd83591e5c399', 'jpg', NULL),
(33, 1, 92730, 1509280413, 1, 0, '56a39e8fc3a6eccb972961b98d2fa17ebcfcb20fc0e2227427f4a08dd0a4d991', 'zs_img2.jpg', 'admin/20171029/77ddc38f69bdf56a3293ef48a4dea269.jpg', '56a39e8fc3a6eccb972961b98d2fa17e', 'cebcc14ab8fa39698316fbee5f92b83a8c478857', 'jpg', NULL),
(34, 1, 78330, 1509280423, 1, 0, '030a70cc9a6f9cd33d086fe316c948b469ec3b0f423789e8de540f5fb0b3253f', 'zs_img1.jpg', 'admin/20171029/84c67eb2421e0e843677bf2cbd20f9c5.jpg', '030a70cc9a6f9cd33d086fe316c948b4', '7123513472567db048645f1178be847876373840', 'jpg', NULL),
(35, 1, 329731, 1509280646, 1, 0, '13cea51be938db292b6ab8c5c7ae6aef0cdb8d93bf250b6636852a0f8c190048', 'zs_jmys1.png', 'admin/20171029/342247ca35acdd3176c09f940952ee3f.png', '13cea51be938db292b6ab8c5c7ae6aef', '1c58a37bcb29ffa61540de766274952bee9f98b5', 'png', NULL),
(36, 1, 21215, 1509280656, 1, 0, 'c8bf27004ac71e24d53537dcd48e1654ad99c50b3bb0cb3a11e1a0ad03a183f8', 'zs_jmys1_hover.png', 'admin/20171029/b135e8db5e3f7c2322df048c19832c5a.png', 'c8bf27004ac71e24d53537dcd48e1654', '40eca66df220bed5f6b02de59873ac2e6fcc50b5', 'png', NULL),
(37, 1, 350774, 1509280671, 1, 0, 'a30c03ffdc169bee592edb30586a46d1a387bd92d9773f7f6274fb77e9bb0d0a', 'zs_jmys2.png', 'admin/20171029/294323718da81225b06a6f0a0832ff98.png', 'a30c03ffdc169bee592edb30586a46d1', '558dc31f76bdbc47655919c2a58f6a9bd9f40214', 'png', NULL),
(38, 1, 27986, 1509280679, 1, 0, '91006aed8274b82c517ec3d88908674cd5ce9c6a214363f06887cb324f8a800a', 'zs_jmys2_hover.png', 'admin/20171029/9ef497aca2494352051be1307ee08ebb.png', '91006aed8274b82c517ec3d88908674c', '97737bdca314c2e5a7bbe17fb450a918406cfa7e', 'png', NULL),
(39, 1, 356356, 1509280692, 1, 0, '84a204f77701d29476b9358faa4ed19503682f6a9024391d4438af0cb92946a3', 'zs_jmys3.png', 'admin/20171029/9a14c6823275fada13878949ee48d9da.png', '84a204f77701d29476b9358faa4ed195', '0f8d18ef2f470043bb9a783037b2fed93e45cba9', 'png', NULL),
(40, 1, 21953, 1509280704, 1, 0, '0d4d6c34686910033766e60750ee8cb0cdcb7ada95730fb5185726c7d6728ef4', 'zs_jmys3_hover.png', 'admin/20171029/295b87404db15f74aac5f374ecdae421.png', '0d4d6c34686910033766e60750ee8cb0', '168dc9f6b3cb6651bf45309abaa75b416ce5ceed', 'png', NULL),
(41, 1, 2728, 1509280777, 1, 0, '09dfa524409817631d562b081e899bde4fb60404b66b24a75102621e4e663693', 'ticon1.png', 'admin/20171029/3fe9a4751431fee7cce890ccd4118ffd.png', '09dfa524409817631d562b081e899bde', '9e1572cc5c6cd72d53393e46364e3fdf1f1c3a3c', 'png', NULL),
(42, 1, 62089, 1509280796, 1, 0, '52814451ce02621b878fb18649b1060e352deee62f49f524c20719b0bae66572', 'zs_zcbz1.png', 'admin/20171029/25f3e7ded2ed56861c39083e79c7bfcf.png', '52814451ce02621b878fb18649b1060e', '701096419e654ebea644ba16cc00a57d4871a8dd', 'png', NULL),
(43, 1, 3170, 1509280811, 1, 0, '12e9bbb1fef4faca4bc3193f62a643110c5f64c78e875c4e859c139373c5ba66', 'ticon2.png', 'admin/20171029/81cab537ba135373bce570d3f7252712.png', '12e9bbb1fef4faca4bc3193f62a64311', '8e21c485f9188b52ec9b1bfa17ca4a62ef62c86e', 'png', NULL),
(44, 1, 94942, 1509280818, 1, 0, 'cddb82758e6fcb1b72598020fa120b4debc34f04417c3e6e810856d828e8a376', 'zs_zcbz2.png', 'admin/20171029/f28e5afb413fbf308a6942bbee6d79b9.png', 'cddb82758e6fcb1b72598020fa120b4d', '1b6a28ad581b5446876651e6cdf69aaf2d293b9e', 'png', NULL),
(45, 1, 2780, 1509280843, 1, 0, '369bd0ca2d61f8918c9b97328a6cbce9df92056a5528ad3e338bf919256384b8', 'ticon3.png', 'admin/20171029/a1ad5b2d77fa2295101008c1613a8c9e.png', '369bd0ca2d61f8918c9b97328a6cbce9', '2097d46cba14ed5d44a823f82ad79535b170d6b2', 'png', NULL),
(46, 1, 86609, 1509280850, 1, 0, '0efa4df8082ede7237791417629c1f0a8eb53ceee6536b2cc7771aac4cce31ab', 'zs_zcbz3.png', 'admin/20171029/c75fe7a45bc16af2b95910e410676bc2.png', '0efa4df8082ede7237791417629c1f0a', 'db732f3389dc8cb3654b292534ddff5d4130d99a', 'png', NULL),
(47, 1, 1649, 1509280883, 1, 0, '68dd3ab4b3295fc5b5e37dd7ff66d1bcbd207b1e28deaebd695d1a8ebc85cee1', 'zs_jmtj_icon1.png', 'admin/20171029/880e9eb9fd8f602b707042ff446b98b7.png', '68dd3ab4b3295fc5b5e37dd7ff66d1bc', '1d90464cb7f9d58c2eed3fdfe3edbb0304ed47e3', 'png', NULL),
(48, 1, 1003, 1509280903, 1, 0, '0663e30819db52f0703cfe10e6e663cd655a5fe52ef7d2e6f06e94793c5fac5d', 'zs_jmtj_icon2.png', 'admin/20171029/4d8545415b016811df8590158d90a381.png', '0663e30819db52f0703cfe10e6e663cd', '3ddf875990340e7aa4afb1d47258b47a57046d87', 'png', NULL),
(49, 1, 1902, 1509280918, 1, 0, '083f7b7e9a1d975ecccc3331f37f5de2916b2267e9d9ebac1e011d317a604406', 'zs_jmtj_icon3.png', 'admin/20171029/9efe4ba4dcd29f72a53b8e986b08ce48.png', '083f7b7e9a1d975ecccc3331f37f5de2', '791ce5651d8bedff2eb20a3c0d1d898fe1e6381d', 'png', NULL),
(50, 1, 113332, 1509280970, 1, 0, 'b7105ef1f42c49a4a8a03e527128853bf79d0b9454ea077529508a05d3b7067a', 'zs_jmlc_left.png', 'admin/20171029/fc88a7e308e07e47ca1d15b9b1e93b9c.png', 'b7105ef1f42c49a4a8a03e527128853b', '5f3d75596c9ee792cdc5e5563862e44e11770166', 'png', NULL),
(51, 1, 23724, 1509280978, 1, 0, '3b4cb997805d4024db680689fa4e0e086db71e282e0a628c50e685f87b593028', 'zs_jmlc_right.png', 'admin/20171029/58e3d9a05dcb9200a0cc4c81d4059788.png', '3b4cb997805d4024db680689fa4e0e08', '60c405b37e76568dcee99c241fe4b59024b7d0c7', 'png', NULL),
(52, 1, 1969, 1509283847, 1, 0, '025e9d5340d78ffb1598742ce29bfba26221b341d21bd4b4bdd7121031a6a5cb', 'zs_jmtj_icon4.png', 'admin/20171029/2ce4bec5643cc3bdaa897d97a5b28b70.png', '025e9d5340d78ffb1598742ce29bfba2', '72f4ec3aea1938f13176e9fdd2702971f3f0b06f', 'png', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `cy_auth_access`
--

CREATE TABLE IF NOT EXISTS `cy_auth_access` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL COMMENT '角色',
  `rule_name` varchar(100) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识,全小写',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '权限规则分类,请加应用前缀,如admin_',
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  KEY `rule_name` (`rule_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限授权表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cy_auth_rule`
--

CREATE TABLE IF NOT EXISTS `cy_auth_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `app` varchar(15) NOT NULL COMMENT '规则所属module',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '权限规则分类，请加应用前缀,如admin_',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识,全小写',
  `param` varchar(100) NOT NULL DEFAULT '' COMMENT '额外url参数',
  `title` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '规则描述',
  `condition` varchar(200) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`) USING BTREE,
  KEY `module` (`app`,`status`,`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='权限规则表' AUTO_INCREMENT=162 ;

--
-- 转存表中的数据 `cy_auth_rule`
--

INSERT INTO `cy_auth_rule` (`id`, `status`, `app`, `type`, `name`, `param`, `title`, `condition`) VALUES
(1, 1, 'admin', 'admin_url', 'admin/Hook/index', '', '钩子管理', ''),
(2, 1, 'admin', 'admin_url', 'admin/Hook/plugins', '', '钩子插件管理', ''),
(3, 1, 'admin', 'admin_url', 'admin/Hook/pluginListOrder', '', '钩子插件排序', ''),
(4, 1, 'admin', 'admin_url', 'admin/Hook/sync', '', '同步钩子', ''),
(5, 1, 'admin', 'admin_url', 'admin/Link/index', '', '友情链接', ''),
(6, 1, 'admin', 'admin_url', 'admin/Link/add', '', '添加友情链接', ''),
(7, 1, 'admin', 'admin_url', 'admin/Link/addPost', '', '添加友情链接提交保存', ''),
(8, 1, 'admin', 'admin_url', 'admin/Link/edit', '', '编辑友情链接', ''),
(9, 1, 'admin', 'admin_url', 'admin/Link/editPost', '', '编辑友情链接提交保存', ''),
(10, 1, 'admin', 'admin_url', 'admin/Link/delete', '', '删除友情链接', ''),
(11, 1, 'admin', 'admin_url', 'admin/Link/listOrder', '', '友情链接排序', ''),
(12, 1, 'admin', 'admin_url', 'admin/Link/toggle', '', '友情链接显示隐藏', ''),
(13, 1, 'admin', 'admin_url', 'admin/Mailer/index', '', '邮箱配置', ''),
(14, 1, 'admin', 'admin_url', 'admin/Mailer/indexPost', '', '邮箱配置提交保存', ''),
(15, 1, 'admin', 'admin_url', 'admin/Mailer/template', '', '邮件模板', ''),
(16, 1, 'admin', 'admin_url', 'admin/Mailer/templatePost', '', '邮件模板提交', ''),
(17, 1, 'admin', 'admin_url', 'admin/Mailer/test', '', '邮件发送测试', ''),
(18, 1, 'admin', 'admin_url', 'admin/Menu/index', '', '后台菜单', ''),
(19, 1, 'admin', 'admin_url', 'admin/Menu/lists', '', '所有菜单', ''),
(20, 1, 'admin', 'admin_url', 'admin/Menu/add', '', '后台菜单添加', ''),
(21, 1, 'admin', 'admin_url', 'admin/Menu/addPost', '', '后台菜单添加提交保存', ''),
(22, 1, 'admin', 'admin_url', 'admin/Menu/edit', '', '后台菜单编辑', ''),
(23, 1, 'admin', 'admin_url', 'admin/Menu/editPost', '', '后台菜单编辑提交保存', ''),
(24, 1, 'admin', 'admin_url', 'admin/Menu/delete', '', '后台菜单删除', ''),
(25, 1, 'admin', 'admin_url', 'admin/Menu/listOrder', '', '后台菜单排序', ''),
(26, 1, 'admin', 'admin_url', 'admin/Menu/getActions', '', '导入新后台菜单', ''),
(27, 1, 'admin', 'admin_url', 'admin/Nav/index', '', '导航管理', ''),
(28, 1, 'admin', 'admin_url', 'admin/Nav/add', '', '添加导航', ''),
(29, 1, 'admin', 'admin_url', 'admin/Nav/addPost', '', '添加导航提交保存', ''),
(30, 1, 'admin', 'admin_url', 'admin/Nav/edit', '', '编辑导航', ''),
(31, 1, 'admin', 'admin_url', 'admin/Nav/editPost', '', '编辑导航提交保存', ''),
(32, 1, 'admin', 'admin_url', 'admin/Nav/delete', '', '删除导航', ''),
(33, 1, 'admin', 'admin_url', 'admin/NavMenu/index', '', '导航菜单', ''),
(34, 1, 'admin', 'admin_url', 'admin/NavMenu/add', '', '添加导航菜单', ''),
(35, 1, 'admin', 'admin_url', 'admin/NavMenu/addPost', '', '添加导航菜单提交保存', ''),
(36, 1, 'admin', 'admin_url', 'admin/NavMenu/edit', '', '编辑导航菜单', ''),
(37, 1, 'admin', 'admin_url', 'admin/NavMenu/editPost', '', '编辑导航菜单提交保存', ''),
(38, 1, 'admin', 'admin_url', 'admin/NavMenu/delete', '', '删除导航菜单', ''),
(39, 1, 'admin', 'admin_url', 'admin/NavMenu/listOrder', '', '导航菜单排序', ''),
(40, 1, 'admin', 'admin_url', 'admin/Plugin/default', '', '插件管理', ''),
(41, 1, 'admin', 'admin_url', 'admin/Plugin/index', '', '插件列表', ''),
(42, 1, 'admin', 'admin_url', 'admin/Plugin/toggle', '', '插件启用禁用', ''),
(43, 1, 'admin', 'admin_url', 'admin/Plugin/setting', '', '插件设置', ''),
(44, 1, 'admin', 'admin_url', 'admin/Plugin/settingPost', '', '插件设置提交', ''),
(45, 1, 'admin', 'admin_url', 'admin/Plugin/install', '', '插件安装', ''),
(46, 1, 'admin', 'admin_url', 'admin/Plugin/update', '', '插件更新', ''),
(47, 1, 'admin', 'admin_url', 'admin/Plugin/uninstall', '', '卸载插件', ''),
(48, 1, 'admin', 'admin_url', 'admin/Rbac/index', '', '角色管理', ''),
(49, 1, 'admin', 'admin_url', 'admin/Rbac/roleAdd', '', '添加角色', ''),
(50, 1, 'admin', 'admin_url', 'admin/Rbac/roleAddPost', '', '添加角色提交', ''),
(51, 1, 'admin', 'admin_url', 'admin/Rbac/roleEdit', '', '编辑角色', ''),
(52, 1, 'admin', 'admin_url', 'admin/Rbac/roleEditPost', '', '编辑角色提交', ''),
(53, 1, 'admin', 'admin_url', 'admin/Rbac/roleDelete', '', '删除角色', ''),
(54, 1, 'admin', 'admin_url', 'admin/Rbac/authorize', '', '设置角色权限', ''),
(55, 1, 'admin', 'admin_url', 'admin/Rbac/authorizePost', '', '角色授权提交', ''),
(56, 1, 'admin', 'admin_url', 'admin/RecycleBin/index', '', '回收站', ''),
(57, 1, 'admin', 'admin_url', 'admin/RecycleBin/restore', '', '回收站还原', ''),
(58, 1, 'admin', 'admin_url', 'admin/RecycleBin/delete', '', '回收站彻底删除', ''),
(59, 1, 'admin', 'admin_url', 'admin/Route/index', '', 'URL美化', ''),
(60, 1, 'admin', 'admin_url', 'admin/Route/add', '', '添加路由规则', ''),
(61, 1, 'admin', 'admin_url', 'admin/Route/addPost', '', '添加路由规则提交', ''),
(62, 1, 'admin', 'admin_url', 'admin/Route/edit', '', '路由规则编辑', ''),
(63, 1, 'admin', 'admin_url', 'admin/Route/editPost', '', '路由规则编辑提交', ''),
(64, 1, 'admin', 'admin_url', 'admin/Route/delete', '', '路由规则删除', ''),
(65, 1, 'admin', 'admin_url', 'admin/Route/ban', '', '路由规则禁用', ''),
(66, 1, 'admin', 'admin_url', 'admin/Route/open', '', '路由规则启用', ''),
(67, 1, 'admin', 'admin_url', 'admin/Route/listOrder', '', '路由规则排序', ''),
(68, 1, 'admin', 'admin_url', 'admin/Route/select', '', '选择URL', ''),
(69, 1, 'admin', 'admin_url', 'admin/Setting/default', '', '设置', ''),
(70, 1, 'admin', 'admin_url', 'admin/Setting/site', '', '网站信息', ''),
(71, 1, 'admin', 'admin_url', 'admin/Setting/sitePost', '', '网站信息设置提交', ''),
(72, 1, 'admin', 'admin_url', 'admin/Setting/password', '', '密码修改', ''),
(73, 1, 'admin', 'admin_url', 'admin/Setting/passwordPost', '', '密码修改提交', ''),
(74, 1, 'admin', 'admin_url', 'admin/Setting/upload', '', '上传设置', ''),
(75, 1, 'admin', 'admin_url', 'admin/Setting/uploadPost', '', '上传设置提交', ''),
(76, 1, 'admin', 'admin_url', 'admin/Setting/clearCache', '', '清除缓存', ''),
(77, 1, 'admin', 'admin_url', 'admin/Slide/index', '', '幻灯片管理', ''),
(78, 1, 'admin', 'admin_url', 'admin/Slide/add', '', '添加幻灯片', ''),
(79, 1, 'admin', 'admin_url', 'admin/Slide/addPost', '', '添加幻灯片提交', ''),
(80, 1, 'admin', 'admin_url', 'admin/Slide/edit', '', '编辑幻灯片', ''),
(81, 1, 'admin', 'admin_url', 'admin/Slide/editPost', '', '编辑幻灯片提交', ''),
(82, 1, 'admin', 'admin_url', 'admin/Slide/delete', '', '删除幻灯片', ''),
(83, 1, 'admin', 'admin_url', 'admin/SlideItem/index', '', '幻灯片页面列表', ''),
(84, 1, 'admin', 'admin_url', 'admin/SlideItem/add', '', '幻灯片页面添加', ''),
(85, 1, 'admin', 'admin_url', 'admin/SlideItem/addPost', '', '幻灯片页面添加提交', ''),
(86, 1, 'admin', 'admin_url', 'admin/SlideItem/edit', '', '幻灯片页面编辑', ''),
(87, 1, 'admin', 'admin_url', 'admin/SlideItem/editPost', '', '幻灯片页面编辑提交', ''),
(88, 1, 'admin', 'admin_url', 'admin/SlideItem/delete', '', '幻灯片页面删除', ''),
(89, 1, 'admin', 'admin_url', 'admin/SlideItem/ban', '', '幻灯片页面隐藏', ''),
(90, 1, 'admin', 'admin_url', 'admin/SlideItem/cancelBan', '', '幻灯片页面显示', ''),
(91, 1, 'admin', 'admin_url', 'admin/SlideItem/listOrder', '', '幻灯片页面排序', ''),
(92, 1, 'admin', 'admin_url', 'admin/Storage/index', '', '文件存储', ''),
(93, 1, 'admin', 'admin_url', 'admin/Storage/settingPost', '', '文件存储设置提交', ''),
(94, 1, 'admin', 'admin_url', 'admin/Theme/index', '', '模板管理', ''),
(95, 1, 'admin', 'admin_url', 'admin/Theme/install', '', '安装模板', ''),
(96, 1, 'admin', 'admin_url', 'admin/Theme/uninstall', '', '卸载模板', ''),
(97, 1, 'admin', 'admin_url', 'admin/Theme/installTheme', '', '模板安装', ''),
(98, 1, 'admin', 'admin_url', 'admin/Theme/update', '', '模板更新', ''),
(99, 1, 'admin', 'admin_url', 'admin/Theme/active', '', '启用模板', ''),
(100, 1, 'admin', 'admin_url', 'admin/Theme/files', '', '模板文件列表', ''),
(101, 1, 'admin', 'admin_url', 'admin/Theme/fileSetting', '', '模板文件设置', ''),
(102, 1, 'admin', 'admin_url', 'admin/Theme/fileArrayData', '', '模板文件数组数据列表', ''),
(103, 1, 'admin', 'admin_url', 'admin/Theme/fileArrayDataEdit', '', '模板文件数组数据添加编辑', ''),
(104, 1, 'admin', 'admin_url', 'admin/Theme/fileArrayDataEditPost', '', '模板文件数组数据添加编辑提交保存', ''),
(105, 1, 'admin', 'admin_url', 'admin/Theme/fileArrayDataDelete', '', '模板文件数组数据删除', ''),
(106, 1, 'admin', 'admin_url', 'admin/Theme/settingPost', '', '模板文件编辑提交保存', ''),
(107, 1, 'admin', 'admin_url', 'admin/Theme/dataSource', '', '模板文件设置数据源', ''),
(108, 1, 'admin', 'admin_url', 'admin/User/default', '', '管理组', ''),
(109, 1, 'admin', 'admin_url', 'admin/User/index', '', '管理员', ''),
(110, 1, 'admin', 'admin_url', 'admin/User/add', '', '管理员添加', ''),
(111, 1, 'admin', 'admin_url', 'admin/User/addPost', '', '管理员添加提交', ''),
(112, 1, 'admin', 'admin_url', 'admin/User/edit', '', '管理员编辑', ''),
(113, 1, 'admin', 'admin_url', 'admin/User/editPost', '', '管理员编辑提交', ''),
(114, 1, 'admin', 'admin_url', 'admin/User/userInfo', '', '个人信息', ''),
(115, 1, 'admin', 'admin_url', 'admin/User/userInfoPost', '', '管理员个人信息修改提交', ''),
(116, 1, 'admin', 'admin_url', 'admin/User/delete', '', '管理员删除', ''),
(117, 1, 'admin', 'admin_url', 'admin/User/ban', '', '停用管理员', ''),
(118, 1, 'admin', 'admin_url', 'admin/User/cancelBan', '', '启用管理员', ''),
(119, 1, 'portal', 'admin_url', 'portal/AdminArticle/index', '', '文章管理', ''),
(120, 1, 'portal', 'admin_url', 'portal/AdminArticle/add', '', '添加文章', ''),
(121, 1, 'portal', 'admin_url', 'portal/AdminArticle/addPost', '', '添加文章提交', ''),
(122, 1, 'portal', 'admin_url', 'portal/AdminArticle/edit', '', '编辑文章', ''),
(123, 1, 'portal', 'admin_url', 'portal/AdminArticle/editPost', '', '编辑文章提交', ''),
(124, 1, 'portal', 'admin_url', 'portal/AdminArticle/delete', '', '文章删除', ''),
(125, 1, 'portal', 'admin_url', 'portal/AdminArticle/publish', '', '文章发布', ''),
(126, 1, 'portal', 'admin_url', 'portal/AdminArticle/top', '', '文章置顶', ''),
(127, 1, 'portal', 'admin_url', 'portal/AdminArticle/recommend', '', '文章推荐', ''),
(128, 1, 'portal', 'admin_url', 'portal/AdminArticle/listOrder', '', '文章排序', ''),
(129, 1, 'portal', 'admin_url', 'portal/AdminCategory/index', '', '分类管理', ''),
(130, 1, 'portal', 'admin_url', 'portal/AdminCategory/add', '', '添加文章分类', ''),
(131, 1, 'portal', 'admin_url', 'portal/AdminCategory/addPost', '', '添加文章分类提交', ''),
(132, 1, 'portal', 'admin_url', 'portal/AdminCategory/edit', '', '编辑文章分类', ''),
(133, 1, 'portal', 'admin_url', 'portal/AdminCategory/editPost', '', '编辑文章分类提交', ''),
(134, 1, 'portal', 'admin_url', 'portal/AdminCategory/select', '', '文章分类选择对话框', ''),
(135, 1, 'portal', 'admin_url', 'portal/AdminCategory/listOrder', '', '文章分类排序', ''),
(136, 1, 'portal', 'admin_url', 'portal/AdminCategory/delete', '', '删除文章分类', ''),
(137, 1, 'portal', 'admin_url', 'portal/AdminIndex/default', '', '门户管理', ''),
(138, 1, 'portal', 'admin_url', 'portal/AdminPage/index', '', '页面管理', ''),
(139, 1, 'portal', 'admin_url', 'portal/AdminPage/add', '', '添加页面', ''),
(140, 1, 'portal', 'admin_url', 'portal/AdminPage/addPost', '', '添加页面提交', ''),
(141, 1, 'portal', 'admin_url', 'portal/AdminPage/edit', '', '编辑页面', ''),
(142, 1, 'portal', 'admin_url', 'portal/AdminPage/editPost', '', '编辑页面提交', ''),
(143, 1, 'portal', 'admin_url', 'portal/AdminPage/delete', '', '删除页面', ''),
(144, 1, 'portal', 'admin_url', 'portal/AdminTag/index', '', '文章标签', ''),
(145, 1, 'portal', 'admin_url', 'portal/AdminTag/add', '', '添加文章标签', ''),
(146, 1, 'portal', 'admin_url', 'portal/AdminTag/addPost', '', '添加文章标签提交', ''),
(147, 1, 'portal', 'admin_url', 'portal/AdminTag/upStatus', '', '更新标签状态', ''),
(148, 1, 'portal', 'admin_url', 'portal/AdminTag/delete', '', '删除文章标签', ''),
(149, 1, 'user', 'admin_url', 'user/AdminAsset/index', '', '资源管理', ''),
(150, 1, 'user', 'admin_url', 'user/AdminAsset/delete', '', '删除文件', ''),
(151, 1, 'user', 'admin_url', 'user/AdminIndex/default', '', '用户管理', ''),
(152, 1, 'user', 'admin_url', 'user/AdminIndex/default1', '', '用户组', ''),
(153, 1, 'user', 'admin_url', 'user/AdminIndex/index', '', '本站用户', ''),
(154, 1, 'user', 'admin_url', 'user/AdminIndex/ban', '', '本站用户拉黑', ''),
(155, 1, 'user', 'admin_url', 'user/AdminIndex/cancelBan', '', '本站用户启用', ''),
(156, 1, 'user', 'admin_url', 'user/AdminOauth/index', '', '第三方用户', ''),
(157, 1, 'user', 'admin_url', 'user/AdminOauth/delete', '', '删除第三方用户绑定', ''),
(158, 1, 'user', 'admin_url', 'user/AdminUserAction/index', '', '用户操作管理', ''),
(159, 1, 'user', 'admin_url', 'user/AdminUserAction/edit', '', '编辑用户操作', ''),
(160, 1, 'user', 'admin_url', 'user/AdminUserAction/editPost', '', '编辑用户操作提交', ''),
(161, 1, 'user', 'admin_url', 'user/AdminUserAction/sync', '', '同步用户操作', '');

-- --------------------------------------------------------

--
-- 表的结构 `cy_comment`
--

CREATE TABLE IF NOT EXISTS `cy_comment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '被回复的评论id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发表评论的用户id',
  `to_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '被评论的用户id',
  `object_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论内容 id',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论时间',
  `delete_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:已审核,0:未审核',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '评论类型；1实名评论',
  `table_name` varchar(64) NOT NULL DEFAULT '' COMMENT '评论内容所在表，不带表前缀',
  `full_name` varchar(50) NOT NULL DEFAULT '' COMMENT '评论者昵称',
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT '评论者邮箱',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '层级关系',
  `url` text COMMENT '原文地址',
  `content` text COMMENT '评论内容',
  `more` text COMMENT '扩展属性',
  PRIMARY KEY (`id`),
  KEY `comment_post_ID` (`object_id`),
  KEY `comment_approved_date_gmt` (`status`),
  KEY `comment_parent` (`parent_id`),
  KEY `table_id_status` (`table_name`,`object_id`,`status`),
  KEY `createtime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='评论表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cy_hook`
--

CREATE TABLE IF NOT EXISTS `cy_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '钩子类型(1:系统钩子;2:应用钩子;3:模板钩子)',
  `once` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否只允许一个插件运行(0:多个;1:一个)',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `hook` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子',
  `app` varchar(15) NOT NULL DEFAULT '' COMMENT '应用名(只有应用钩子才用)',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='系统钩子表' AUTO_INCREMENT=32 ;

--
-- 转存表中的数据 `cy_hook`
--

INSERT INTO `cy_hook` (`id`, `type`, `once`, `name`, `hook`, `app`, `description`) VALUES
(1, 1, 0, '应用初始化', 'app_init', 'cmf', '应用初始化'),
(2, 1, 0, '应用开始', 'app_begin', 'cmf', '应用开始'),
(3, 1, 0, '模块初始化', 'module_init', 'cmf', '模块初始化'),
(4, 1, 0, '控制器开始', 'action_begin', 'cmf', '控制器开始'),
(5, 1, 0, '视图输出过滤', 'view_filter', 'cmf', '视图输出过滤'),
(6, 1, 0, '应用结束', 'app_end', 'cmf', '应用结束'),
(7, 1, 0, '日志write方法', 'log_write', 'cmf', '日志write方法'),
(8, 1, 0, '输出结束', 'response_end', 'cmf', '输出结束'),
(9, 1, 0, '后台控制器初始化', 'admin_init', 'cmf', '后台控制器初始化'),
(10, 1, 0, '前台控制器初始化', 'home_init', 'cmf', '前台控制器初始化'),
(11, 1, 1, '发送手机验证码', 'send_mobile_verification_code', 'cmf', '发送手机验证码'),
(12, 3, 0, '模板 body标签开始', 'body_start', '', '模板 body标签开始'),
(13, 3, 0, '模板 head标签结束前', 'before_head_end', '', '模板 head标签结束前'),
(14, 3, 0, '模板底部开始', 'footer_start', '', '模板底部开始'),
(15, 3, 0, '模板底部开始之前', 'before_footer', '', '模板底部开始之前'),
(16, 3, 0, '模板底部结束之前', 'before_footer_end', '', '模板底部结束之前'),
(17, 3, 0, '模板 body 标签结束之前', 'before_body_end', '', '模板 body 标签结束之前'),
(18, 3, 0, '模板左边栏开始', 'left_sidebar_start', '', '模板左边栏开始'),
(19, 3, 0, '模板左边栏结束之前', 'before_left_sidebar_end', '', '模板左边栏结束之前'),
(20, 3, 0, '模板右边栏开始', 'right_sidebar_start', '', '模板右边栏开始'),
(21, 3, 0, '模板右边栏结束之前', 'before_right_sidebar_end', '', '模板右边栏结束之前'),
(22, 3, 1, '评论区', 'comment', '', '评论区'),
(23, 3, 1, '留言区', 'guestbook', '', '留言区'),
(24, 2, 0, '后台首页仪表盘', 'admin_dashboard', 'admin', '后台首页仪表盘'),
(25, 4, 0, '后台模板 head标签结束前', 'admin_before_head_end', '', '后台模板 head标签结束前'),
(26, 4, 0, '后台模板 body 标签结束之前', 'admin_before_body_end', '', '后台模板 body 标签结束之前'),
(27, 2, 0, '后台登录页面', 'admin_login', 'admin', '后台登录页面'),
(28, 1, 1, '前台模板切换', 'switch_theme', 'cmf', '前台模板切换'),
(29, 3, 0, '主要内容之后', 'after_content', '', '主要内容之后'),
(30, 2, 0, '文章显示之前', 'portal_before_assign_article', 'portal', '文章显示之前'),
(31, 2, 0, '后台文章保存之后', 'portal_admin_after_save_article', 'portal', '后台文章保存之后');

-- --------------------------------------------------------

--
-- 表的结构 `cy_hook_plugin`
--

CREATE TABLE IF NOT EXISTS `cy_hook_plugin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态(0:禁用,1:启用)',
  `hook` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名',
  `plugin` varchar(30) NOT NULL DEFAULT '' COMMENT '插件',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='系统钩子插件表' AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `cy_hook_plugin`
--

INSERT INTO `cy_hook_plugin` (`id`, `list_order`, `status`, `hook`, `plugin`) VALUES
(10, 10000, 1, 'admin_login', 'CustomAdminLogin');

-- --------------------------------------------------------

--
-- 表的结构 `cy_link`
--

CREATE TABLE IF NOT EXISTS `cy_link` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:显示;0:不显示',
  `rating` int(11) NOT NULL DEFAULT '0' COMMENT '友情链接评级',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '友情链接描述',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '友情链接地址',
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '友情链接名称',
  `image` varchar(100) NOT NULL DEFAULT '' COMMENT '友情链接图标',
  `target` varchar(10) NOT NULL DEFAULT '' COMMENT '友情链接打开方式',
  `rel` varchar(50) NOT NULL DEFAULT '' COMMENT '链接与网站的关系',
  PRIMARY KEY (`id`),
  KEY `link_visible` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='友情链接表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cy_nav`
--

CREATE TABLE IF NOT EXISTS `cy_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `is_main` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否为主导航;1:是;0:不是',
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '导航位置名称',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='前台导航位置表' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `cy_nav`
--

INSERT INTO `cy_nav` (`id`, `is_main`, `name`, `remark`) VALUES
(1, 1, '主导航', '主导航'),
(2, 0, '底部导航', '');

-- --------------------------------------------------------

--
-- 表的结构 `cy_nav_menu`
--

CREATE TABLE IF NOT EXISTS `cy_nav_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nav_id` int(11) NOT NULL COMMENT '导航 id',
  `parent_id` int(11) NOT NULL COMMENT '父 id',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:显示;0:隐藏',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '菜单名称',
  `target` varchar(10) NOT NULL DEFAULT '' COMMENT '打开方式',
  `href` varchar(100) NOT NULL DEFAULT '' COMMENT '链接',
  `icon` varchar(20) NOT NULL DEFAULT '' COMMENT '图标',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '层级关系',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='前台导航菜单表' AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `cy_nav_menu`
--

INSERT INTO `cy_nav_menu` (`id`, `nav_id`, `parent_id`, `status`, `list_order`, `name`, `target`, `href`, `icon`, `path`) VALUES
(1, 1, 0, 1, 0, '首页', '', 'home', '', '0-1'),
(2, 1, 0, 1, 10000, '关于我们', '', '{"action":"portal\\/Page\\/index","param":{"id":1}}', '', ''),
(3, 1, 0, 1, 10000, 'Holyfan好饭', '', '{"action":"portal\\/List\\/index","param":{"id":7}}', '', ''),
(4, 1, 0, 1, 10000, '留萌日式火锅', '', '{"action":"portal\\/List\\/index","param":{"id":5}}', '', ''),
(5, 1, 0, 1, 10000, '这里有意式餐厅', '', '{"action":"portal\\/List\\/index","param":{"id":6}}', '', ''),
(6, 1, 0, 1, 10000, '招商加盟', '', '{"action":"portal\\/Page\\/index","param":{"id":2}}', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `cy_option`
--

CREATE TABLE IF NOT EXISTS `cy_option` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `autoload` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否自动加载;1:自动加载;0:不自动加载',
  `option_name` varchar(64) NOT NULL DEFAULT '' COMMENT '配置名',
  `option_value` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT '配置值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='全站配置表' AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `cy_option`
--

INSERT INTO `cy_option` (`id`, `autoload`, `option_name`, `option_value`) VALUES
(7, 1, 'site_info', '{"site_name":"\\u8fd9\\u91cc\\u6709\\u9910\\u996e","site_seo_title":"\\u8fd9\\u91cc\\u6709\\u9910\\u996e","site_seo_keywords":"\\u8fd9\\u91cc\\u6709\\u9910\\u996e","site_seo_description":"\\u8fd9\\u91cc\\u6709\\u9910\\u996e","site_host":"","site_logo":"admin\\/20171027\\/447ba5083ba16171baf0ecc9c990529d.png","site_erweima":"admin\\/20171027\\/abd96d82f9473df35fbb8f31a1b3187d.png","site_icp":"","site_admin_email":"","site_analytics":"","urlmode":"1","html_suffix":""}'),
(8, 1, 'storage', '{"type":"Local"}'),
(9, 1, 'cmf_settings', '{"open_registration":"0","banned_usernames":""}'),
(10, 1, 'cdn_settings', '{"cdn_static_root":""}'),
(11, 1, 'admin_settings', '{"admin_password":""}'),
(12, 1, 'admin_dashboard_widgets', '[{"name":"CmfHub","is_system":1},{"name":"MainContributors","is_system":1},{"name":"Contributors","is_system":1},{"name":"Custom1","is_system":1},{"name":"Custom2","is_system":1},{"name":"Custom3","is_system":1},{"name":"Custom4","is_system":1},{"name":"Custom5","is_system":1}]');

-- --------------------------------------------------------

--
-- 表的结构 `cy_plugin`
--

CREATE TABLE IF NOT EXISTS `cy_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '插件类型;1:网站;8:微信',
  `has_admin` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台管理,0:没有;1:有',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:开启;0:禁用',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '插件安装时间',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '插件标识名,英文字母(惟一)',
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '插件名称',
  `demo_url` varchar(50) NOT NULL DEFAULT '' COMMENT '演示地址，带协议',
  `hooks` varchar(255) NOT NULL DEFAULT '' COMMENT '实现的钩子;以“,”分隔',
  `author` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '插件作者',
  `author_url` varchar(50) NOT NULL DEFAULT '' COMMENT '作者网站链接',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '插件版本号',
  `description` varchar(255) NOT NULL COMMENT '插件描述',
  `config` text COMMENT '插件配置',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='插件表' AUTO_INCREMENT=15 ;

--
-- 转存表中的数据 `cy_plugin`
--

INSERT INTO `cy_plugin` (`id`, `type`, `has_admin`, `status`, `create_time`, `name`, `title`, `demo_url`, `hooks`, `author`, `author_url`, `version`, `description`, `config`) VALUES
(14, 1, 0, 1, 0, 'CustomAdminLogin', '自定义后台登录页', '', '', 'ThinkCMF', '', '1.0', '自定义后台登录页', '[]');

-- --------------------------------------------------------

--
-- 表的结构 `cy_portal_category`
--

CREATE TABLE IF NOT EXISTS `cy_portal_category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类id',
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '分类父id',
  `post_count` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '分类文章数',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:发布,0:不发布',
  `delete_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '分类名称',
  `description` varchar(255) NOT NULL COMMENT '分类描述',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '分类层级关系路径',
  `seo_title` varchar(100) NOT NULL DEFAULT '',
  `seo_keywords` varchar(255) NOT NULL DEFAULT '',
  `seo_description` varchar(255) NOT NULL DEFAULT '',
  `list_tpl` varchar(50) NOT NULL DEFAULT '' COMMENT '分类列表模板',
  `one_tpl` varchar(50) NOT NULL DEFAULT '' COMMENT '分类文章页模板',
  `more` text COMMENT '扩展属性',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='portal应用 文章分类表' AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `cy_portal_category`
--

INSERT INTO `cy_portal_category` (`id`, `parent_id`, `post_count`, `status`, `delete_time`, `list_order`, `name`, `description`, `path`, `seo_title`, `seo_keywords`, `seo_description`, `list_tpl`, `one_tpl`, `more`) VALUES
(1, 0, 0, 1, 0, 10000, '品牌中心', '品牌中心', '0-1', '品牌中心', '品牌中心', '品牌中心', 'brand1', 'article', '{"thumbnail":""}'),
(2, 0, 0, 1, 0, 10000, '新闻中心', '新闻中心', '0-2', '新闻中心', '新闻中心', '新闻中心', 'list', 'article', '{"thumbnail":""}'),
(3, 2, 0, 1, 0, 10000, '新品上市', '新品上市', '0-2-3', '新品上市', '新品上市', '新品上市', 'list', 'article', '{"thumbnail":""}'),
(4, 2, 0, 1, 0, 10000, '企业动态', '企业动态', '0-2-4', '企业动态', '企业动态', '企业动态', 'list', 'article', '{"thumbnail":""}'),
(5, 1, 0, 1, 0, 10000, '留萌日式火锅', '留萌日式火锅', '0-1-5', '留萌日式火锅', '留萌日式火锅', '留萌日式火锅', 'brand1', 'article', '{"thumbnail":""}'),
(6, 1, 0, 1, 0, 10000, '这里有意式餐厅', '这里有意式餐厅', '0-1-6', '这里有意式餐厅', '这里有意式餐厅', '这里有意式餐厅', 'brand2', 'article', '{"thumbnail":""}'),
(7, 1, 0, 1, 0, 10000, 'Holyfan好饭', 'Holyfan好饭', '0-1-7', 'Holyfan好饭', 'Holyfan好饭', 'Holyfan好饭', 'brand3', 'article', '{"thumbnail":""}');

-- --------------------------------------------------------

--
-- 表的结构 `cy_portal_category_post`
--

CREATE TABLE IF NOT EXISTS `cy_portal_category_post` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文章id',
  `category_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '分类id',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:发布;0:不发布',
  PRIMARY KEY (`id`),
  KEY `term_taxonomy_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='portal应用 分类文章对应表' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `cy_portal_category_post`
--

INSERT INTO `cy_portal_category_post` (`id`, `post_id`, `category_id`, `list_order`, `status`) VALUES
(1, 3, 3, 10000, 1),
(2, 4, 4, 10000, 1),
(3, 5, 2, 10000, 1);

-- --------------------------------------------------------

--
-- 表的结构 `cy_portal_post`
--

CREATE TABLE IF NOT EXISTS `cy_portal_post` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '父级id',
  `post_type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '类型,1:文章;2:页面',
  `post_format` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '内容格式;1:html;2:md',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '发表者用户id',
  `post_status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:已发布;0:未发布;',
  `comment_status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '评论状态;1:允许;0:不允许',
  `is_top` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否置顶;1:置顶;0:不置顶',
  `recommended` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否推荐;1:推荐;0:不推荐',
  `post_hits` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '查看数',
  `post_like` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '点赞数',
  `comment_count` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `published_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发布时间',
  `delete_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `post_title` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'post标题',
  `post_keywords` varchar(150) NOT NULL DEFAULT '' COMMENT 'seo keywords',
  `post_excerpt` varchar(500) NOT NULL DEFAULT '' COMMENT 'post摘要',
  `post_source` varchar(150) NOT NULL DEFAULT '' COMMENT '转载文章的来源',
  `post_content` text COMMENT '文章内容',
  `post_content_filtered` text COMMENT '处理过的文章内容',
  `more` text COMMENT '扩展属性,如缩略图;格式为json',
  PRIMARY KEY (`id`),
  KEY `type_status_date` (`post_type`,`post_status`,`create_time`,`id`),
  KEY `post_parent` (`parent_id`),
  KEY `post_author` (`user_id`),
  KEY `post_date` (`create_time`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='portal应用 文章表' AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `cy_portal_post`
--

INSERT INTO `cy_portal_post` (`id`, `parent_id`, `post_type`, `post_format`, `user_id`, `post_status`, `comment_status`, `is_top`, `recommended`, `post_hits`, `post_like`, `comment_count`, `create_time`, `update_time`, `published_time`, `delete_time`, `post_title`, `post_keywords`, `post_excerpt`, `post_source`, `post_content`, `post_content_filtered`, `more`) VALUES
(1, 0, 2, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1508861467, 1508862779, 1508861400, 0, '关于我们', '关于我们', '', '', NULL, NULL, '{"thumbnail":"","template":"about"}'),
(2, 0, 2, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1508861497, 1508863200, 1508861460, 0, '招商加盟', '招商加盟', '招商加盟', '', NULL, NULL, '{"thumbnail":"","template":"join"}'),
(3, 0, 1, 1, 1, 1, 1, 0, 1, 56, 0, 0, 1509238186, 1509239325, 1509238140, 0, '新品上市测试', '新品上市测试', '新品上市测试', '', '&lt;p&gt;新品上市测试新品上市测试新品上市测试新品上市测试新品上市测试新品上市测试&lt;/p&gt;', NULL, '{"thumbnail":"portal\\/20171029\\/dc44367760930ea5766b65178b46489b.png","template":"article"}'),
(4, 0, 1, 1, 1, 1, 1, 0, 0, 11, 0, 0, 1509238232, 1509238232, 1509238199, 0, '企业动态测试', '企业动态测试', '企业动态测试', '企业动态测试', '&lt;p&gt;企业动态测试企业动态测试企业动态测试企业动态测试&lt;/p&gt;', NULL, '{"thumbnail":"portal\\/20171029\\/dc44367760930ea5766b65178b46489b.png","template":""}'),
(5, 0, 1, 1, 1, 1, 1, 0, 0, 37, 0, 0, 1509238284, 1509238284, 1509238239, 0, '新闻中心文章', '新闻中心文章', '新闻中心文章', '', '&lt;p&gt;新闻中心文章新闻中心文章新闻中心文章新闻中心文章&lt;/p&gt;', NULL, '{"thumbnail":"portal\\/20171029\\/dc44367760930ea5766b65178b46489b.png","template":""}');

-- --------------------------------------------------------

--
-- 表的结构 `cy_portal_tag`
--

CREATE TABLE IF NOT EXISTS `cy_portal_tag` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类id',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:发布,0:不发布',
  `recommended` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否推荐;1:推荐;0:不推荐',
  `post_count` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '标签文章数',
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '标签名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='portal应用 文章标签表' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `cy_portal_tag`
--

INSERT INTO `cy_portal_tag` (`id`, `status`, `recommended`, `post_count`, `name`) VALUES
(1, 1, 0, 0, '新品上市测试'),
(2, 1, 0, 0, '企业动态测试'),
(3, 1, 0, 0, '新闻中心文章');

-- --------------------------------------------------------

--
-- 表的结构 `cy_portal_tag_post`
--

CREATE TABLE IF NOT EXISTS `cy_portal_tag_post` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tag_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '标签 id',
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文章 id',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:发布;0:不发布',
  PRIMARY KEY (`id`),
  KEY `term_taxonomy_id` (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='portal应用 标签文章对应表' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `cy_portal_tag_post`
--

INSERT INTO `cy_portal_tag_post` (`id`, `tag_id`, `post_id`, `status`) VALUES
(1, 1, 3, 1),
(2, 2, 4, 1),
(3, 3, 5, 1);

-- --------------------------------------------------------

--
-- 表的结构 `cy_recycle_bin`
--

CREATE TABLE IF NOT EXISTS `cy_recycle_bin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` int(11) DEFAULT '0' COMMENT '删除内容 id',
  `create_time` int(10) unsigned DEFAULT '0' COMMENT '创建时间',
  `table_name` varchar(60) DEFAULT '' COMMENT '删除内容所在表名',
  `name` varchar(255) DEFAULT '' COMMENT '删除内容名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT=' 回收站' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cy_role`
--

CREATE TABLE IF NOT EXISTS `cy_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父角色ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态;0:禁用;1:正常',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `list_order` float NOT NULL DEFAULT '0' COMMENT '排序',
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '角色名称',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `parentId` (`parent_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='角色表' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `cy_role`
--

INSERT INTO `cy_role` (`id`, `parent_id`, `status`, `create_time`, `update_time`, `list_order`, `name`, `remark`) VALUES
(1, 0, 1, 1329633709, 1329633709, 0, '超级管理员', '拥有网站最高管理员权限！'),
(2, 0, 1, 1329633709, 1329633709, 0, '普通管理员', '权限由最高管理员分配！');

-- --------------------------------------------------------

--
-- 表的结构 `cy_role_user`
--

CREATE TABLE IF NOT EXISTS `cy_role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '角色 id',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  PRIMARY KEY (`id`),
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户角色对应表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cy_route`
--

CREATE TABLE IF NOT EXISTS `cy_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '路由id',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态;1:启用,0:不启用',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'URL规则类型;1:用户自定义;2:别名添加',
  `full_url` varchar(255) NOT NULL DEFAULT '' COMMENT '完整url',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '实际显示的url',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='url路由表' AUTO_INCREMENT=19 ;

--
-- 转存表中的数据 `cy_route`
--

INSERT INTO `cy_route` (`id`, `list_order`, `status`, `type`, `full_url`, `url`) VALUES
(1, 5000, 1, 2, 'portal/Page/index?id=1', 'about'),
(2, 5000, 1, 2, 'portal/Page/index?id=2', 'join'),
(4, 5000, 1, 2, 'portal/List/index?id=1', 'brand'),
(5, 4999, 1, 2, 'portal/Article/index?cid=1', 'brand/:id'),
(6, 5000, 1, 2, 'portal/List/index?id=2', 'news'),
(7, 4999, 1, 2, 'portal/Article/index?cid=2', 'news/:id'),
(8, 5000, 1, 2, 'portal/List/index?id=3', 'xpss'),
(9, 4999, 1, 2, 'portal/Article/index?cid=3', 'xpss/:id'),
(10, 5000, 1, 2, 'portal/List/index?id=4', 'qydt'),
(11, 4999, 1, 2, 'portal/Article/index?cid=4', 'qydt/:id'),
(12, 5000, 1, 2, 'portal/List/index?id=5', 'lmrshg'),
(13, 4999, 1, 2, 'portal/Article/index?cid=5', 'lmrshg/:id'),
(14, 5000, 1, 2, 'portal/List/index?id=6', 'zlyysct'),
(15, 4999, 1, 2, 'portal/Article/index?cid=6', 'zlyysct/:id'),
(16, 5000, 1, 2, 'portal/List/index?id=7', 'holyfan'),
(17, 4999, 1, 2, 'portal/Article/index?cid=7', 'holyfan/:id'),
(18, 10000, 1, 1, 'portal/Article/index', 'detail/:id');

-- --------------------------------------------------------

--
-- 表的结构 `cy_slide`
--

CREATE TABLE IF NOT EXISTS `cy_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:显示,0不显示',
  `delete_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '幻灯片分类',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '分类备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='幻灯片表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `cy_slide`
--

INSERT INTO `cy_slide` (`id`, `status`, `delete_time`, `name`, `remark`) VALUES
(1, 1, 0, '首页轮播图', '首页轮播图');

-- --------------------------------------------------------

--
-- 表的结构 `cy_slide_item`
--

CREATE TABLE IF NOT EXISTS `cy_slide_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slide_id` int(11) NOT NULL DEFAULT '0' COMMENT '幻灯片id',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:显示;0:隐藏',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '幻灯片名称',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '幻灯片图片',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '幻灯片链接',
  `target` varchar(10) NOT NULL DEFAULT '' COMMENT '友情链接打开方式',
  `description` varchar(255) NOT NULL COMMENT '幻灯片描述',
  `content` text COMMENT '幻灯片内容',
  `more` text COMMENT '链接打开方式',
  PRIMARY KEY (`id`),
  KEY `slide_cid` (`slide_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='幻灯片子项表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `cy_slide_item`
--

INSERT INTO `cy_slide_item` (`id`, `slide_id`, `status`, `list_order`, `title`, `image`, `url`, `target`, `description`, `content`, `more`) VALUES
(1, 1, 1, 10000, '1', 'admin/20171025/d91699ad82e9cbee3bd173438a61113d.png', '#', '', '', '', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `cy_theme`
--

CREATE TABLE IF NOT EXISTS `cy_theme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后升级时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '模板状态,1:正在使用;0:未使用',
  `is_compiled` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否为已编译模板',
  `theme` varchar(20) NOT NULL DEFAULT '' COMMENT '主题目录名，用于主题的维一标识',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '主题名称',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '主题版本号',
  `demo_url` varchar(50) NOT NULL DEFAULT '' COMMENT '演示地址，带协议',
  `thumbnail` varchar(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `author` varchar(20) NOT NULL DEFAULT '' COMMENT '主题作者',
  `author_url` varchar(50) NOT NULL DEFAULT '' COMMENT '作者网站链接',
  `lang` varchar(10) NOT NULL DEFAULT '' COMMENT '支持语言',
  `keywords` varchar(50) NOT NULL DEFAULT '' COMMENT '主题关键字',
  `description` varchar(100) NOT NULL DEFAULT '' COMMENT '主题描述',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- 转存表中的数据 `cy_theme`
--

INSERT INTO `cy_theme` (`id`, `create_time`, `update_time`, `status`, `is_compiled`, `theme`, `name`, `version`, `demo_url`, `thumbnail`, `author`, `author_url`, `lang`, `keywords`, `description`) VALUES
(20, 0, 0, 0, 0, 'canyin', 'canyin', '1.0.0', '', '', 'lolxy', '', 'zh-cn', '这理有餐饮', '这理有餐饮');

-- --------------------------------------------------------

--
-- 表的结构 `cy_theme_file`
--

CREATE TABLE IF NOT EXISTS `cy_theme_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_public` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否公共的模板文件',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `theme` varchar(20) NOT NULL DEFAULT '' COMMENT '模板名称',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '模板文件名',
  `action` varchar(50) NOT NULL DEFAULT '' COMMENT '操作',
  `file` varchar(50) NOT NULL DEFAULT '' COMMENT '模板文件，相对于模板根目录，如Portal/index.html',
  `description` varchar(100) NOT NULL DEFAULT '' COMMENT '模板文件描述',
  `more` text COMMENT '模板更多配置,用户自己后台设置的',
  `config_more` text COMMENT '模板更多配置,来源模板的配置文件',
  `draft_more` text COMMENT '模板更多配置,用户临时保存的配置',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4169 ;

--
-- 转存表中的数据 `cy_theme_file`
--

INSERT INTO `cy_theme_file` (`id`, `is_public`, `list_order`, `theme`, `name`, `action`, `file`, `description`, `more`, `config_more`, `draft_more`) VALUES
(129, 0, 5, 'canyin', '品牌：这里有意式餐厅', 'portal/List/index', 'portal/brand2', '品牌页模板文件', '{"vars":{"ads":{"title":"\\u9876\\u90e8\\u5e7f\\u544a\\u56fe","value":"","type":"image","tip":"\\uff08\\u5efa\\u8bae\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a1920px*500px\\uff09"}},"widgets":{"mainbox":{"title":"\\u9876\\u90e8\\u63a8\\u8350\\u6a21\\u5757","display":1,"vars":{"mainlogo":{"title":"\\u54c1\\u724clogo","value":"admin\\/20171029\\/dfabae926653d7d5fae98b1e5b2bb8ac.png","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a220px*220px)"},"mainthumb":{"title":"\\u54c1\\u724c\\u4e3b\\u56fe","value":"admin\\/20171029\\/92e4b0f9ade6266b3c13a31b59e3efb6.png","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a375px*340px)"},"description":{"title":"\\u54c1\\u724c\\u4ecb\\u7ecd","value":"Holyfan\\u897f\\u73ed\\u7259\\u6d77\\u9c9c\\u996d\\uff0c\\u4e3b\\u8425\\u597d\\u597d\\u5403\\u7684\\u996d\\uff0c\\u798f\\u5dde\\u51712\\u5bb6\\u5206\\u5e97","type":"textarea","tip":""}}},"product":{"title":"\\u83dc\\u54c1","display":1,"vars":{"products":{"title":"\\u83dc\\u54c1\\u7ba1\\u7406","value":[{"title":"\\u897f\\u73ed\\u7259\\u70e9\\u996d","description":"\\u4ee5\\u7c73\\u996d\\u3001\\u65b0\\u9c9c\\u5e72\\u8d1d\\u4e3a\\u4e3b\\u8981\\u98df\\u6750\\u91c7\\u7528\\u591a\\u79cd\\u6d77\\u9c9c\\uff0c\\u53e3\\u611f\\u4e30\\u5bcc","thumb":"admin\\/20171029\\/1fb88dc4b8efb2cc0c47016c56de7822.png"},{"title":"\\u897f\\u73ed\\u7259\\u70e9\\u996d","description":"\\u4ee5\\u7c73\\u996d\\u3001\\u65b0\\u9c9c\\u5e72\\u8d1d\\u4e3a\\u4e3b\\u8981\\u98df\\u6750\\u91c7\\u7528\\u591a\\u79cd\\u6d77\\u9c9c\\uff0c\\u53e3\\u611f\\u4e30\\u5bcc","thumb":"admin\\/20171029\\/45c6ca4a5a2998ab20a4a5382fc1cafa.png"},{"title":"\\u897f\\u73ed\\u7259\\u70e9\\u996d","description":"\\u4ee5\\u7c73\\u996d\\u3001\\u65b0\\u9c9c\\u5e72\\u8d1d\\u4e3a\\u4e3b\\u8981\\u98df\\u6750\\u91c7\\u7528\\u591a\\u79cd\\u6d77\\u9c9c\\uff0c\\u53e3\\u611f\\u4e30\\u5bcc","thumb":"admin\\/20171029\\/b6bb274a401fac6a711d57774359394f.png"}],"type":"array","item":{"title":{"title":"\\u83dc\\u54c1\\u540d\\u79f0","value":"","type":"text"},"description":{"title":"\\u83dc\\u54c1\\u4ecb\\u7ecd","value":"","type":"textarea"},"thumb":{"title":"\\u83dc\\u54c1\\u4e3b\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a770px*510px)"}},"tip":""}}},"xingxiang":{"title":"\\u5f62\\u8c61\\u76f8\\u518c","display":1,"vars":{"xingxiangs":{"title":"\\u76f8\\u518c\\u7ba1\\u7406","value":[{"thumb":"admin\\/20171029\\/abd2b61f44cae79827f08c360a253bfe.png"},{"thumb":"admin\\/20171029\\/3e5719548e9ef906494e8f89c63e98ae.png"}],"type":"array","item":{"thumb":{"title":"\\u76f8\\u518c\\u4e0a\\u4f20","value":"","type":"image"}},"tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a530px*325px)"}}},"mengdian":{"title":"\\u95e8\\u5e97\\u5206\\u5e03","display":1,"vars":{"shophome":{"title":"\\u95e8\\u5e97\\u7ba1\\u7406","value":[{"name":"\\u4e16\\u6b27\\u5e7f\\u573a\\u5e97","shop_location_text_":"\\u798f\\u5efa\\u7701\\u798f\\u5dde\\u5e02\\u9f13\\u697c\\u533a\\u9053\\u5c71\\u8def305\\u53f7-2\\u53f7\\u697c-2-1","shop_location":"119.298983,26.082409"},{"name":"\\u4e16\\u6b27\\u5e7f\\u573a\\u5e97","shop_location_text_":"\\u798f\\u5efa\\u7701\\u798f\\u5dde\\u5e02\\u4ed3\\u5c71\\u533a","shop_location":"119.399266,25.993394"}],"type":"array","item":{"name":{"title":"\\u95e8\\u5e97\\u540d\\u79f0","value":"","type":"text"},"shop_location":{"title":"\\u95e8\\u5e97\\u5750\\u6807","value":"","type":"location","tip":""}},"tip":""},"phone":{"title":"\\u52a0\\u76df\\u70ed\\u7ebf","value":"137-1234-5678","type":"text","tip":""},"qq":{"title":"QQ\\u53f7\\u7801","value":"60476867","type":"text","tip":""},"weixin":{"title":"\\u4e0a\\u4f20\\u5fae\\u4fe1\\u4e8c\\u7ef4\\u7801","value":"admin\\/20171027\\/abd96d82f9473df35fbb8f31a1b3187d.png","type":"image","tip":""},"weibo":{"title":"\\u5fae\\u535a\\u53f7","value":"lolxy2010","type":"text","tip":""}}}}}', '{"vars":{"ads":{"title":"\\u9876\\u90e8\\u5e7f\\u544a\\u56fe","value":"","type":"image","tip":"\\uff08\\u5efa\\u8bae\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a1920px*500px\\uff09"}},"widgets":{"mainbox":{"title":"\\u9876\\u90e8\\u63a8\\u8350\\u6a21\\u5757","display":"1","vars":{"mainlogo":{"title":"\\u54c1\\u724clogo","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a220px*220px)"},"mainthumb":{"title":"\\u54c1\\u724c\\u4e3b\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a375px*340px)"},"description":{"title":"\\u54c1\\u724c\\u4ecb\\u7ecd","value":"","type":"textarea","tip":""}}},"product":{"title":"\\u83dc\\u54c1","display":"1","vars":{"products":{"title":"\\u83dc\\u54c1\\u7ba1\\u7406","value":[],"type":"array","item":{"title":{"title":"\\u83dc\\u54c1\\u540d\\u79f0","value":"","type":"text"},"description":{"title":"\\u83dc\\u54c1\\u4ecb\\u7ecd","value":"","type":"textarea"},"thumb":{"title":"\\u83dc\\u54c1\\u4e3b\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a770px*510px)"}},"tip":""}}},"xingxiang":{"title":"\\u5f62\\u8c61\\u76f8\\u518c","display":"1","vars":{"xingxiangs":{"title":"\\u76f8\\u518c\\u7ba1\\u7406","value":[],"type":"array","item":{"thumb":{"title":"\\u76f8\\u518c\\u4e0a\\u4f20","value":"","type":"image"}},"tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a530px*325px)"}}},"mengdian":{"title":"\\u95e8\\u5e97\\u5206\\u5e03","display":"1","vars":{"shophome":{"title":"\\u95e8\\u5e97\\u7ba1\\u7406","value":[],"type":"array","item":{"name":{"title":"\\u95e8\\u5e97\\u540d\\u79f0","value":"","type":"text"},"shop_location":{"title":"\\u95e8\\u5e97\\u5750\\u6807","value":"","type":"location","tip":""}},"tip":""},"phone":{"title":"\\u52a0\\u76df\\u70ed\\u7ebf","value":"","type":"text","tip":""},"qq":{"title":"QQ\\u53f7\\u7801","value":"","type":"text","tip":""},"weixin":{"title":"\\u4e0a\\u4f20\\u5fae\\u4fe1\\u4e8c\\u7ef4\\u7801","value":"","type":"image","tip":""},"weibo":{"title":"\\u5fae\\u535a\\u53f7","value":"","type":"text","tip":""}}}}}', NULL),
(130, 0, 6, 'canyin', '品牌：Holyfan好饭', 'portal/List/index', 'portal/brand3', '品牌页模板文件', '{"vars":{"ads":{"title":"\\u9876\\u90e8\\u5e7f\\u544a\\u56fe","value":"","type":"image","tip":"\\uff08\\u5efa\\u8bae\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a1920px*500px\\uff09"}},"widgets":{"mainbox":{"title":"\\u9876\\u90e8\\u63a8\\u8350\\u6a21\\u5757","display":1,"vars":{"mainlogo":{"title":"\\u54c1\\u724clogo","value":"admin\\/20171029\\/dfabae926653d7d5fae98b1e5b2bb8ac.png","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a220px*220px)"},"mainthumb":{"title":"\\u54c1\\u724c\\u4e3b\\u56fe","value":"admin\\/20171029\\/92e4b0f9ade6266b3c13a31b59e3efb6.png","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a375px*340px)"},"description":{"title":"\\u54c1\\u724c\\u4ecb\\u7ecd","value":"Holyfan\\u897f\\u73ed\\u7259\\u6d77\\u9c9c\\u996d\\uff0c\\u4e3b\\u8425\\u597d\\u597d\\u5403\\u7684\\u996d\\uff0c\\u798f\\u5dde\\u51712\\u5bb6\\u5206\\u5e97","type":"textarea","tip":""}}},"product":{"title":"\\u83dc\\u54c1","display":1,"vars":{"products":{"title":"\\u83dc\\u54c1\\u7ba1\\u7406","value":[{"title":"\\u897f\\u73ed\\u7259\\u70e9\\u996d","description":"\\u4ee5\\u7c73\\u996d\\u3001\\u65b0\\u9c9c\\u5e72\\u8d1d\\u4e3a\\u4e3b\\u8981\\u98df\\u6750\\u91c7\\u7528\\u591a\\u79cd\\u6d77\\u9c9c\\uff0c\\u53e3\\u611f\\u4e30\\u5bcc","thumb":"admin\\/20171029\\/1fb88dc4b8efb2cc0c47016c56de7822.png"},{"title":"\\u897f\\u73ed\\u7259\\u70e9\\u996d","description":"\\u4ee5\\u7c73\\u996d\\u3001\\u65b0\\u9c9c\\u5e72\\u8d1d\\u4e3a\\u4e3b\\u8981\\u98df\\u6750\\u91c7\\u7528\\u591a\\u79cd\\u6d77\\u9c9c\\uff0c\\u53e3\\u611f\\u4e30\\u5bcc","thumb":"admin\\/20171029\\/45c6ca4a5a2998ab20a4a5382fc1cafa.png"},{"title":"\\u897f\\u73ed\\u7259\\u70e9\\u996d","description":"\\u4ee5\\u7c73\\u996d\\u3001\\u65b0\\u9c9c\\u5e72\\u8d1d\\u4e3a\\u4e3b\\u8981\\u98df\\u6750\\u91c7\\u7528\\u591a\\u79cd\\u6d77\\u9c9c\\uff0c\\u53e3\\u611f\\u4e30\\u5bcc","thumb":"admin\\/20171029\\/b6bb274a401fac6a711d57774359394f.png"}],"type":"array","item":{"title":{"title":"\\u83dc\\u54c1\\u540d\\u79f0","value":"","type":"text"},"description":{"title":"\\u83dc\\u54c1\\u4ecb\\u7ecd","value":"","type":"textarea"},"thumb":{"title":"\\u83dc\\u54c1\\u4e3b\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a770px*510px)"}},"tip":""}}},"xingxiang":{"title":"\\u5f62\\u8c61\\u76f8\\u518c","display":1,"vars":{"xingxiangs":{"title":"\\u76f8\\u518c\\u7ba1\\u7406","value":[{"thumb":"admin\\/20171029\\/3e5719548e9ef906494e8f89c63e98ae.png"}],"type":"array","item":{"thumb":{"title":"\\u76f8\\u518c\\u4e0a\\u4f20","value":"","type":"image"}},"tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a530px*325px)"}}},"mengdian":{"title":"\\u95e8\\u5e97\\u5206\\u5e03","display":1,"vars":{"shophome":{"title":"\\u95e8\\u5e97\\u7ba1\\u7406","value":[{"name":"\\u4e16\\u6b27\\u5e7f\\u573a\\u5e97","shop_location_text_":"\\u798f\\u5efa\\u7701\\u798f\\u5dde\\u5e02\\u664b\\u5b89\\u533a\\u7ad9\\u4e1c\\u8def","shop_location":"119.332646,26.121127"},{"name":"\\u4e16\\u6b27\\u5e7f\\u573a\\u5e97","shop_location_text_":"\\u798f\\u5efa\\u7701\\u798f\\u5dde\\u5e02\\u9f13\\u697c\\u533a\\u897f\\u4e8c\\u73af\\u5317\\u8def200\\u53f7","shop_location":"119.286223,26.094187"}],"type":"array","item":{"name":{"title":"\\u95e8\\u5e97\\u540d\\u79f0","value":"","type":"text"},"shop_location":{"title":"\\u95e8\\u5e97\\u5750\\u6807","value":"","type":"location","tip":""}},"tip":""},"phone":{"title":"\\u52a0\\u76df\\u70ed\\u7ebf","value":"137-1234-5678","type":"text","tip":""},"qq":{"title":"QQ\\u53f7\\u7801","value":"78787676","type":"text","tip":""},"weixin":{"title":"\\u4e0a\\u4f20\\u5fae\\u4fe1\\u4e8c\\u7ef4\\u7801","value":"admin\\/20171027\\/abd96d82f9473df35fbb8f31a1b3187d.png","type":"image","tip":""},"weibo":{"title":"\\u5fae\\u535a\\u53f7","value":"604749526","type":"text","tip":""}}}}}', '{"vars":{"ads":{"title":"\\u9876\\u90e8\\u5e7f\\u544a\\u56fe","value":"","type":"image","tip":"\\uff08\\u5efa\\u8bae\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a1920px*500px\\uff09"}},"widgets":{"mainbox":{"title":"\\u9876\\u90e8\\u63a8\\u8350\\u6a21\\u5757","display":"1","vars":{"mainlogo":{"title":"\\u54c1\\u724clogo","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a220px*220px)"},"mainthumb":{"title":"\\u54c1\\u724c\\u4e3b\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a375px*340px)"},"description":{"title":"\\u54c1\\u724c\\u4ecb\\u7ecd","value":"","type":"textarea","tip":""}}},"product":{"title":"\\u83dc\\u54c1","display":"1","vars":{"products":{"title":"\\u83dc\\u54c1\\u7ba1\\u7406","value":[],"type":"array","item":{"title":{"title":"\\u83dc\\u54c1\\u540d\\u79f0","value":"","type":"text"},"description":{"title":"\\u83dc\\u54c1\\u4ecb\\u7ecd","value":"","type":"textarea"},"thumb":{"title":"\\u83dc\\u54c1\\u4e3b\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a770px*510px)"}},"tip":""}}},"xingxiang":{"title":"\\u5f62\\u8c61\\u76f8\\u518c","display":"1","vars":{"xingxiangs":{"title":"\\u76f8\\u518c\\u7ba1\\u7406","value":[],"type":"array","item":{"thumb":{"title":"\\u76f8\\u518c\\u4e0a\\u4f20","value":"","type":"image"}},"tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a530px*325px)"}}},"mengdian":{"title":"\\u95e8\\u5e97\\u5206\\u5e03","display":"1","vars":{"shophome":{"title":"\\u95e8\\u5e97\\u7ba1\\u7406","value":[],"type":"array","item":{"name":{"title":"\\u95e8\\u5e97\\u540d\\u79f0","value":"","type":"text"},"shop_location":{"title":"\\u95e8\\u5e97\\u5750\\u6807","value":"","type":"location","tip":""}},"tip":""},"phone":{"title":"\\u52a0\\u76df\\u70ed\\u7ebf","value":"","type":"text","tip":""},"qq":{"title":"QQ\\u53f7\\u7801","value":"","type":"text","tip":""},"weixin":{"title":"\\u4e0a\\u4f20\\u5fae\\u4fe1\\u4e8c\\u7ef4\\u7801","value":"","type":"image","tip":""},"weibo":{"title":"\\u5fae\\u535a\\u53f7","value":"","type":"text","tip":""}}}}}', NULL),
(115, 0, 1, 'canyin', '首页', 'portal/Index/index', 'portal/index', '配置首页模板文件', '{"vars":{"top_slide":{"title":"\\u9876\\u90e8\\u5e7b\\u706f\\u7247","value":"1","type":"text","dataSource":{"api":"admin\\/Slide\\/index","multi":false},"placeholder":"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247","tip":"","rule":{"require":true},"valueText":"\\u9996\\u9875\\u8f6e\\u64ad\\u56fe"}},"widgets":{"brand":{"title":"\\u4e09\\u5927\\u54c1\\u724c","display":1,"vars":{"brands":{"title":"\\u4e09\\u5927\\u54c1\\u724c","value":[{"title":"\\u7559\\u840c\\u65e5\\u5f0f\\u706b\\u9505","url":"\\/lmrshg.html","thumb":"admin\\/20171027\\/cb1276fabfe49d3cf4bc173e3e58670f.png"},{"title":"\\u8fd9\\u91cc\\u6709\\u610f\\u5f0f\\u9910\\u5385","url":"\\/zlyysct.html","thumb":"admin\\/20171027\\/92a88d68b7d912c014c060b69e1fea02.png"},{"title":"Holyfan\\u597d\\u996d","url":"\\/holyfan.html","thumb":"admin\\/20171027\\/e987b1049d914dbe6557673b63d2e014.png"}],"type":"array","item":{"title":{"title":"\\u54c1\\u724c\\u540d\\u79f0","value":"","type":"text","rule":{"require":true}},"url":{"title":"\\u54c1\\u724c\\u94fe\\u63a5","value":"","type":"text"},"thumb":{"title":"\\u54c1\\u724c\\u4e3b\\u56fe","value":"","type":"image"}},"tip":""}}},"companyinfo":{"title":"\\u516c\\u53f8\\u7b80\\u4ecb","display":1,"vars":{"top_content":{"title":"\\u9876\\u90e8\\u6587\\u5b57\\u8bf4\\u660e","value":"\\u201c\\u798f\\u5dde\\u8fd9\\u91cc\\u6709\\u9910\\u996e\\u7ba1\\u7406\\u6709\\u9650\\u516c\\u53f8\\u201d\\u521b\\u7acb\\u4e8e2015\\u5e744\\u6708\\uff0c\\u65d7\\u4e0b\\u6700\\u65e9\\u54c1\\u724c\\u201c\\u8fd9\\u91cc\\u6709\\u610f\\u5f0f\\u9910\\u5385\\u201d\\u662f\\u4e00\\u5bb6\\u4f4d\\u4e8e\\u798f\\u5dde\\u4e94\\u56db\\u8def\\u4e0a\\u4e00\\u4e2a\\u50fb\\u9759\\u5c0f\\u5df7\\u91cc\\u7684\\u7eff\\u8272\\u9910\\u5385\\uff0c\\u51ed\\u501f\\u65b0\\u9c9c\\u7684\\u98df\\u6750\\u3001\\u7b80\\u7ea6\\u7684\\u73af\\u5883\\u4ee5\\u53ca\\u521b\\u65b0\\u7684\\u4e92\\u8054\\u7f51\\u4e92\\u52a8\\u65b9\\u5f0f\\uff0c\\u6e05\\u65b0\\u6021\\u4eba\\u800c\\u53c8\\u65f6\\u5c1a\\u6709\\u8da3\\uff0c\\u83b7\\u5f97\\u4f17\\u591a\\u6d88\\u8d39\\u8005\\u7684\\u9752\\u7750\\uff0c\\u201c\\u8fd9\\u91cc\\u6709\\u201d\\u7ecf\\u8425\\u4ee5\\u610f\\u5927\\u5229\\u9762\\u4e3a\\u4e3b\\uff0c\\u6c99\\u62c9\\uff0c\\u996d\\u7c7b\\uff0c\\u7279\\u8272\\u5c0f\\u5403\\u4e3a\\u8f85\\uff0c\\u503e\\u5fc3\\u6253\\u9020\\u6700\\u5730\\u9053\\u7684\\u610f\\u5f0f\\u6599\\u7406\\u3002","type":"textarea","placeholder":"\\u8bf7\\u8f93\\u5165\\u8bf4\\u660e\\u5185\\u5bb9","tip":""},"bottom_content":{"title":"\\u5c3e\\u90e8\\u6587\\u5b57\\u8bf4\\u660e","value":"\\u8fd9\\u662f\\u4e00\\u5bb6\\u975e\\u5e38\\u6709\\u6f5c\\u529b\\u548c\\u5b9e\\u529b\\u7684\\u9910\\u996e\\u7ba1\\u7406\\u516c\\u53f8\\uff0c\\u201c\\u8fd9\\u91cc\\u6709\\u201d\\u7684\\u6838\\u5fc3\\u56e2\\u961f\\u4eba\\u5458\\u5747\\u67095\\u5e74\\u4ee5\\u4e0a\\u9910\\u996e\\u884c\\u4e1a\\u76f8\\u5173\\u7684\\u4ece\\u4e1a\\u7ecf\\u9a8c\\uff0c\\u79c9\\u6301\\u201c\\u8ba9\\u4f60\\u610f\\u4eab\\u4e0d\\u5230\\u201d\\u7684\\u54c1\\u724c\\u7406\\u5ff5\\uff0c\\u575a\\u6301\\u505a\\u597d\\u6599\\u7406\\uff0c\\u8425\\u9020\\u51fa\\u65f6\\u5c1a\\u3001\\u8f7b\\u677e\\u3001\\u6709\\u8da3\\u7684\\u6c1b\\u56f4\\uff0c\\u6fc0\\u53d1\\u7075\\u611f\\uff0c\\u5ef6\\u4f38\\u5feb\\u4e50\\uff0c\\u5f15\\u9886\\u5065\\u5eb7\\u4e50\\u6d3b\\u7684\\u751f\\u6d3b\\u65b9\\u5f0f\\u3002","type":"textarea","placeholder":"\\u8bf7\\u8f93\\u5165\\u8bf4\\u660e\\u5185\\u5bb9","tip":""},"brand":{"title":"\\u4e09\\u5927\\u54c1\\u724c","value":[{"title":"Holyfan\\u597d\\u996d","url":"\\/holyfan.html","content":"Holyfan\\u897f\\u73ed\\u7259\\u6d77\\u9c9c\\u996d\\uff0c\\u4e3b\\u8425\\u597d\\u597d\\u5403\\u7684\\u996d\\uff0c\\u798f\\u5dde\\u51712\\u5bb6\\u5206\\u5e97","logo":"admin\\/20171028\\/2045d89c7b21a2be93f0bf069e1538b1.png","thumb":"admin\\/20171028\\/b7bc341f4cc542522118abde7da83a0f.png"},{"title":"\\u7559\\u840c\\u65e5\\u5f0f\\u706b\\u9505","url":"\\/lmrshg.html","content":"Holyfan\\u897f\\u73ed\\u7259\\u6d77\\u9c9c\\u996d\\uff0c\\u4e3b\\u8425\\u597d\\u597d\\u5403\\u7684\\u996d\\uff0c\\u798f\\u5dde\\u51712\\u5bb6\\u5206\\u5e97","logo":"admin\\/20171028\\/179212cdbbdabbf98562285f4da060d6.png","thumb":"admin\\/20171028\\/ad38a610db48a0b191e5cea341cd06fa.png"},{"title":"\\u8fd9\\u91cc\\u6709\\u610f\\u5f0f\\u9910\\u5385","url":"\\/zlyysct.html","content":"Holyfan\\u897f\\u73ed\\u7259\\u6d77\\u9c9c\\u996d\\uff0c\\u4e3b\\u8425\\u597d\\u597d\\u5403\\u7684\\u996d\\uff0c\\u798f\\u5dde\\u51712\\u5bb6\\u5206\\u5e97","logo":"admin\\/20171028\\/40ea013875f97b1a7688bfea3af91d70.png","thumb":"admin\\/20171028\\/750ef4388ccf76682156daa8130096c0.png"}],"type":"array","item":{"title":{"title":"\\u54c1\\u724c\\u540d\\u79f0","value":"","type":"text"},"url":{"title":"\\u54c1\\u724c\\u94fe\\u63a5","value":"","type":"text"},"content":{"title":"\\u54c1\\u724c\\u63cf\\u8ff0","value":"","type":"textarea"},"logo":{"title":"\\u54c1\\u724clogo","value":"","type":"image"},"thumb":{"title":"\\u54c1\\u724c\\u4e3b\\u56fe","value":"","type":"image"}},"tip":""}}},"last_news":{"title":"\\u6700\\u65b0\\u8d44\\u8baf","display":1,"vars":{"last_news_category_id":{"title":"\\u6587\\u7ae0\\u5206\\u7c7bID","value":"2,3,4","type":"text","dataSource":{"api":"portal\\/category\\/index","multi":true},"placeholder":"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b","tip":"","valueText":"\\u65b0\\u95fb\\u4e2d\\u5fc3,\\u65b0\\u54c1\\u4e0a\\u5e02,\\u4f01\\u4e1a\\u52a8\\u6001"}}},"contact":{"title":"\\u8054\\u7cfb\\u6211\\u4eec","display":1,"vars":{"company_location":{"title":"\\u516c\\u53f8\\u5750\\u6807","value":"119.253173,26.01181","type":"location","tip":"","valueText":"\\u798f\\u5efa\\u7701\\u798f\\u5dde\\u5e02\\u95fd\\u4faf\\u53bf"},"address":{"title":"\\u8054\\u7cfb\\u5730\\u5740","value":"\\u798f\\u5efa\\u7701\\u798f\\u5dde\\u5e02\\u4ed3\\u5c71\\u533a\\u798f\\u5efa\\u7701\\u798f\\u5dde\\u5e02\\u4ed3\\u5c71\\u533a","type":"text","tip":""},"phone":{"title":"\\u8054\\u7cfb\\u7535\\u8bdd","value":"15676765654","type":"text","tip":""}}}}}', '{"vars":{"top_slide":{"title":"\\u9876\\u90e8\\u5e7b\\u706f\\u7247","value":"","type":"text","dataSource":{"api":"admin\\/Slide\\/index","multi":false},"placeholder":"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247","tip":"","rule":{"require":true}}},"widgets":{"brand":{"title":"\\u4e09\\u5927\\u54c1\\u724c","display":"1","vars":{"brands":{"title":"\\u4e09\\u5927\\u54c1\\u724c","value":[],"type":"array","item":{"title":{"title":"\\u54c1\\u724c\\u540d\\u79f0","value":"","type":"text","rule":{"require":true}},"url":{"title":"\\u54c1\\u724c\\u94fe\\u63a5","value":"","type":"text"},"thumb":{"title":"\\u54c1\\u724c\\u4e3b\\u56fe","value":"","type":"image"}},"tip":""}}},"companyinfo":{"title":"\\u516c\\u53f8\\u7b80\\u4ecb","display":"1","vars":{"top_content":{"title":"\\u9876\\u90e8\\u6587\\u5b57\\u8bf4\\u660e","value":"","type":"textarea","placeholder":"\\u8bf7\\u8f93\\u5165\\u8bf4\\u660e\\u5185\\u5bb9","tip":""},"bottom_content":{"title":"\\u5c3e\\u90e8\\u6587\\u5b57\\u8bf4\\u660e","value":"","type":"textarea","placeholder":"\\u8bf7\\u8f93\\u5165\\u8bf4\\u660e\\u5185\\u5bb9","tip":""},"brand":{"title":"\\u4e09\\u5927\\u54c1\\u724c","value":[],"type":"array","item":{"title":{"title":"\\u54c1\\u724c\\u540d\\u79f0","value":"","type":"text"},"url":{"title":"\\u54c1\\u724c\\u94fe\\u63a5","value":"","type":"text"},"content":{"title":"\\u54c1\\u724c\\u63cf\\u8ff0","value":"","type":"textarea"},"logo":{"title":"\\u54c1\\u724clogo","value":"","type":"image"},"thumb":{"title":"\\u54c1\\u724c\\u4e3b\\u56fe","value":"","type":"image"}},"tip":""}}},"last_news":{"title":"\\u6700\\u65b0\\u8d44\\u8baf","display":"1","vars":{"last_news_category_id":{"title":"\\u6587\\u7ae0\\u5206\\u7c7bID","value":"","type":"text","dataSource":{"api":"portal\\/category\\/index","multi":true},"placeholder":"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b","tip":""}}},"contact":{"title":"\\u8054\\u7cfb\\u6211\\u4eec","display":"1","vars":{"company_location":{"title":"\\u516c\\u53f8\\u5750\\u6807","value":"","type":"location","tip":""},"address":{"title":"\\u8054\\u7cfb\\u5730\\u5740","value":"","type":"text","tip":""},"phone":{"title":"\\u8054\\u7cfb\\u7535\\u8bdd","value":"","type":"text","tip":""}}}}}', NULL),
(128, 0, 4, 'canyin', '品牌：留萌日式火锅', 'portal/List/index', 'portal/brand1', '品牌页模板文件', '{"vars":{"ads":{"title":"\\u9876\\u90e8\\u5e7f\\u544a\\u56fe","value":"admin\\/20171029\\/ffbcbabaa7280cda69534bfac0327661.png","type":"image","tip":"\\uff08\\u5efa\\u8bae\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a1920px*500px\\uff09"}},"widgets":{"mainbox":{"title":"\\u9876\\u90e8\\u63a8\\u8350\\u6a21\\u5757","display":1,"vars":{"mainlogo":{"title":"\\u54c1\\u724clogo","value":"admin\\/20171029\\/dfabae926653d7d5fae98b1e5b2bb8ac.png","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a220px*220px)"},"mainthumb":{"title":"\\u54c1\\u724c\\u4e3b\\u56fe","value":"admin\\/20171029\\/92e4b0f9ade6266b3c13a31b59e3efb6.png","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a375px*340px)"},"description":{"title":"\\u54c1\\u724c\\u4ecb\\u7ecd","value":"Holyfan\\u897f\\u73ed\\u7259\\u6d77\\u9c9c\\u996d\\uff0c\\u4e3b\\u8425\\u597d\\u597d\\u5403\\u7684\\u996d\\uff0c\\u798f\\u5dde\\u51712\\u5bb6\\u5206\\u5e97","type":"textarea","tip":""}}},"product":{"title":"\\u83dc\\u54c1","display":1,"vars":{"products":{"title":"\\u83dc\\u54c1\\u7ba1\\u7406","value":[{"title":"\\u897f\\u73ed\\u7259\\u70e9\\u996d","description":"\\u4ee5\\u7c73\\u996d\\u3001\\u65b0\\u9c9c\\u5e72\\u8d1d\\u4e3a\\u4e3b\\u8981\\u98df\\u6750\\u91c7\\u7528\\u591a\\u79cd\\u6d77\\u9c9c\\uff0c\\u53e3\\u611f\\u4e30\\u5bcc","thumb":"admin\\/20171029\\/1fb88dc4b8efb2cc0c47016c56de7822.png"},{"title":"\\u897f\\u73ed\\u7259\\u70e9\\u996d","description":"\\u4ee5\\u7c73\\u996d\\u3001\\u65b0\\u9c9c\\u5e72\\u8d1d\\u4e3a\\u4e3b\\u8981\\u98df\\u6750\\u91c7\\u7528\\u591a\\u79cd\\u6d77\\u9c9c\\uff0c\\u53e3\\u611f\\u4e30\\u5bcc","thumb":"admin\\/20171029\\/45c6ca4a5a2998ab20a4a5382fc1cafa.png"},{"title":"\\u897f\\u73ed\\u7259\\u70e9\\u996d","description":"\\u4ee5\\u7c73\\u996d\\u3001\\u65b0\\u9c9c\\u5e72\\u8d1d\\u4e3a\\u4e3b\\u8981\\u98df\\u6750\\u91c7\\u7528\\u591a\\u79cd\\u6d77\\u9c9c\\uff0c\\u53e3\\u611f\\u4e30\\u5bcc","thumb":"admin\\/20171029\\/b6bb274a401fac6a711d57774359394f.png"}],"type":"array","item":{"title":{"title":"\\u83dc\\u54c1\\u540d\\u79f0","value":"","type":"text"},"description":{"title":"\\u83dc\\u54c1\\u4ecb\\u7ecd","value":"","type":"textarea"},"thumb":{"title":"\\u83dc\\u54c1\\u4e3b\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a770px*510px)"}},"tip":""}}},"xingxiang":{"title":"\\u5f62\\u8c61\\u76f8\\u518c","display":1,"vars":{"xingxiangs":{"title":"\\u76f8\\u518c\\u7ba1\\u7406","value":[{"thumb":"admin\\/20171029\\/abd2b61f44cae79827f08c360a253bfe.png"},{"thumb":"admin\\/20171029\\/3e5719548e9ef906494e8f89c63e98ae.png"},{"thumb":"admin\\/20171029\\/abd2b61f44cae79827f08c360a253bfe.png"},{"thumb":"admin\\/20171029\\/3e5719548e9ef906494e8f89c63e98ae.png"},{"thumb":"admin\\/20171029\\/abd2b61f44cae79827f08c360a253bfe.png"},{"thumb":"admin\\/20171029\\/3e5719548e9ef906494e8f89c63e98ae.png"}],"type":"array","item":{"thumb":{"title":"\\u76f8\\u518c\\u4e0a\\u4f20","value":"","type":"image"}},"tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a530px*325px)"}}},"mengdian":{"title":"\\u95e8\\u5e97\\u5206\\u5e03","display":1,"vars":{"shophome":{"title":"\\u95e8\\u5e97\\u7ba1\\u7406","value":[{"name":"\\u4e16\\u6b27\\u5e7f\\u573a\\u5e97","shop_location_text_":"\\u798f\\u5efa\\u7701\\u798f\\u5dde\\u5e02\\u664b\\u5b89\\u533a\\u9f99\\u5b89\\u8def198\\u53f7","shop_location":"119.344934,26.103529"},{"name":"\\u4e16\\u6b27\\u5e7f\\u573a\\u5e97","shop_location_text_":"\\u798f\\u5efa\\u7701\\u798f\\u5dde\\u5e02\\u4ed3\\u5c71\\u533a","shop_location":"119.398548,26.001318"}],"type":"array","item":{"name":{"title":"\\u95e8\\u5e97\\u540d\\u79f0","value":"","type":"text"},"shop_location":{"title":"\\u95e8\\u5e97\\u5750\\u6807","value":"","type":"location","tip":""}},"tip":""},"phone":{"title":"\\u52a0\\u76df\\u70ed\\u7ebf","value":"137-1234-5678","type":"text","tip":""},"qq":{"title":"QQ\\u53f7\\u7801","value":"604749526","type":"text","tip":""},"weixin":{"title":"\\u4e0a\\u4f20\\u5fae\\u4fe1\\u4e8c\\u7ef4\\u7801","value":"admin\\/20171027\\/abd96d82f9473df35fbb8f31a1b3187d.png","type":"image","tip":""},"weibo":{"title":"\\u5fae\\u535a\\u53f7","value":"lolxy2010@163.com","type":"text","tip":""}}}}}', '{"vars":{"ads":{"title":"\\u9876\\u90e8\\u5e7f\\u544a\\u56fe","value":"","type":"image","tip":"\\uff08\\u5efa\\u8bae\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a1920px*500px\\uff09"}},"widgets":{"mainbox":{"title":"\\u9876\\u90e8\\u63a8\\u8350\\u6a21\\u5757","display":"1","vars":{"mainlogo":{"title":"\\u54c1\\u724clogo","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a220px*220px)"},"mainthumb":{"title":"\\u54c1\\u724c\\u4e3b\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a375px*340px)"},"description":{"title":"\\u54c1\\u724c\\u4ecb\\u7ecd","value":"","type":"textarea","tip":""}}},"product":{"title":"\\u83dc\\u54c1","display":"1","vars":{"products":{"title":"\\u83dc\\u54c1\\u7ba1\\u7406","value":[],"type":"array","item":{"title":{"title":"\\u83dc\\u54c1\\u540d\\u79f0","value":"","type":"text"},"description":{"title":"\\u83dc\\u54c1\\u4ecb\\u7ecd","value":"","type":"textarea"},"thumb":{"title":"\\u83dc\\u54c1\\u4e3b\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a770px*510px)"}},"tip":""}}},"xingxiang":{"title":"\\u5f62\\u8c61\\u76f8\\u518c","display":"1","vars":{"xingxiangs":{"title":"\\u76f8\\u518c\\u7ba1\\u7406","value":[],"type":"array","item":{"thumb":{"title":"\\u76f8\\u518c\\u4e0a\\u4f20","value":"","type":"image"}},"tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a530px*325px)"}}},"mengdian":{"title":"\\u95e8\\u5e97\\u5206\\u5e03","display":"1","vars":{"shophome":{"title":"\\u95e8\\u5e97\\u7ba1\\u7406","value":[],"type":"array","item":{"name":{"title":"\\u95e8\\u5e97\\u540d\\u79f0","value":"","type":"text"},"shop_location":{"title":"\\u95e8\\u5e97\\u5750\\u6807","value":"","type":"location","tip":""}},"tip":""},"phone":{"title":"\\u52a0\\u76df\\u70ed\\u7ebf","value":"","type":"text","tip":""},"qq":{"title":"QQ\\u53f7\\u7801","value":"","type":"text","tip":""},"weixin":{"title":"\\u4e0a\\u4f20\\u5fae\\u4fe1\\u4e8c\\u7ef4\\u7801","value":"","type":"image","tip":""},"weibo":{"title":"\\u5fae\\u535a\\u53f7","value":"","type":"text","tip":""}}}}}', NULL),
(119, 1, 0, 'canyin', '模板全局配置', 'public/Config', 'public/config', '模板全局配置文件', '{"vars":[]}', '{"vars":[]}', NULL),
(121, 0, 2, 'canyin', '关于我们页面', 'portal/Page/index', 'portal/about', '配置关于我们页面', '{"widgets":{"zheliyou":{"title":"\\u8fd9\\u91cc\\u6709","display":1,"vars":{"main_thumb":{"title":"\\u4e3b\\u56fe\\u4e0a\\u4f20","value":"admin\\/20171029\\/63c7e3f8a8bf58a0545232e1e7dee2e6.png","type":"image","tip":""},"description":{"title":"\\u8bf4\\u660e\\u6587\\u5b57","value":"&lt;p&gt;\\u201c\\u8fd9\\u91cc\\u6709\\u201d\\uff0c\\u8fd9\\u4e2a\\u54c1\\u724c\\u521b\\u4f5c\\u7684\\u521d\\u8877\\u662f\\u767d\\u8bdd\\u6587\\u7684\\u4ee3\\u8a00\\u8bcd\\uff0c\\u767e\\u5ea6\\u641c\\u7d22\\u9ad8\\u8fbe1\\u4ebf\\u4ee5\\u4e0a\\uff0c\\u662f\\u5929\\u7136\\u7684\\u8d85\\u7ea7\\u5927IP\\u3002\\u201c\\u8fd9\\u91cc\\u6709\\u610f\\u9762\\u201d\\u3001\\u201c\\u8fd9\\u91cc\\u6709\\u897f\\u9910\\u201d\\u3001\\u201c\\u53bb\\u8fd9\\u91cc\\u6709\\u201d\\u3001\\u201c\\u8fd9\\u91cc\\u6709XXX\\u201d\\u8fd9\\u91cc\\u6709\\u80fd\\u4e0e\\u4efb\\u4f55\\u4e8b\\u7269\\u94fe\\u63a5\\uff0c\\u4e0e\\u5f53\\u4e0b\\u975e\\u5e38\\u6d41\\u884c\\u7684\\u4e92\\u8054\\u7f51\\u601d\\u7ef4\\u975e\\u5e38\\u543b\\u5408\\uff0c\\u800c\\u56e2\\u961f\\u770b\\u4e2d\\u201c\\u8fd9\\u91cc\\u6709\\u201d\\u8fd9\\u4e2a\\u5929\\u7136\\u8d85\\u7ea7\\u5927IP\\u8ba9\\u6d88\\u8d39\\u8005\\u5bf9\\u54c1\\u724c\\u7684\\u719f\\u6089\\u548c\\u8ba4\\u77e5\\u6539\\u53d8\\u3002&lt;\\/p&gt;\\r\\n\\r\\n&lt;p&gt;\\u201c\\u8fd9\\u91cc\\u6709\\u201d\\u521b\\u7acb\\u4e8e2015\\u5e744\\u6708\\uff0c\\u6700\\u65e9\\u662f\\u4e00\\u5bb6\\u4f4d\\u4e8e\\u798f\\u5dde\\u4e94\\u56db\\u8def\\u4e0a\\u4e00\\u4e2a\\u504f\\u50fb\\u5c0f\\u5df7\\u91cc\\u7684\\u7eff\\u8272\\u9910\\u5385\\uff0c\\u7ecf\\u8425\\u4ee5\\u610f\\u5927\\u5229\\u9762\\u4e3a\\u4e3b\\uff0c\\u6c99\\u62c9\\uff0c\\u996d\\u7c7b\\uff0c\\u7279\\u8272\\u5c0f\\u5403\\u4e3a\\u8f85\\uff0c\\u503e\\u5fc3\\u6253\\u9020\\u6700\\u5730\\u9053\\u7684\\u610f\\u5f0f\\u6599\\u7406\\u3002\\u8fd9\\u91cc\\u6709\\u7684\\u6838\\u5fc3\\u56e2\\u961f\\u4eba\\u5458\\u5747\\u6709\\u4e94\\u5e74\\u4ee5\\u4e0a\\u4e0e\\u9910\\u996e\\u4e1a\\u76f8\\u5173\\u7684\\u4ece\\u4e1a\\u7ecf\\u9a8c\\uff0c\\u79c9\\u6301\\u8ba9\\u201c\\u8fd9\\u91cc\\u6709\\uff0c\\u975e\\u5e38\\u597d\\u5403\\u7684\\u610f\\u9762\\u201d\\u7684\\u4ea7\\u54c1\\u7406\\u5ff5\\uff0c\\u5c06\\u5404\\u81ea\\u5bf9\\u7f8e\\u98df\\u3001\\u8bbe\\u8ba1\\u3001\\u8425\\u9500\\u3001\\u7ba1\\u7406\\u7b49\\u65b9\\u9762\\u7684\\u4e13\\u957f\\u53d1\\u6325\\u5230\\u6781\\u81f4\\uff0c\\u4e13\\u6ce8\\u4e8e\\u6bcf\\u4e2a\\u7ec6\\u8282\\u3002\\u76ee\\u524d\\u201c\\u8fd9\\u91cc\\u6709\\u201d\\u5728\\u798f\\u5dde\\u62e5\\u67095\\u5bb6\\u76f4\\u8425\\u95e8\\u5e97\\u548c\\u767e\\u540d\\u5458\\u5de5\\uff0c\\u6b63\\u5904\\u4e8e\\u98de\\u901f\\u6210\\u957f\\u9636\\u6bb5\\uff0c\\u662f\\u4e00\\u5bb6\\u5177\\u6709\\u826f\\u597d\\u53d1\\u5c55\\u548c\\u6f5c\\u529b\\u7684\\u4f01\\u4e1a\\u3002&lt;\\/p&gt;","type":"textarea","tip":""}}},"terms":{"title":"\\u56e2\\u961f","display":1,"vars":{"itemarray":{"title":"\\u56e2\\u961f\\u6210\\u5458","value":[{"title":"\\u9648\\u957f\\u751f","description":"\\u8fd9\\u91cc\\u6709\\u521b\\u59cb\\u4eba\\u517c\\u4ea7\\u54c1\\u603b\\u76d1&lt;br&gt;\\u90fd\\u8bf4\\u7537\\u4eba\\u6700\\u5e05\\u7684\\u65f6\\u5019\\u662f\\u5728\\u53a8\\u623f&lt;br&gt;\\u8ba4\\u771f\\u505a\\u996d\\u7684\\u65f6\\u5019&lt;br&gt;\\u800c\\u8fd9\\u4e2a\\u8001\\u5934\\u6070\\u6070\\u5370\\u8bc1\\u4e86\\u8fd9\\u4e2a\\u8bdd&lt;br&gt;\\u5341\\u51e0\\u5e74\\u7684\\u897f\\u9910\\u7ecf\\u9a8c&lt;br&gt;\\u66fe\\u5f53\\u4eba\\u65e5\\u672c\\u661f\\u7ea7\\u9910\\u5385\\u53a8\\u5e08\\u957f&lt;br&gt;\\u4efb\\u4f55\\u7f8e\\u5473\\u5728\\u4ed6\\u7684\\u624b\\u91cc\\u90fd\\u53d8\\u5f97\\u7b80\\u5355\\u800c\\u7f8e\\u597d","thumb":"admin\\/20171029\\/8b5486fb0caf56aeae1fe41ab33f58c2.jpg"},{"title":"\\u9648\\u957f\\u751f","description":"\\u8fd9\\u91cc\\u6709\\u521b\\u59cb\\u4eba\\u517c\\u4ea7\\u54c1\\u603b\\u76d1&lt;br&gt;\\u90fd\\u8bf4\\u7537\\u4eba\\u6700\\u5e05\\u7684\\u65f6\\u5019\\u662f\\u5728\\u53a8\\u623f&lt;br&gt;\\u8ba4\\u771f\\u505a\\u996d\\u7684\\u65f6\\u5019&lt;br&gt;\\u800c\\u8fd9\\u4e2a\\u8001\\u5934\\u6070\\u6070\\u5370\\u8bc1\\u4e86\\u8fd9\\u4e2a\\u8bdd&lt;br&gt;\\u5341\\u51e0\\u5e74\\u7684\\u897f\\u9910\\u7ecf\\u9a8c&lt;br&gt;\\u66fe\\u5f53\\u4eba\\u65e5\\u672c\\u661f\\u7ea7\\u9910\\u5385\\u53a8\\u5e08\\u957f&lt;br&gt;\\u4efb\\u4f55\\u7f8e\\u5473\\u5728\\u4ed6\\u7684\\u624b\\u91cc\\u90fd\\u53d8\\u5f97\\u7b80\\u5355\\u800c\\u7f8e\\u597d","thumb":"admin\\/20171029\\/79305a3918c7f6a2044f58576eca9d89.jpg"},{"title":"\\u9648\\u957f\\u751f","description":"\\u8fd9\\u91cc\\u6709\\u521b\\u59cb\\u4eba\\u517c\\u4ea7\\u54c1\\u603b\\u76d1&lt;br&gt;\\u90fd\\u8bf4\\u7537\\u4eba\\u6700\\u5e05\\u7684\\u65f6\\u5019\\u662f\\u5728\\u53a8\\u623f&lt;br&gt;\\u8ba4\\u771f\\u505a\\u996d\\u7684\\u65f6\\u5019&lt;br&gt;\\u800c\\u8fd9\\u4e2a\\u8001\\u5934\\u6070\\u6070\\u5370\\u8bc1\\u4e86\\u8fd9\\u4e2a\\u8bdd&lt;br&gt;\\u5341\\u51e0\\u5e74\\u7684\\u897f\\u9910\\u7ecf\\u9a8c&lt;br&gt;\\u66fe\\u5f53\\u4eba\\u65e5\\u672c\\u661f\\u7ea7\\u9910\\u5385\\u53a8\\u5e08\\u957f&lt;br&gt;\\u4efb\\u4f55\\u7f8e\\u5473\\u5728\\u4ed6\\u7684\\u624b\\u91cc\\u90fd\\u53d8\\u5f97\\u7b80\\u5355\\u800c\\u7f8e\\u597d","thumb":"admin\\/20171029\\/c206f8501714d7c3cdbe565838a973eb.jpg"}],"type":"array","item":{"title":{"title":"\\u59d3\\u540d","value":"","type":"text"},"description":{"title":"\\u4e2a\\u4eba\\u4ecb\\u7ecd","value":"","type":"textarea"},"thumb":{"title":"\\u54c1\\u724c\\u4e3b\\u56fe","value":"","type":"image"}},"tip":""}}},"linian":{"title":"\\u4f01\\u4e1a\\u7406\\u5ff5","display":1,"vars":{"linianarray":{"title":"\\u4f01\\u4e1a\\u7406\\u5ff5","value":[{"title":"\\u54c1\\u724c-\\u5851\\u9020\\u6587\\u5316","description":"\\u8fd9\\u91cc\\u6709\\u59cb\\u7ec8\\u5c06\\u6bcf\\u9879\\u4ea7\\u54c1\\u7684\\u54c1\\u8d28\\u653e\\u5728\\u7b2c\\u4e00\\u4f4d&lt;br&gt;\\u6bcf\\u4e00\\u9053\\u7e41\\u7410\\u7684\\u5de5\\u5e8f&lt;br&gt;\\u6bcf\\u4e00\\u6b21\\u7cbe\\u96d5\\u7ec6\\u7422\\u7684\\u70f9\\u8c03\\u4e0e\\u6446\\u76d8&lt;br&gt;\\u804c\\u4f4d\\u5c06\\u6700\\u539f\\u6c41\\u539f\\u5473\\u7684\\u7279\\u8272\\u6599\\u7406\\u53ca\\u6587\\u5316\\u54c1\\u5473\\u4f53\\u9a8c\\u5e26\\u7ed9\\u6bcf\\u4f4d\\u987e\\u5ba2","thumb":"admin\\/20171029\\/cf94769b6bc381fa8d8add144d853575.png"},{"title":"\\u4e13\\u4e1a-\\u6210\\u5c31\\u5353\\u8d8a","description":"\\u6211\\u4eec\\u4ee5\\u6211\\u4eec\\u7684\\u4e13\\u4e1a\\uff0c\\u4e3a\\u6bcf\\u4f4d\\u5ba2\\u6237\\u63d0\\u4f9b\\u6700\\u5353\\u8d8a\\u7684\\u4ea7\\u54c1\\uff0c\\u4e3a\\u6bcf\\u4f4d\\u52a0\\u76df\\u5546\\u63d0\\u4f9b\\u6700\\u5b89\\u5fc3\\u3001\\u65e0\\u5fe7\\u7684\\u4e00\\u7ad9\\u5f0f\\u79d1\\u5b66\\u7ba1\\u7406\\u670d\\u52a1","thumb":"admin\\/20171029\\/c6e6341e5a3cbffb7938fbd01f2d8fdc.png"},{"title":"\\u670d\\u52a1-\\u5f70\\u663e\\u4ef7\\u503c","description":"\\u665a\\u4e0a\\u7684\\u670d\\u52a1\\u662f\\u6700\\u597d\\u7684\\u5ba3\\u4f20\\u540d\\u7247&lt;br&gt;\\r\\n\\u8fd9\\u91cc\\u6709\\u672c\\u7740\\u5bf9\\u6bcf\\u4f4d\\u5ba2\\u6237\\u8ba4\\u77e5\\u3001\\u8d1f\\u8d23\\u7684\\u6001\\u5ea6&lt;br&gt;\\r\\n\\u4ee5\\u81f3\\u8bda\\u3001\\u611f\\u6069\\u3001\\u70ed\\u60c5\\u7684\\u7ec6\\u8282\\u670d\\u52a1&lt;br&gt;\\r\\n\\u5f70\\u663e\\u8fd9\\u91cc\\u6709\\u54c1\\u724c\\u7684\\u6587\\u5316\\u53ca\\u4ef7\\u503c","thumb":"admin\\/20171029\\/8277e9bd353205cb24ef1393b90c51b0.png"}],"type":"array","item":{"title":{"title":"\\u6807\\u9898","value":"","type":"text"},"description":{"title":"\\u7406\\u5ff5\\u4ecb\\u7ecd","value":"","type":"textarea"},"thumb":{"title":"\\u7406\\u5ff5\\u4e3b\\u56fe","value":"","type":"image"}},"tip":""}}},"licheng":{"title":"\\u5386\\u7a0b\\u8bbe\\u7f6e","display":1,"vars":{"lichengimg":{"title":"\\u5386\\u7a0b\\u56fe\\u7247","value":"admin\\/20171029\\/2e5788bac72b2ce6239ce1849099d85c.png","type":"image","tip":""}}},"contact":{"title":"\\u8054\\u7cfb\\u6211\\u4eec","display":1,"vars":{"company_location":{"title":"\\u516c\\u53f8\\u5750\\u6807","value":"119.258691,26.059092","type":"location","tip":"","valueText":"\\u798f\\u5efa\\u7701\\u798f\\u5dde\\u5e02\\u4ed3\\u5c71\\u533a\\u91d1\\u8fbe\\u8def"},"address":{"title":"\\u8054\\u7cfb\\u5730\\u5740","value":"\\u798f\\u5efa\\u7701\\u798f\\u5dde\\u5e02\\u4ed3\\u5c71\\u533a","type":"text","tip":""},"phone":{"title":"\\u8054\\u7cfb\\u7535\\u8bdd","value":"15676765654","type":"text","tip":""},"qq":{"title":"\\u8054\\u7cfbQQ","value":"1234455","type":"text","tip":""},"weixin":{"title":"\\u8054\\u7cfb\\u5fae\\u4fe1","value":"lolxy2010","type":"text","tip":""},"email":{"title":"\\u8054\\u7cfb\\u90ae\\u7bb1","value":"hjkhkjh@163.com","type":"text","tip":""}}}}}', '{"widgets":{"zheliyou":{"title":"\\u8fd9\\u91cc\\u6709","display":"1","vars":{"main_thumb":{"title":"\\u4e3b\\u56fe\\u4e0a\\u4f20","value":"","type":"image","tip":""},"description":{"title":"\\u8bf4\\u660e\\u6587\\u5b57","value":"","type":"textarea","tip":""}}},"terms":{"title":"\\u56e2\\u961f","display":"1","vars":{"itemarray":{"title":"\\u56e2\\u961f\\u6210\\u5458","value":[],"type":"array","item":{"title":{"title":"\\u59d3\\u540d","value":"","type":"text"},"description":{"title":"\\u4e2a\\u4eba\\u4ecb\\u7ecd","value":"","type":"textarea"},"thumb":{"title":"\\u54c1\\u724c\\u4e3b\\u56fe","value":"","type":"image"}},"tip":""}}},"linian":{"title":"\\u4f01\\u4e1a\\u7406\\u5ff5","display":"1","vars":{"linianarray":{"title":"\\u4f01\\u4e1a\\u7406\\u5ff5","value":[],"type":"array","item":{"title":{"title":"\\u6807\\u9898","value":"","type":"text"},"description":{"title":"\\u7406\\u5ff5\\u4ecb\\u7ecd","value":"","type":"textarea"},"thumb":{"title":"\\u7406\\u5ff5\\u4e3b\\u56fe","value":"","type":"image"}},"tip":""}}},"licheng":{"title":"\\u5386\\u7a0b\\u8bbe\\u7f6e","display":"1","vars":{"lichengimg":{"title":"\\u5386\\u7a0b\\u56fe\\u7247","value":"","type":"image","tip":""}}},"contact":{"title":"\\u8054\\u7cfb\\u6211\\u4eec","display":"1","vars":{"company_location":{"title":"\\u516c\\u53f8\\u5750\\u6807","value":"","type":"location","tip":""},"address":{"title":"\\u8054\\u7cfb\\u5730\\u5740","value":"","type":"text","tip":""},"phone":{"title":"\\u8054\\u7cfb\\u7535\\u8bdd","value":"","type":"text","tip":""},"qq":{"title":"\\u8054\\u7cfbQQ","value":"","type":"text","tip":""},"weixin":{"title":"\\u8054\\u7cfb\\u5fae\\u4fe1","value":"","type":"text","tip":""},"email":{"title":"\\u8054\\u7cfb\\u90ae\\u7bb1","value":"","type":"text","tip":""}}}}}', NULL),
(122, 0, 3, 'canyin', '招商加盟页面', 'portal/Page/index', 'portal/join', '配置招商加盟模板文件', '{"vars":{"ads":{"title":"\\u9876\\u90e8\\u5e7f\\u544a\\u56fe","value":"admin\\/20171029\\/7660d9004f2443d89450cac324760ffc.png","type":"image","tip":"\\uff08\\u5efa\\u8bae\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a1920px*500px\\uff09"}},"widgets":{"mainbox":{"title":"\\u9876\\u90e8\\u63a8\\u8350\\u6a21\\u5757","display":1,"vars":{"img1":{"title":"\\u516c\\u53f8\\u56fe\\u72471","value":"admin\\/20171029\\/84c67eb2421e0e843677bf2cbd20f9c5.jpg","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a400px*400px)"},"img2":{"title":"\\u516c\\u53f8\\u56fe\\u72472","value":"admin\\/20171029\\/77ddc38f69bdf56a3293ef48a4dea269.jpg","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a400px*400px)"},"description":{"title":"\\u516c\\u53f8\\u4ecb\\u7ecd","value":"&lt;p&gt;\\u201c\\u8fd9\\u91cc\\u6709\\u201d\\uff0c\\u8d85\\u7ea7\\u5927IP\\u7684\\u8bcd\\u6c47\\uff0c\\u4e5f\\u610f\\u5473\\u7740\\u6210\\u5343\\u4e0a\\u4e07\\u7684\\u53ef\\u80fd\\u6027\\uff1b&lt;\\/p&gt;&lt;p&gt;\\r\\n\\u8fd9\\u91cc\\u6709\\u4e0d\\u8bba\\u4ece\\u98df\\u7269\\u3001\\u670d\\u88c5\\u3001\\u9910\\u5177\\u8fd8\\u662f\\u73af\\u5883\\uff0c\\u90fd\\u5448\\u73b0\\u8fd9\\u6837\\u7684\\u4e2a\\u6027\\uff0c\\u7b80\\u7ea6\\u800c\\u4e0d\\u5931\\u6709\\u8da3\\uff0c\\u8ba9\\u6bcf\\u4e00\\u4e2a\\u63a5\\u89e6\\u8fd9\\u91cc\\u6709\\u7f8e\\u98df\\u7684\\u8fbe\\u4eba\\u7684\\u751f\\u6d3b\\u589e\\u6dfb\\u66f4\\u591a\\u73a9\\u5473\\u4e50\\u8da3\\u3002&lt;\\/p&gt;","type":"textarea","tip":""}}},"jiameng":{"title":"\\u52a0\\u76df\\u4f18\\u52bf","display":1,"vars":{"jiamengs":{"title":"\\u52a0\\u76df\\u4f18\\u52bf","value":[{"thumb":"admin\\/20171029\\/342247ca35acdd3176c09f940952ee3f.png","thumbHover":"admin\\/20171029\\/b135e8db5e3f7c2322df048c19832c5a.png"},{"thumb":"admin\\/20171029\\/294323718da81225b06a6f0a0832ff98.png","thumbHover":"admin\\/20171029\\/9ef497aca2494352051be1307ee08ebb.png"},{"thumb":"admin\\/20171029\\/9a14c6823275fada13878949ee48d9da.png","thumbHover":"admin\\/20171029\\/295b87404db15f74aac5f374ecdae421.png"}],"type":"array","item":{"thumb":{"title":"\\u52a0\\u76df\\u4f18\\u52bf\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a328px*515px)"},"thumbHover":{"title":"\\u9f20\\u6807\\u89e6\\u53d1\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a328px*515px)"}},"tip":""}}},"baozhang":{"title":"\\u652f\\u6301\\u4fdd\\u969c","display":1,"vars":{"baozhangs":{"title":"\\u652f\\u6301\\u4fdd\\u969c","value":[{"icon":"admin\\/20171029\\/3fe9a4751431fee7cce890ccd4118ffd.png","thumb":"admin\\/20171029\\/25f3e7ded2ed56861c39083e79c7bfcf.png","description":"\\u4e13\\u4e1a\\u53a8\\u5e08\\u7814\\u53d1\\u56e2\\u961f\\uff0c\\u4ea7\\u54c1\\u7814\\u53d1\\u603b\\u76d1\\u7531\\u65e5\\u672c\\u5f52\\u6765\\u4e30\\u5bcc\\u7684\\u897f\\u9910\\u83dc\\u54c1\\u7814\\u53d1\\u5236\\u4f5c\\u7ecf\\u9a8c\\u3002"},{"icon":"admin\\/20171029\\/81cab537ba135373bce570d3f7252712.png","thumb":"admin\\/20171029\\/f28e5afb413fbf308a6942bbee6d79b9.png","description":"\\u4e13\\u4e1a\\u53a8\\u5e08\\u7814\\u53d1\\u56e2\\u961f\\uff0c\\u4ea7\\u54c1\\u7814\\u53d1\\u603b\\u76d1\\u7531\\u65e5\\u672c\\u5f52\\u6765\\u4e30\\u5bcc\\u7684\\u897f\\u9910\\u83dc\\u54c1\\u7814\\u53d1\\u5236\\u4f5c\\u7ecf\\u9a8c\\u3002"},{"icon":"admin\\/20171029\\/a1ad5b2d77fa2295101008c1613a8c9e.png","thumb":"admin\\/20171029\\/c75fe7a45bc16af2b95910e410676bc2.png","description":"\\u4e13\\u4e1a\\u53a8\\u5e08\\u7814\\u53d1\\u56e2\\u961f\\uff0c\\u4ea7\\u54c1\\u7814\\u53d1\\u603b\\u76d1\\u7531\\u65e5\\u672c\\u5f52\\u6765\\u4e30\\u5bcc\\u7684\\u897f\\u9910\\u83dc\\u54c1\\u7814\\u53d1\\u5236\\u4f5c\\u7ecf\\u9a8c\\u3002"}],"type":"array","item":{"icon":{"title":"\\u4fdd\\u969c\\u56fe\\u6807","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a122px*122px)"},"thumb":{"title":"\\u4fdd\\u969c\\u4e3b\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a480px*280px)"},"description":{"title":"\\u4fdd\\u969c\\u8bf4\\u660e","value":"","type":"textarea","tip":""}},"tip":""}}},"tiaojian":{"title":"\\u52a0\\u76df\\u6761\\u4ef6","display":1,"vars":{"tiaojians":{"title":"\\u52a0\\u76df\\u6761\\u4ef6","value":[{"icon":"admin\\/20171029\\/880e9eb9fd8f602b707042ff446b98b7.png","description":"\\u6709\\u5f3a\\u70c8\\u7684\\u4e8b\\u4e1a\\u6210\\u529f\\u6b32\\u5e76\\u62e5\\u6709\\u4e00\\u5b9a\\u7ecf\\u8425\\u7ba1\\u7406\\u80fd\\u529b"},{"icon":"admin\\/20171029\\/4d8545415b016811df8590158d90a381.png","description":"\\u6709\\u5f3a\\u70c8\\u7684\\u4e8b\\u4e1a\\u6210\\u529f\\u6b32\\u5e76\\u62e5\\u6709\\u4e00\\u5b9a\\u7ecf\\u8425\\u7ba1\\u7406\\u80fd\\u529b"},{"icon":"admin\\/20171029\\/9efe4ba4dcd29f72a53b8e986b08ce48.png","description":"\\u6709\\u5f3a\\u70c8\\u7684\\u4e8b\\u4e1a\\u6210\\u529f\\u6b32\\u5e76\\u62e5\\u6709\\u4e00\\u5b9a\\u7ecf\\u8425\\u7ba1\\u7406\\u80fd\\u529b"},{"icon":"admin\\/20171029\\/2ce4bec5643cc3bdaa897d97a5b28b70.png","description":"\\u6709\\u5f3a\\u70c8\\u7684\\u4e8b\\u4e1a\\u6210\\u529f\\u6b32\\u5e76\\u62e5\\u6709\\u4e00\\u5b9a\\u7ecf\\u8425\\u7ba1\\u7406\\u80fd\\u529b"}],"type":"array","item":{"icon":{"title":"\\u6761\\u4ef6\\u56fe\\u6807","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a215px*215px)"},"description":{"title":"\\u6761\\u4ef6\\u8bf4\\u660e","value":"","type":"textarea","tip":""}},"tip":""}}},"mengdian":{"title":"\\u95e8\\u5e97\\u5206\\u5e03","display":1,"vars":{"img1":{"title":"\\u52a0\\u76df\\u6d41\\u7a0b\\u5de6\\u8fb9\\u56fe\\u7247","value":"admin\\/20171029\\/fc88a7e308e07e47ca1d15b9b1e93b9c.png","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a425px*585px)"},"img2":{"title":"\\u52a0\\u76df\\u6d41\\u7a0b\\u53f3\\u8fb9\\u56fe\\u7247","value":"admin\\/20171029\\/58e3d9a05dcb9200a0cc4c81d4059788.png","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a570px*585px)"}}}}}', '{"vars":{"ads":{"title":"\\u9876\\u90e8\\u5e7f\\u544a\\u56fe","value":"","type":"image","tip":"\\uff08\\u5efa\\u8bae\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a1920px*500px\\uff09"}},"widgets":{"mainbox":{"title":"\\u9876\\u90e8\\u63a8\\u8350\\u6a21\\u5757","display":"1","vars":{"img1":{"title":"\\u516c\\u53f8\\u56fe\\u72471","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a400px*400px)"},"img2":{"title":"\\u516c\\u53f8\\u56fe\\u72472","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a400px*400px)"},"description":{"title":"\\u516c\\u53f8\\u4ecb\\u7ecd","value":"","type":"textarea","tip":""}}},"jiameng":{"title":"\\u52a0\\u76df\\u4f18\\u52bf","display":"1","vars":{"jiamengs":{"title":"\\u52a0\\u76df\\u4f18\\u52bf","value":[],"type":"array","item":{"thumb":{"title":"\\u52a0\\u76df\\u4f18\\u52bf\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a328px*515px)"},"thumbHover":{"title":"\\u9f20\\u6807\\u89e6\\u53d1\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a328px*515px)"}},"tip":""}}},"baozhang":{"title":"\\u652f\\u6301\\u4fdd\\u969c","display":"1","vars":{"baozhangs":{"title":"\\u652f\\u6301\\u4fdd\\u969c","value":[],"type":"array","item":{"icon":{"title":"\\u4fdd\\u969c\\u56fe\\u6807","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a122px*122px)"},"thumb":{"title":"\\u4fdd\\u969c\\u4e3b\\u56fe","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a480px*280px)"},"description":{"title":"\\u4fdd\\u969c\\u8bf4\\u660e","value":"","type":"textarea","tip":""}},"tip":""}}},"tiaojian":{"title":"\\u52a0\\u76df\\u6761\\u4ef6","display":"1","vars":{"tiaojians":{"title":"\\u52a0\\u76df\\u6761\\u4ef6","value":[],"type":"array","item":{"icon":{"title":"\\u6761\\u4ef6\\u56fe\\u6807","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a215px*215px)"},"description":{"title":"\\u6761\\u4ef6\\u8bf4\\u660e","value":"","type":"textarea","tip":""}},"tip":""}}},"mengdian":{"title":"\\u52a0\\u76df\\u6d41\\u7a0b","display":"1","vars":{"img1":{"title":"\\u52a0\\u76df\\u6d41\\u7a0b\\u5de6\\u8fb9\\u56fe\\u7247","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a425px*585px)"},"img2":{"title":"\\u52a0\\u76df\\u6d41\\u7a0b\\u53f3\\u8fb9\\u56fe\\u7247","value":"","type":"image","tip":"(\\u4e0a\\u4f20\\u5c3a\\u5bf8\\uff1a570px*585px)"}}}}}', NULL),
(2188, 1, 1, 'canyin', '新闻分类导航', 'public/Config', 'public/categorynav', '新闻分类导航配置文件', '{"vars":{"contact":{"title":"\\u54a8\\u8be2\\u70ed\\u7ebf","value":"137-1234-5678","type":"text","tip":""}}}', '{"vars":{"contact":{"title":"\\u54a8\\u8be2\\u70ed\\u7ebf","value":"","type":"text","tip":""}}}', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `cy_third_party_user`
--

CREATE TABLE IF NOT EXISTS `cy_third_party_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '本站用户id',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'access_token过期时间',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '绑定时间',
  `login_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:正常;0:禁用',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '用户昵称',
  `third_party` varchar(20) NOT NULL DEFAULT '' COMMENT '第三方惟一码',
  `app_id` varchar(64) NOT NULL DEFAULT '' COMMENT '第三方应用 id',
  `last_login_ip` varchar(15) NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `access_token` varchar(512) NOT NULL DEFAULT '' COMMENT '第三方授权码',
  `openid` varchar(40) NOT NULL DEFAULT '' COMMENT '第三方用户id',
  `union_id` varchar(64) NOT NULL DEFAULT '' COMMENT '第三方用户多个产品中的惟一 id,(如:微信平台)',
  `more` text COMMENT '扩展信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='第三方用户表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cy_user`
--

CREATE TABLE IF NOT EXISTS `cy_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '用户类型;1:admin;2:会员',
  `sex` tinyint(2) NOT NULL DEFAULT '0' COMMENT '性别;0:保密,1:男,2:女',
  `birthday` int(11) NOT NULL DEFAULT '0' COMMENT '生日',
  `last_login_time` int(11) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `coin` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '金币',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '注册时间',
  `user_status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '用户状态;0:禁用,1:正常,2:未验证',
  `user_login` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `user_pass` varchar(64) NOT NULL DEFAULT '' COMMENT '登录密码;cmf_password加密',
  `user_nickname` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '用户昵称',
  `user_email` varchar(100) NOT NULL DEFAULT '' COMMENT '用户登录邮箱',
  `user_url` varchar(100) NOT NULL DEFAULT '' COMMENT '用户个人网址',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '用户头像',
  `signature` varchar(255) NOT NULL DEFAULT '' COMMENT '个性签名',
  `last_login_ip` varchar(15) NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '' COMMENT '激活码',
  `mobile` varchar(20) NOT NULL DEFAULT '' COMMENT '用户手机号',
  `more` text COMMENT '扩展属性',
  PRIMARY KEY (`id`),
  KEY `user_login` (`user_login`),
  KEY `user_nickname` (`user_nickname`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='用户表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `cy_user`
--

INSERT INTO `cy_user` (`id`, `user_type`, `sex`, `birthday`, `last_login_time`, `score`, `coin`, `create_time`, `user_status`, `user_login`, `user_pass`, `user_nickname`, `user_email`, `user_url`, `avatar`, `signature`, `last_login_ip`, `user_activation_key`, `mobile`, `more`) VALUES
(1, 1, 0, 0, 1509283074, 0, 0, 1508411178, 1, 'admin', '###ab822cde2498ffd7fc7a30af824c7104', 'admin', 'admin@qq.com', '', '', '', '127.0.0.1', '', '', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `cy_user_action`
--

CREATE TABLE IF NOT EXISTS `cy_user_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '更改积分，可以为负',
  `coin` int(11) NOT NULL DEFAULT '0' COMMENT '更改金币，可以为负',
  `reward_number` int(11) NOT NULL DEFAULT '0' COMMENT '奖励次数',
  `cycle_type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '周期类型;0:不限;1:按天;2:按小时;3:永久',
  `cycle_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '周期时间值',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '用户操作名称',
  `action` varchar(50) NOT NULL DEFAULT '' COMMENT '用户操作名称',
  `app` varchar(50) NOT NULL DEFAULT '' COMMENT '操作所在应用名或插件名等',
  `url` text COMMENT '执行操作的url',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='用户操作表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `cy_user_action`
--

INSERT INTO `cy_user_action` (`id`, `score`, `coin`, `reward_number`, `cycle_type`, `cycle_time`, `name`, `action`, `app`, `url`) VALUES
(1, 1, 0, 1, 1, 1, '用户登录', 'login', 'user', '');

-- --------------------------------------------------------

--
-- 表的结构 `cy_user_action_log`
--

CREATE TABLE IF NOT EXISTS `cy_user_action_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '访问次数',
  `last_visit_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后访问时间',
  `object` varchar(100) NOT NULL DEFAULT '' COMMENT '访问对象的id,格式:不带前缀的表名+id;如posts1表示xx_posts表里id为1的记录',
  `action` varchar(50) NOT NULL DEFAULT '' COMMENT '操作名称;格式:应用名+控制器+操作名,也可自己定义格式只要不发生冲突且惟一;',
  `ip` varchar(15) NOT NULL DEFAULT '' COMMENT '用户ip',
  PRIMARY KEY (`id`),
  KEY `user_object_action` (`user_id`,`object`,`action`),
  KEY `user_object_action_ip` (`user_id`,`object`,`action`,`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='访问记录表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cy_user_favorite`
--

CREATE TABLE IF NOT EXISTS `cy_user_favorite` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户 id',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '收藏内容的标题',
  `url` varchar(255) DEFAULT '' COMMENT '收藏内容的原文地址，不带域名',
  `description` varchar(500) DEFAULT '' COMMENT '收藏内容的描述',
  `table_name` varchar(64) NOT NULL DEFAULT '' COMMENT '收藏实体以前所在表,不带前缀',
  `object_id` int(10) unsigned DEFAULT '0' COMMENT '收藏内容原来的主键id',
  `create_time` int(10) unsigned DEFAULT '0' COMMENT '收藏时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户收藏表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cy_user_login_attempt`
--

CREATE TABLE IF NOT EXISTS `cy_user_login_attempt` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `login_attempts` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '尝试次数',
  `attempt_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '尝试登录时间',
  `locked_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '锁定时间',
  `ip` varchar(15) NOT NULL DEFAULT '' COMMENT '用户 ip',
  `account` varchar(100) NOT NULL DEFAULT '' COMMENT '用户账号,手机号,邮箱或用户名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='用户登录尝试表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cy_user_score_log`
--

CREATE TABLE IF NOT EXISTS `cy_user_score_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户 id',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `action` varchar(50) NOT NULL DEFAULT '' COMMENT '用户操作名称',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '更改积分，可以为负',
  `coin` int(11) NOT NULL DEFAULT '0' COMMENT '更改金币，可以为负',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户操作积分等奖励日志表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cy_user_token`
--

CREATE TABLE IF NOT EXISTS `cy_user_token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户id',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT ' 过期时间',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `token` varchar(64) NOT NULL DEFAULT '' COMMENT 'token',
  `device_type` varchar(10) NOT NULL DEFAULT '' COMMENT '设备类型;mobile,android,iphone,ipad,web,pc,mac,wxapp',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='用户客户端登录 token 表' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `cy_user_token`
--

INSERT INTO `cy_user_token` (`id`, `user_id`, `expire_time`, `create_time`, `token`, `device_type`) VALUES
(3, 1, 1524835074, 1509283074, '695fdd48339f34b660e080d4f00cd507e16e0913d78acea92abc4ef12630b78c', 'web');

-- --------------------------------------------------------

--
-- 表的结构 `cy_verification_code`
--

CREATE TABLE IF NOT EXISTS `cy_verification_code` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '表id',
  `count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '当天已经发送成功的次数',
  `send_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后发送成功时间',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '验证码过期时间',
  `code` varchar(8) NOT NULL DEFAULT '' COMMENT '最后发送成功的验证码',
  `account` varchar(100) NOT NULL DEFAULT '' COMMENT '手机号或者邮箱',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='手机邮箱数字验证码表' AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
